import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, RefreshCw, Trash2, Edit, Play, Pause, Clock, Calendar, Check, X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertRecurringTransactionSchema, type InsertRecurringTransaction, type RecurringTransaction, type Category } from "@shared/schema";
import { useState } from "react";
import { z } from "zod";

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(value);
}

function formatDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

const frequencyLabels: Record<string, string> = {
  daily: "Harian",
  weekly: "Mingguan",
  biweekly: "2 Mingguan",
  monthly: "Bulanan",
  yearly: "Tahunan",
};

const statusLabels: Record<string, string> = {
  active: "Aktif",
  paused: "Dijeda",
  completed: "Selesai",
  cancelled: "Dibatalkan",
};

const statusColors: Record<string, string> = {
  active: "bg-green-500/20 text-green-400 border-green-500/30",
  paused: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  completed: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  cancelled: "bg-gray-500/20 text-gray-400 border-gray-500/30",
};

const formSchema = insertRecurringTransactionSchema.extend({
  productName: z.string().min(1, "Nama produk wajib diisi"),
  quantity: z.coerce.number().min(1, "Jumlah minimal 1"),
  costPrice: z.coerce.number().min(0, "Harga modal tidak boleh negatif"),
  sellingPrice: z.coerce.number().min(0, "Harga jual tidak boleh negatif"),
  operationalCost: z.coerce.number().min(0).default(0),
  startDate: z.string().min(1, "Tanggal mulai wajib diisi"),
  nextScheduledDate: z.string().min(1, "Tanggal berikutnya wajib diisi"),
});

export default function RecurringPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingRecurring, setEditingRecurring] = useState<RecurringTransaction | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const { data: recurring = [], isLoading } = useQuery<RecurringTransaction[]>({
    queryKey: ["/api/recurring"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: dueTransactions = [] } = useQuery<RecurringTransaction[]>({
    queryKey: ["/api/recurring/due"],
  });

  const today = new Date().toISOString().split("T")[0];

  const form = useForm<InsertRecurringTransaction>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      productName: "",
      quantity: 1,
      costPrice: 0,
      sellingPrice: 0,
      operationalCost: 0,
      category: "",
      paymentMethod: "cash",
      frequency: "monthly",
      status: "active",
      startDate: today,
      nextScheduledDate: today,
      endDate: "",
      notes: "",
    },
  });

  const editForm = useForm<InsertRecurringTransaction>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      productName: "",
      quantity: 1,
      costPrice: 0,
      sellingPrice: 0,
      operationalCost: 0,
      category: "",
      paymentMethod: "cash",
      frequency: "monthly",
      status: "active",
      startDate: today,
      nextScheduledDate: today,
      endDate: "",
      notes: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertRecurringTransaction) => {
      const res = await apiRequest("POST", "/api/recurring", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recurring"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recurring/due"] });
      toast({ title: "Transaksi berulang berhasil ditambahkan" });
      form.reset({
        productName: "",
        quantity: 1,
        costPrice: 0,
        sellingPrice: 0,
        operationalCost: 0,
        category: "",
        paymentMethod: "cash",
        frequency: "monthly",
        status: "active",
        startDate: today,
        nextScheduledDate: today,
        endDate: "",
        notes: "",
      });
    },
    onError: () => {
      toast({ title: "Gagal menambahkan transaksi berulang", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertRecurringTransaction> }) => {
      const res = await apiRequest("PATCH", `/api/recurring/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recurring"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recurring/due"] });
      toast({ title: "Transaksi berulang berhasil diperbarui" });
      setIsEditDialogOpen(false);
      setEditingRecurring(null);
    },
    onError: () => {
      toast({ title: "Gagal memperbarui transaksi berulang", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/recurring/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recurring"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recurring/due"] });
      toast({ title: "Transaksi berulang berhasil dihapus" });
    },
    onError: () => {
      toast({ title: "Gagal menghapus transaksi berulang", variant: "destructive" });
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const res = await apiRequest("PATCH", `/api/recurring/${id}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recurring"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recurring/due"] });
      toast({ title: "Status berhasil diperbarui" });
    },
    onError: () => {
      toast({ title: "Gagal memperbarui status", variant: "destructive" });
    },
  });

  const processMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/recurring/${id}/process`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recurring"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recurring/due"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({ title: "Transaksi berhasil diproses" });
    },
    onError: () => {
      toast({ title: "Gagal memproses transaksi", variant: "destructive" });
    },
  });

  const processAllMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/recurring/process-all");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/recurring"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recurring/due"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({ 
        title: `${data.processed} transaksi diproses`,
        description: data.failed > 0 ? `${data.failed} gagal` : undefined,
      });
    },
    onError: () => {
      toast({ title: "Gagal memproses transaksi", variant: "destructive" });
    },
  });

  const handleEdit = (item: RecurringTransaction) => {
    setEditingRecurring(item);
    editForm.reset({
      productName: item.productName,
      quantity: item.quantity,
      costPrice: item.costPrice,
      sellingPrice: item.sellingPrice,
      operationalCost: item.operationalCost,
      category: item.category || "",
      paymentMethod: item.paymentMethod || "cash",
      frequency: item.frequency,
      status: item.status,
      startDate: item.startDate,
      nextScheduledDate: item.nextScheduledDate,
      endDate: item.endDate || "",
      notes: item.notes || "",
    });
    setIsEditDialogOpen(true);
  };

  const onSubmit = (data: InsertRecurringTransaction) => {
    createMutation.mutate(data);
  };

  const onEditSubmit = (data: InsertRecurringTransaction) => {
    if (editingRecurring) {
      updateMutation.mutate({ id: editingRecurring.id, data });
    }
  };

  const activeCount = recurring.filter(r => r.status === "active").length;
  const pausedCount = recurring.filter(r => r.status === "paused").length;

  if (isLoading) {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <RefreshCw className="h-6 w-6 text-cyan-400" />
            Transaksi Berulang
          </h1>
          <p className="text-muted-foreground">
            Kelola transaksi otomatis yang dijadwalkan secara berkala
          </p>
        </div>
        {dueTransactions.length > 0 && (
          <Button 
            onClick={() => processAllMutation.mutate()}
            disabled={processAllMutation.isPending}
            className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500"
            data-testid="button-process-all"
          >
            <Play className="mr-2 h-4 w-4" />
            Proses {dueTransactions.length} Transaksi
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-cyan-500/30 bg-gradient-to-br from-cyan-500/10 to-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Transaksi Berulang
            </CardTitle>
            <RefreshCw className="h-4 w-4 text-cyan-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-cyan-400" data-testid="text-total-recurring">
              {recurring.length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-500/30 bg-gradient-to-br from-green-500/10 to-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Aktif
            </CardTitle>
            <Check className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400" data-testid="text-active-count">
              {activeCount}
            </div>
          </CardContent>
        </Card>

        <Card className="border-yellow-500/30 bg-gradient-to-br from-yellow-500/10 to-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Menunggu Proses
            </CardTitle>
            <Clock className="h-4 w-4 text-yellow-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-400" data-testid="text-due-count">
              {dueTransactions.length}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1 border-purple-500/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-purple-400" />
              Tambah Transaksi Berulang
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="productName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nama Produk</FormLabel>
                      <FormControl>
                        <Input placeholder="Nama produk" {...field} data-testid="input-product-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Jumlah</FormLabel>
                        <FormControl>
                          <Input type="number" min="1" {...field} data-testid="input-quantity" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Kategori</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || ""}>
                          <FormControl>
                            <SelectTrigger data-testid="select-category">
                              <SelectValue placeholder="Pilih kategori" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories.map((cat) => (
                              <SelectItem key={cat.id} value={cat.name}>
                                {cat.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="costPrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Harga Modal</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" {...field} data-testid="input-cost-price" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="sellingPrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Harga Jual</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" {...field} data-testid="input-selling-price" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="frequency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Frekuensi</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-frequency">
                            <SelectValue placeholder="Pilih frekuensi" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="daily">Harian</SelectItem>
                          <SelectItem value="weekly">Mingguan</SelectItem>
                          <SelectItem value="biweekly">2 Mingguan</SelectItem>
                          <SelectItem value="monthly">Bulanan</SelectItem>
                          <SelectItem value="yearly">Tahunan</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tanggal Mulai</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} data-testid="input-start-date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="nextScheduledDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Jadwal Berikutnya</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} data-testid="input-next-date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tanggal Berakhir (Opsional)</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} value={field.value || ""} data-testid="input-end-date" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="paymentMethod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Metode Pembayaran</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "cash"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-payment">
                            <SelectValue placeholder="Pilih metode" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="cash">Tunai</SelectItem>
                          <SelectItem value="transfer">Transfer</SelectItem>
                          <SelectItem value="ewallet">E-Wallet</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500"
                  disabled={createMutation.isPending}
                  data-testid="button-submit"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Tambah Transaksi Berulang
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 border-cyan-500/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RefreshCw className="h-5 w-5 text-cyan-400" />
              Daftar Transaksi Berulang
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recurring.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <RefreshCw className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Belum ada transaksi berulang</p>
                <p className="text-sm">Tambahkan transaksi berulang pertama Anda</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Produk</TableHead>
                      <TableHead>Frekuensi</TableHead>
                      <TableHead>Jadwal</TableHead>
                      <TableHead className="text-right">Profit</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recurring.map((item) => {
                      const profit = (item.sellingPrice - item.costPrice) * item.quantity - item.operationalCost;
                      const isDue = item.nextScheduledDate <= today && item.status === "active";
                      
                      return (
                        <TableRow key={item.id} className={isDue ? "bg-yellow-500/10" : ""} data-testid={`row-recurring-${item.id}`}>
                          <TableCell>
                            <div className="font-medium">{item.productName}</div>
                            <div className="text-sm text-muted-foreground">
                              {item.quantity}x @ {formatCurrency(item.sellingPrice)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="border-cyan-500/30">
                              {frequencyLabels[item.frequency]}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-muted-foreground" />
                              <span>{formatDate(item.nextScheduledDate)}</span>
                            </div>
                            {isDue && (
                              <Badge variant="outline" className="mt-1 bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                                Siap diproses
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right font-medium text-green-400">
                            {formatCurrency(profit)}
                          </TableCell>
                          <TableCell>
                            <Badge className={statusColors[item.status]}>
                              {statusLabels[item.status]}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              {isDue && (
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  onClick={() => processMutation.mutate(item.id)}
                                  disabled={processMutation.isPending}
                                  className="text-green-400 hover:text-green-300"
                                  data-testid={`button-process-${item.id}`}
                                >
                                  <Play className="h-4 w-4" />
                                </Button>
                              )}
                              {item.status === "active" && (
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  onClick={() => updateStatusMutation.mutate({ id: item.id, status: "paused" })}
                                  disabled={updateStatusMutation.isPending}
                                  className="text-yellow-400 hover:text-yellow-300"
                                  data-testid={`button-pause-${item.id}`}
                                >
                                  <Pause className="h-4 w-4" />
                                </Button>
                              )}
                              {item.status === "paused" && (
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  onClick={() => updateStatusMutation.mutate({ id: item.id, status: "active" })}
                                  disabled={updateStatusMutation.isPending}
                                  className="text-green-400 hover:text-green-300"
                                  data-testid={`button-resume-${item.id}`}
                                >
                                  <Play className="h-4 w-4" />
                                </Button>
                              )}
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => handleEdit(item)}
                                data-testid={`button-edit-${item.id}`}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="text-red-400 hover:text-red-300"
                                    data-testid={`button-delete-${item.id}`}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Hapus Transaksi Berulang?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Transaksi berulang "{item.productName}" akan dihapus secara permanen.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Batal</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteMutation.mutate(item.id)}
                                      className="bg-red-600 hover:bg-red-700"
                                    >
                                      Hapus
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Transaksi Berulang</DialogTitle>
            <DialogDescription>
              Perbarui informasi transaksi berulang
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="productName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nama Produk</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-edit-product-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="quantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Jumlah</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" {...field} data-testid="input-edit-quantity" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="frequency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Frekuensi</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-edit-frequency">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="daily">Harian</SelectItem>
                          <SelectItem value="weekly">Mingguan</SelectItem>
                          <SelectItem value="biweekly">2 Mingguan</SelectItem>
                          <SelectItem value="monthly">Bulanan</SelectItem>
                          <SelectItem value="yearly">Tahunan</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="costPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Harga Modal</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} data-testid="input-edit-cost-price" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="sellingPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Harga Jual</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} data-testid="input-edit-selling-price" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={editForm.control}
                name="nextScheduledDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Jadwal Berikutnya</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-edit-next-date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Batal
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateMutation.isPending}
                  className="bg-gradient-to-r from-cyan-600 to-purple-600"
                  data-testid="button-edit-submit"
                >
                  Simpan
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
