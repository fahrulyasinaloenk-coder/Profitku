import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CircuitBackground } from "@/components/circuit-background";
import {
  Calculator,
  TrendingUp,
  Package,
  BarChart3,
  FileText,
  Target,
  Smartphone,
  Sparkles,
  ChevronRight,
} from "lucide-react";
import asfLogo from "@assets/IMG_6514_1764421052224.jpeg";

const features = [
  {
    icon: Calculator,
    title: "Profit Real-time",
    description: "Catat transaksi dan lihat profit langsung dihitung otomatis",
  },
  {
    icon: TrendingUp,
    title: "Grafik Penjualan",
    description: "Pantau tren penjualan harian dan mingguan dengan visual menarik",
  },
  {
    icon: Target,
    title: "Target Bulanan",
    description: "Tetapkan target dan lihat progress pencapaian Anda",
  },
  {
    icon: Package,
    title: "Manajemen Stok",
    description: "Kelola inventaris dan dapatkan peringatan stok rendah",
  },
  {
    icon: BarChart3,
    title: "Analitik Lengkap",
    description: "Lihat produk terlaris dan performa per kategori",
  },
  {
    icon: FileText,
    title: "Export Laporan",
    description: "Unduh laporan dalam format Excel atau PDF",
  },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[hsl(230,60%,6%)] via-[hsl(230,55%,8%)] to-[hsl(230,50%,10%)] relative overflow-hidden">
      <div className="fixed inset-0 z-0">
        <CircuitBackground />
      </div>
      <header className="border-b border-cyan-500/20 bg-[hsl(230,60%,6%)]/90 backdrop-blur-lg sticky top-0 z-50 shadow-[0_4px_20px_rgba(34,211,238,0.1)]">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3 group">
            <img 
              src={asfLogo} 
              alt="aSF" 
              className="h-10 w-10 rounded-lg shadow-[0_0_15px_rgba(34,211,238,0.4)] group-hover:shadow-[0_0_25px_rgba(34,211,238,0.6)] transition-shadow" 
            />
            <div>
              <span className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-cyan-300 bg-clip-text text-transparent neon-text">aSF</span>
              <p className="text-[8px] text-purple-400/70">alung SF</p>
            </div>
          </div>
          <Button asChild data-testid="button-login-header" className="bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-[hsl(230,60%,5%)] border-0 shadow-[0_0_15px_rgba(34,211,238,0.4)] hover:shadow-[0_0_25px_rgba(34,211,238,0.6)]">
            <a href="/api/login">Masuk</a>
          </Button>
        </div>
      </header>

      <main className="relative z-10">
        <section className="container mx-auto px-4 py-20 md:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mb-8 shadow-[0_0_15px_rgba(34,211,238,0.2)]">
              <Sparkles className="h-4 w-4" />
              <span className="text-sm font-medium">Platform Bisnis Modern</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 leading-tight text-white">
              Kelola Bisnis Anda dengan{" "}
              <span className="bg-gradient-to-r from-cyan-400 via-cyan-300 to-purple-400 bg-clip-text text-transparent">
                Lebih Cerdas
              </span>
            </h1>
            <p className="text-lg md:text-xl text-cyan-200/70 mb-10 max-w-2xl mx-auto leading-relaxed">
              Platform manajemen keuangan futuristik untuk pengusaha modern. 
              Catat transaksi, analisis profit, dan kembangkan bisnis Anda.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild data-testid="button-login-hero" className="gap-2 bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-[hsl(230,60%,5%)] border-0 shadow-[0_0_20px_rgba(34,211,238,0.4)] hover:shadow-[0_0_30px_rgba(34,211,238,0.6)]">
                <a href="/api/login">
                  Mulai Sekarang
                  <ChevronRight className="h-5 w-5" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild className="gap-2 border-purple-500/40 text-purple-300 hover:bg-purple-500/10 hover:border-purple-500/60 shadow-[0_0_10px_rgba(139,92,246,0.2)]">
                <a href="#features">
                  <Smartphone className="h-5 w-5" />
                  Pelajari Fitur
                </a>
              </Button>
            </div>
          </div>
        </section>

        <section id="features" className="container mx-auto px-4 py-20 border-t border-cyan-500/20">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
              Fitur <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">Premium</span>
            </h2>
            <p className="text-cyan-200/60 max-w-2xl mx-auto">
              Semua yang Anda butuhkan untuk mengelola keuangan bisnis dalam satu platform
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover-elevate bg-[hsl(230,55%,10%)] border-cyan-500/20 hover:border-cyan-500/50 transition-all hover:shadow-[0_0_25px_rgba(34,211,238,0.2)]">
                <CardContent className="p-8">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 flex items-center justify-center mb-6 shadow-[0_0_15px_rgba(34,211,238,0.2)]">
                    <feature.icon className="h-6 w-6 text-cyan-400" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 text-white">{feature.title}</h3>
                  <p className="text-cyan-200/60 leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="container mx-auto px-4 py-20">
          <Card className="bg-gradient-to-br from-[hsl(230,55%,10%)] to-[hsl(260,50%,12%)] border-purple-500/30 overflow-hidden shadow-[0_0_30px_rgba(139,92,246,0.2)]">
            <CardContent className="p-10 md:p-16 text-center relative">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(139,92,246,0.3)_0%,_transparent_70%)] opacity-30" />
              <div className="relative z-10">
                <h2 className="text-2xl md:text-4xl font-bold mb-6 text-white">
                  Siap Mengembangkan <span className="bg-gradient-to-r from-cyan-400 to-cyan-300 bg-clip-text text-transparent">Bisnis Anda?</span>
                </h2>
                <p className="text-cyan-200/70 mb-8 max-w-xl mx-auto text-lg leading-relaxed">
                  Bergabunglah dengan ribuan pengusaha sukses yang sudah mempercayakan 
                  manajemen keuangan bisnis mereka kepada aSF.
                </p>
                <Button size="lg" asChild data-testid="button-login-cta" className="gap-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 text-white border-0 shadow-[0_0_20px_rgba(139,92,246,0.4)] hover:shadow-[0_0_30px_rgba(139,92,246,0.6)]">
                  <a href="/api/login">
                    Daftar Gratis
                    <ChevronRight className="h-5 w-5" />
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>

      <footer className="border-t border-cyan-500/20 py-10 bg-[hsl(230,60%,5%)] relative z-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3 group">
              <img src={asfLogo} alt="aSF" className="h-8 w-8 rounded-lg shadow-[0_0_10px_rgba(34,211,238,0.3)]" />
              <div>
                <span className="font-semibold bg-gradient-to-r from-cyan-400 to-cyan-300 bg-clip-text text-transparent">aSF</span>
                <p className="text-[7px] text-purple-400/70">alung SF</p>
              </div>
            </div>
            <p className="text-sm text-cyan-400/50">
              &copy; {new Date().getFullYear()} aSF. Platform Bisnis Modern.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
