import { useQuery } from "@tanstack/react-query";
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Package,
  Tag,
  Trophy,
  PieChart,
  Wallet,
  CreditCard,
  Smartphone,
  Banknote,
  Clock,
  Calendar,
  Users,
  Target,
  ArrowUp,
  ArrowDown,
  Minus,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart as RechartsPie,
  Pie,
  LineChart,
  Line,
  AreaChart,
  Area,
} from "recharts";
import { formatRupiah, getCurrentMonthYear, getMonthName } from "@/lib/utils";
import type { 
  CategorySummary, 
  ProductSummary, 
  PaymentMethodSummary,
  HourlySales,
  DayOfWeekSales,
  CustomerInsight,
  ProductProfitability,
  PeriodComparison,
} from "@shared/schema";

const CHART_COLORS = [
  "#6366f1",
  "#10b981",
  "#f59e0b",
  "#f43f5e",
  "#0ea5e9",
  "#a855f7",
  "#f97316",
  "#14b8a6",
];

const PAYMENT_ICONS: Record<string, any> = {
  cash: Banknote,
  transfer: CreditCard,
  ewallet: Smartphone,
};

const PAYMENT_LABELS: Record<string, string> = {
  cash: "Tunai",
  transfer: "Transfer Bank",
  ewallet: "E-Wallet",
};

export default function AnalitikPage() {
  const { month, year } = getCurrentMonthYear();

  // Existing analytics queries
  const { data: categorySummaries = [], isLoading: loadingCategories } = useQuery<
    CategorySummary[]
  >({
    queryKey: ["/api/analytics/categories", month, year],
  });

  const { data: productSummaries = [], isLoading: loadingProducts } = useQuery<
    ProductSummary[]
  >({
    queryKey: ["/api/analytics/products", month, year],
  });

  const { data: paymentSummaries = [], isLoading: loadingPayments } = useQuery<
    PaymentMethodSummary[]
  >({
    queryKey: ["/api/analytics/payment-methods", month, year],
  });

  // Advanced analytics queries
  const { data: hourlySales = [], isLoading: loadingHourly } = useQuery<HourlySales[]>({
    queryKey: ["/api/analytics/hourly", month, year],
  });

  const { data: dayOfWeekSales = [], isLoading: loadingDayOfWeek } = useQuery<DayOfWeekSales[]>({
    queryKey: ["/api/analytics/day-of-week", month, year],
  });

  const { data: customerInsights = [], isLoading: loadingCustomers } = useQuery<CustomerInsight[]>({
    queryKey: ["/api/analytics/customers"],
  });

  const { data: profitability = [], isLoading: loadingProfitability } = useQuery<ProductProfitability[]>({
    queryKey: ["/api/analytics/profitability", month, year],
  });

  const { data: weeklyComparison, isLoading: loadingWeekly } = useQuery<PeriodComparison>({
    queryKey: ["/api/analytics/comparison", "weekly"],
  });

  const { data: monthlyComparison, isLoading: loadingMonthly } = useQuery<PeriodComparison>({
    queryKey: ["/api/analytics/comparison", "monthly"],
  });

  const totalRevenue = categorySummaries.reduce(
    (sum, c) => sum + c.totalRevenue,
    0
  );
  const totalProfit = categorySummaries.reduce(
    (sum, c) => sum + c.totalProfit,
    0
  );
  const totalTransactions = categorySummaries.reduce(
    (sum, c) => sum + c.transactionCount,
    0
  );

  const topProducts = productSummaries.slice(0, 5);
  const categoryChartData = categorySummaries.map((cat) => ({
    name: cat.category,
    revenue: cat.totalRevenue,
    profit: cat.totalProfit,
  }));

  const paymentChartData = paymentSummaries.map((pm) => ({
    name: PAYMENT_LABELS[pm.method] || pm.method,
    value: pm.totalRevenue,
    count: pm.transactionCount,
  }));

  // Format hourly data for chart
  const hourlyChartData = hourlySales.map((h) => ({
    hour: `${h.hour.toString().padStart(2, '0')}:00`,
    revenue: h.totalRevenue,
    transactions: h.transactionCount,
  }));

  // Format day of week data for chart
  const dayOfWeekChartData = dayOfWeekSales.map((d) => ({
    day: d.dayName,
    revenue: d.totalRevenue,
    profit: d.totalProfit,
    transactions: d.transactionCount,
  }));

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="rounded-lg border bg-background p-3 shadow-md">
          <p className="font-medium">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {formatRupiah(entry.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const PieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="rounded-lg border bg-background p-3 shadow-md">
          <p className="font-medium">{payload[0].name}</p>
          <p className="text-sm text-muted-foreground">
            {formatRupiah(payload[0].value)}
          </p>
          <p className="text-sm text-muted-foreground">
            {payload[0].payload.count} transaksi
          </p>
        </div>
      );
    }
    return null;
  };

  const ChangeIndicator = ({ value, suffix = "%" }: { value: number; suffix?: string }) => {
    if (value > 0) {
      return (
        <span className="flex items-center gap-1 text-green-600 dark:text-green-400">
          <ArrowUp className="h-4 w-4" />
          +{value.toFixed(1)}{suffix}
        </span>
      );
    } else if (value < 0) {
      return (
        <span className="flex items-center gap-1 text-red-600 dark:text-red-400">
          <ArrowDown className="h-4 w-4" />
          {value.toFixed(1)}{suffix}
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1 text-muted-foreground">
        <Minus className="h-4 w-4" />
        0{suffix}
      </span>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
          <BarChart3 className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Analitik</h1>
          <p className="text-muted-foreground">
            Analisis performa {getMonthName(month)} {year}
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-card-border">
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Omzet Bulan Ini
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingCategories ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <div className="text-2xl font-bold font-mono tabular-nums">
                {formatRupiah(totalRevenue)}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-card-border">
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Profit Bulan Ini
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            {loadingCategories ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <div className="text-2xl font-bold font-mono tabular-nums text-green-600 dark:text-green-400">
                {formatRupiah(totalProfit)}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-card-border">
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Transaksi
            </CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingCategories ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <div className="text-2xl font-bold font-mono tabular-nums">
                {totalTransactions}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Tabbed Analytics */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid grid-cols-5 w-full max-w-2xl">
          <TabsTrigger value="overview" data-testid="tab-overview">
            <BarChart3 className="h-4 w-4 mr-2 hidden sm:block" />
            Ringkasan
          </TabsTrigger>
          <TabsTrigger value="time" data-testid="tab-time">
            <Clock className="h-4 w-4 mr-2 hidden sm:block" />
            Waktu
          </TabsTrigger>
          <TabsTrigger value="trend" data-testid="tab-trend">
            <TrendingUp className="h-4 w-4 mr-2 hidden sm:block" />
            Trend
          </TabsTrigger>
          <TabsTrigger value="customers" data-testid="tab-customers">
            <Users className="h-4 w-4 mr-2 hidden sm:block" />
            Pelanggan
          </TabsTrigger>
          <TabsTrigger value="profitability" data-testid="tab-profitability">
            <Target className="h-4 w-4 mr-2 hidden sm:block" />
            Margin
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="border-card-border lg:col-span-2">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Trophy className="h-5 w-5 text-amber-500" />
                  Produk Terlaris
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingProducts ? (
                  <div className="space-y-3">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <Skeleton key={i} className="h-12 w-full" />
                    ))}
                  </div>
                ) : topProducts.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Belum ada data produk</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {topProducts.map((product, index) => {
                      const maxQuantity = topProducts[0]?.totalQuantity || 1;
                      const percentage = (product.totalQuantity / maxQuantity) * 100;
                      return (
                        <div key={product.productName} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Badge
                                variant={index === 0 ? "default" : "secondary"}
                                className="w-6 h-6 flex items-center justify-center p-0 text-xs"
                              >
                                {index + 1}
                              </Badge>
                              <span className="font-medium truncate max-w-[180px]">
                                {product.productName}
                              </span>
                            </div>
                            <div className="text-right">
                              <p className="font-mono text-sm font-medium">
                                {product.totalQuantity} terjual
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {formatRupiah(product.totalRevenue)}
                              </p>
                            </div>
                          </div>
                          <Progress value={percentage} className="h-2" />
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-card-border">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Wallet className="h-5 w-5 text-primary" />
                  Metode Pembayaran
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingPayments ? (
                  <div className="h-[200px] flex items-center justify-center">
                    <Skeleton className="h-full w-full" />
                  </div>
                ) : paymentChartData.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Wallet className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Belum ada data pembayaran</p>
                  </div>
                ) : (
                  <>
                    <div className="h-[180px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPie>
                          <Pie
                            data={paymentChartData}
                            cx="50%"
                            cy="50%"
                            innerRadius={40}
                            outerRadius={70}
                            paddingAngle={2}
                            dataKey="value"
                          >
                            {paymentChartData.map((entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={CHART_COLORS[index % CHART_COLORS.length]}
                              />
                            ))}
                          </Pie>
                          <Tooltip content={<PieTooltip />} />
                        </RechartsPie>
                      </ResponsiveContainer>
                    </div>
                    <div className="space-y-2 mt-4">
                      {paymentSummaries.map((pm, index) => {
                        const Icon = PAYMENT_ICONS[pm.method] || Wallet;
                        const totalPaymentRevenue = paymentSummaries.reduce((s, p) => s + p.totalRevenue, 0);
                        const percentage = totalPaymentRevenue > 0 ? (pm.totalRevenue / totalPaymentRevenue) * 100 : 0;
                        return (
                          <div key={pm.method} className="flex items-center gap-2 text-sm">
                            <div
                              className="h-3 w-3 rounded-full"
                              style={{ backgroundColor: CHART_COLORS[index % CHART_COLORS.length] }}
                            />
                            <Icon className="h-4 w-4 text-muted-foreground" />
                            <span className="flex-1">{PAYMENT_LABELS[pm.method] || pm.method}</span>
                            <span className="font-mono text-muted-foreground">{percentage.toFixed(0)}%</span>
                          </div>
                        );
                      })}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          <Card className="border-card-border">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <PieChart className="h-5 w-5 text-primary" />
                Performa per Kategori
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingCategories ? (
                <div className="h-[300px] flex items-center justify-center">
                  <Skeleton className="h-full w-full" />
                </div>
              ) : categoryChartData.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Tag className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Belum ada data kategori</p>
                </div>
              ) : (
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={categoryChartData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis
                        dataKey="name"
                        tick={{ fontSize: 12 }}
                        angle={-45}
                        textAnchor="end"
                        height={60}
                        className="fill-muted-foreground"
                      />
                      <YAxis
                        tickFormatter={(value) =>
                          new Intl.NumberFormat("id-ID", {
                            notation: "compact",
                            compactDisplay: "short",
                          }).format(value)
                        }
                        className="fill-muted-foreground"
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="revenue" name="Omzet" radius={[4, 4, 0, 0]}>
                        {categoryChartData.map((entry, index) => (
                          <Cell
                            key={`cell-${index}`}
                            fill={CHART_COLORS[index % CHART_COLORS.length]}
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-card-border">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Tag className="h-5 w-5" />
                Ringkasan per Kategori
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingCategories ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : categorySummaries.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Tag className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Belum ada data kategori</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Kategori</TableHead>
                        <TableHead className="text-right">Produk</TableHead>
                        <TableHead className="text-right">Transaksi</TableHead>
                        <TableHead className="text-right">Omzet</TableHead>
                        <TableHead className="text-right">Profit</TableHead>
                        <TableHead className="text-right">% Omzet</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {categorySummaries.map((category, index) => {
                        const revenuePercentage =
                          totalRevenue > 0
                            ? (category.totalRevenue / totalRevenue) * 100
                            : 0;
                        return (
                          <TableRow
                            key={category.category}
                            data-testid={`row-category-summary-${index}`}
                          >
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <div
                                  className="h-3 w-3 rounded-full"
                                  style={{
                                    backgroundColor:
                                      CHART_COLORS[index % CHART_COLORS.length],
                                  }}
                                />
                                <span className="font-medium">{category.category}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-right font-mono">
                              {category.productCount}
                            </TableCell>
                            <TableCell className="text-right font-mono">
                              {category.transactionCount}
                            </TableCell>
                            <TableCell className="text-right font-mono">
                              {formatRupiah(category.totalRevenue)}
                            </TableCell>
                            <TableCell className="text-right font-mono text-green-600 dark:text-green-400">
                              {formatRupiah(category.totalProfit)}
                            </TableCell>
                            <TableCell className="text-right">
                              <Badge variant="secondary">
                                {revenuePercentage.toFixed(1)}%
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Time Analysis Tab */}
        <TabsContent value="time" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-card-border">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Clock className="h-5 w-5 text-primary" />
                  Penjualan per Jam
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingHourly ? (
                  <div className="h-[300px] flex items-center justify-center">
                    <Skeleton className="h-full w-full" />
                  </div>
                ) : (
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={hourlyChartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis 
                          dataKey="hour" 
                          tick={{ fontSize: 10 }}
                          interval={2}
                          className="fill-muted-foreground"
                        />
                        <YAxis
                          tickFormatter={(value) =>
                            new Intl.NumberFormat("id-ID", {
                              notation: "compact",
                              compactDisplay: "short",
                            }).format(value)
                          }
                          className="fill-muted-foreground"
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Area 
                          type="monotone" 
                          dataKey="revenue" 
                          name="Omzet"
                          stroke="#6366f1" 
                          fillOpacity={1} 
                          fill="url(#colorRevenue)" 
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-card-border">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Calendar className="h-5 w-5 text-primary" />
                  Penjualan per Hari
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingDayOfWeek ? (
                  <div className="h-[300px] flex items-center justify-center">
                    <Skeleton className="h-full w-full" />
                  </div>
                ) : (
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={dayOfWeekChartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis 
                          dataKey="day" 
                          tick={{ fontSize: 12 }}
                          className="fill-muted-foreground"
                        />
                        <YAxis
                          tickFormatter={(value) =>
                            new Intl.NumberFormat("id-ID", {
                              notation: "compact",
                              compactDisplay: "short",
                            }).format(value)
                          }
                          className="fill-muted-foreground"
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Bar dataKey="revenue" name="Omzet" fill="#6366f1" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="profit" name="Profit" fill="#10b981" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Best Hours & Days Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="border-card-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Jam Tersibuk
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingHourly ? (
                  <Skeleton className="h-8 w-24" />
                ) : (
                  (() => {
                    const busiest = hourlySales.reduce((max, h) => 
                      h.transactionCount > max.transactionCount ? h : max, 
                      hourlySales[0] || { hour: 0, transactionCount: 0, totalRevenue: 0 }
                    );
                    return (
                      <div>
                        <p className="text-2xl font-bold font-mono">
                          {busiest.hour.toString().padStart(2, '0')}:00
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {busiest.transactionCount} transaksi • {formatRupiah(busiest.totalRevenue)}
                        </p>
                      </div>
                    );
                  })()
                )}
              </CardContent>
            </Card>

            <Card className="border-card-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Hari Tersibuk
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingDayOfWeek ? (
                  <Skeleton className="h-8 w-24" />
                ) : (
                  (() => {
                    const busiest = dayOfWeekSales.reduce((max, d) => 
                      d.transactionCount > max.transactionCount ? d : max, 
                      dayOfWeekSales[0] || { dayName: '-', transactionCount: 0, totalRevenue: 0 }
                    );
                    return (
                      <div>
                        <p className="text-2xl font-bold">{busiest.dayName}</p>
                        <p className="text-sm text-muted-foreground">
                          {busiest.transactionCount} transaksi • {formatRupiah(busiest.totalRevenue)}
                        </p>
                      </div>
                    );
                  })()
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Trend Comparison Tab */}
        <TabsContent value="trend" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Weekly Comparison */}
            <Card className="border-card-border">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Perbandingan Mingguan
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingWeekly ? (
                  <div className="space-y-4">
                    <Skeleton className="h-20 w-full" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                ) : !weeklyComparison ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <TrendingUp className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Belum ada data perbandingan</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 rounded-lg bg-muted/50">
                        <p className="text-sm text-muted-foreground">{weeklyComparison.currentPeriod.label}</p>
                        <p className="text-xl font-bold font-mono">{formatRupiah(weeklyComparison.currentPeriod.totalRevenue)}</p>
                        <p className="text-sm text-green-600 dark:text-green-400">{formatRupiah(weeklyComparison.currentPeriod.totalProfit)} profit</p>
                      </div>
                      <div className="p-4 rounded-lg bg-muted/50">
                        <p className="text-sm text-muted-foreground">{weeklyComparison.previousPeriod.label}</p>
                        <p className="text-xl font-bold font-mono">{formatRupiah(weeklyComparison.previousPeriod.totalRevenue)}</p>
                        <p className="text-sm text-green-600 dark:text-green-400">{formatRupiah(weeklyComparison.previousPeriod.totalProfit)} profit</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 pt-4 border-t">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground mb-1">Omzet</p>
                        <ChangeIndicator value={weeklyComparison.revenueChange} />
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground mb-1">Profit</p>
                        <ChangeIndicator value={weeklyComparison.profitChange} />
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground mb-1">Transaksi</p>
                        <ChangeIndicator value={weeklyComparison.transactionCountChange} />
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Monthly Comparison */}
            <Card className="border-card-border">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Calendar className="h-5 w-5 text-primary" />
                  Perbandingan Bulanan
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingMonthly ? (
                  <div className="space-y-4">
                    <Skeleton className="h-20 w-full" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                ) : !monthlyComparison ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Belum ada data perbandingan</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 rounded-lg bg-muted/50">
                        <p className="text-sm text-muted-foreground">{monthlyComparison.currentPeriod.label}</p>
                        <p className="text-xl font-bold font-mono">{formatRupiah(monthlyComparison.currentPeriod.totalRevenue)}</p>
                        <p className="text-sm text-green-600 dark:text-green-400">{formatRupiah(monthlyComparison.currentPeriod.totalProfit)} profit</p>
                      </div>
                      <div className="p-4 rounded-lg bg-muted/50">
                        <p className="text-sm text-muted-foreground">{monthlyComparison.previousPeriod.label}</p>
                        <p className="text-xl font-bold font-mono">{formatRupiah(monthlyComparison.previousPeriod.totalRevenue)}</p>
                        <p className="text-sm text-green-600 dark:text-green-400">{formatRupiah(monthlyComparison.previousPeriod.totalProfit)} profit</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 pt-4 border-t">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground mb-1">Omzet</p>
                        <ChangeIndicator value={monthlyComparison.revenueChange} />
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground mb-1">Profit</p>
                        <ChangeIndicator value={monthlyComparison.profitChange} />
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground mb-1">Transaksi</p>
                        <ChangeIndicator value={monthlyComparison.transactionCountChange} />
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Customer Insights Tab */}
        <TabsContent value="customers" className="space-y-6">
          <Card className="border-card-border">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Users className="h-5 w-5 text-primary" />
                Pelanggan Terbaik
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingCustomers ? (
                <div className="space-y-3">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : customerInsights.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Belum ada data pelanggan</p>
                  <p className="text-sm mt-2">Tambahkan pelanggan di menu Pelanggan</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>#</TableHead>
                        <TableHead>Nama Pelanggan</TableHead>
                        <TableHead className="text-right">Total Transaksi</TableHead>
                        <TableHead className="text-right">Total Belanja</TableHead>
                        <TableHead className="text-right">Rata-rata</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {customerInsights.map((customer, index) => (
                        <TableRow key={customer.customerId} data-testid={`row-customer-${index}`}>
                          <TableCell>
                            <Badge variant={index < 3 ? "default" : "secondary"} className="w-6 h-6 flex items-center justify-center p-0">
                              {index + 1}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-medium">{customer.customerName}</TableCell>
                          <TableCell className="text-right font-mono">{customer.totalTransactions}</TableCell>
                          <TableCell className="text-right font-mono">{formatRupiah(customer.totalSpent)}</TableCell>
                          <TableCell className="text-right font-mono text-muted-foreground">
                            {formatRupiah(customer.averageTransactionValue)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Product Profitability Tab */}
        <TabsContent value="profitability" className="space-y-6">
          <Card className="border-card-border">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Target className="h-5 w-5 text-primary" />
                Margin Profit per Produk
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingProfitability ? (
                <div className="space-y-3">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : profitability.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Target className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Belum ada data profitabilitas</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Produk</TableHead>
                        <TableHead>Kategori</TableHead>
                        <TableHead className="text-right">Qty</TableHead>
                        <TableHead className="text-right">Omzet</TableHead>
                        <TableHead className="text-right">Profit</TableHead>
                        <TableHead className="text-right">Margin</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {profitability.slice(0, 10).map((product, index) => (
                        <TableRow key={product.productName} data-testid={`row-profitability-${index}`}>
                          <TableCell className="font-medium max-w-[150px] truncate">
                            {product.productName}
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {product.category || '-'}
                          </TableCell>
                          <TableCell className="text-right font-mono">{product.totalQuantity}</TableCell>
                          <TableCell className="text-right font-mono">{formatRupiah(product.totalRevenue)}</TableCell>
                          <TableCell className="text-right font-mono text-green-600 dark:text-green-400">
                            {formatRupiah(product.totalProfit)}
                          </TableCell>
                          <TableCell className="text-right">
                            <Badge 
                              variant={product.profitMargin >= 30 ? "default" : product.profitMargin >= 15 ? "secondary" : "destructive"}
                            >
                              {product.profitMargin.toFixed(1)}%
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Profitability Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="border-card-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Rata-rata Margin
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingProfitability ? (
                  <Skeleton className="h-8 w-20" />
                ) : (
                  <p className="text-2xl font-bold font-mono">
                    {profitability.length > 0 
                      ? (profitability.reduce((sum, p) => sum + p.profitMargin, 0) / profitability.length).toFixed(1)
                      : 0
                    }%
                  </p>
                )}
              </CardContent>
            </Card>

            <Card className="border-card-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Margin Tertinggi
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingProfitability ? (
                  <Skeleton className="h-8 w-32" />
                ) : profitability.length > 0 ? (
                  <div>
                    <p className="text-lg font-bold truncate">{profitability[0].productName}</p>
                    <p className="text-sm text-green-600 dark:text-green-400">{profitability[0].profitMargin.toFixed(1)}% margin</p>
                  </div>
                ) : (
                  <p className="text-muted-foreground">-</p>
                )}
              </CardContent>
            </Card>

            <Card className="border-card-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Margin Terendah
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingProfitability ? (
                  <Skeleton className="h-8 w-32" />
                ) : profitability.length > 0 ? (
                  <div>
                    <p className="text-lg font-bold truncate">{profitability[profitability.length - 1].productName}</p>
                    <p className="text-sm text-amber-600 dark:text-amber-400">{profitability[profitability.length - 1].profitMargin.toFixed(1)}% margin</p>
                  </div>
                ) : (
                  <p className="text-muted-foreground">-</p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
