import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Upload, Download, FileSpreadsheet, Trash2, Package, CheckCircle, XCircle, AlertTriangle, History, ShieldAlert } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { type Transaction, type Product, type BulkImportLog } from "@shared/schema";
import { useState, useRef } from "react";
import * as XLSX from "xlsx";

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(value);
}

function formatDate(dateString: string | Date | null): string {
  if (!dateString) return "-";
  return new Date(dateString).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

const statusColors: Record<string, string> = {
  pending: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  processing: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  completed: "bg-green-500/20 text-green-400 border-green-500/30",
  failed: "bg-red-500/20 text-red-400 border-red-500/30",
};

const statusLabels: Record<string, string> = {
  pending: "Menunggu",
  processing: "Memproses",
  completed: "Selesai",
  failed: "Gagal",
};

export default function BulkOperationsPage() {
  const { toast } = useToast();
  const { user, canExport, canDelete } = useAuth();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [selectedTransactions, setSelectedTransactions] = useState<number[]>([]);
  const [selectedProducts, setSelectedProducts] = useState<number[]>([]);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleteType, setDeleteType] = useState<"transactions" | "products">("transactions");
  const [importData, setImportData] = useState<any[]>([]);
  const [importFileName, setImportFileName] = useState("");

  // RBAC: Only Owner can access bulk operations
  if (user?.role !== "owner") {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <Card className="bg-red-500/10 border-red-500/30">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ShieldAlert className="h-16 w-16 text-red-400 mb-4" />
            <h2 className="text-xl font-semibold text-red-400 mb-2">Akses Ditolak</h2>
            <p className="text-muted-foreground text-center max-w-md">
              Halaman ini hanya dapat diakses oleh pemilik toko (Owner). 
              Hubungi administrator untuk mendapatkan akses.
            </p>
            <Button 
              className="mt-6" 
              variant="outline"
              onClick={() => navigate("/")}
              data-testid="button-back-home"
            >
              Kembali ke Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data: transactions = [], isLoading: loadingTxn } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const { data: products = [], isLoading: loadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: importLogs = [], isLoading: loadingLogs } = useQuery<BulkImportLog[]>({
    queryKey: ["/api/bulk/logs"],
  });

  const bulkImportMutation = useMutation({
    mutationFn: async ({ transactions, fileName }: { transactions: any[]; fileName: string }) => {
      const res = await apiRequest("POST", "/api/bulk/transactions", { transactions, fileName });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bulk/logs"] });
      toast({
        title: "Import selesai",
        description: `${data.success} berhasil, ${data.failed} gagal`,
      });
      setImportData([]);
      setImportFileName("");
    },
    onError: () => {
      toast({ title: "Gagal mengimport data", variant: "destructive" });
    },
  });

  const bulkDeleteTransactionsMutation = useMutation({
    mutationFn: async (ids: number[]) => {
      const res = await apiRequest("POST", "/api/bulk/delete/transactions", { ids });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Hapus berhasil",
        description: `${data.success} transaksi dihapus`,
      });
      setSelectedTransactions([]);
      setShowDeleteDialog(false);
    },
    onError: () => {
      toast({ title: "Gagal menghapus transaksi", variant: "destructive" });
    },
  });

  const bulkDeleteProductsMutation = useMutation({
    mutationFn: async (ids: number[]) => {
      const res = await apiRequest("POST", "/api/bulk/delete/products", { ids });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Hapus berhasil",
        description: `${data.success} produk dihapus`,
      });
      setSelectedProducts([]);
      setShowDeleteDialog(false);
    },
    onError: () => {
      toast({ title: "Gagal menghapus produk", variant: "destructive" });
    },
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImportFileName(file.name);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: "array" });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(sheet);
        
        const transactions = jsonData.map((row: any) => ({
          productName: row["Nama Produk"] || row.productName || "",
          quantity: parseInt(row["Jumlah"] || row.quantity) || 1,
          costPrice: parseFloat(row["Harga Modal"] || row.costPrice) || 0,
          sellingPrice: parseFloat(row["Harga Jual"] || row.sellingPrice) || 0,
          operationalCost: parseFloat(row["Biaya Operasional"] || row.operationalCost) || 0,
          category: row["Kategori"] || row.category || null,
          paymentMethod: row["Metode Pembayaran"] || row.paymentMethod || "cash",
          date: row["Tanggal"] || row.date || new Date().toISOString().split("T")[0],
        }));

        setImportData(transactions);
        toast({ title: `${transactions.length} baris data siap diimport` });
      } catch (error) {
        toast({ title: "Gagal membaca file", variant: "destructive" });
      }
    };
    reader.readAsArrayBuffer(file);
    
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleExportTransactions = () => {
    const exportData = transactions.map(t => ({
      "Nama Produk": t.productName,
      "Jumlah": t.quantity,
      "Harga Modal": t.costPrice,
      "Harga Jual": t.sellingPrice,
      "Biaya Operasional": t.operationalCost,
      "Profit": t.profit,
      "Kategori": t.category || "",
      "Metode Pembayaran": t.paymentMethod,
      "Tanggal": t.date,
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Transaksi");
    XLSX.writeFile(workbook, `transaksi_${new Date().toISOString().split("T")[0]}.xlsx`);
    toast({ title: "Export berhasil" });
  };

  const handleExportProducts = () => {
    const exportData = products.map(p => ({
      "Nama Produk": p.name,
      "Kategori ID": p.categoryId || "",
      "Stok": p.stock,
      "Stok Minimum": p.minStock,
      "Harga Modal": p.costPrice,
      "Harga Jual": p.sellingPrice,
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Produk");
    XLSX.writeFile(workbook, `produk_${new Date().toISOString().split("T")[0]}.xlsx`);
    toast({ title: "Export berhasil" });
  };

  const handleDownloadTemplate = () => {
    const templateData = [
      {
        "Nama Produk": "Contoh Produk",
        "Jumlah": 1,
        "Harga Modal": 10000,
        "Harga Jual": 15000,
        "Biaya Operasional": 0,
        "Kategori": "Makanan",
        "Metode Pembayaran": "cash",
        "Tanggal": new Date().toISOString().split("T")[0],
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Template");
    XLSX.writeFile(workbook, "template_transaksi.xlsx");
    toast({ title: "Template berhasil diunduh" });
  };

  const toggleTransactionSelection = (id: number) => {
    setSelectedTransactions(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleProductSelection = (id: number) => {
    setSelectedProducts(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const selectAllTransactions = () => {
    if (selectedTransactions.length === transactions.length) {
      setSelectedTransactions([]);
    } else {
      setSelectedTransactions(transactions.map(t => t.id));
    }
  };

  const selectAllProducts = () => {
    if (selectedProducts.length === products.length) {
      setSelectedProducts([]);
    } else {
      setSelectedProducts(products.map(p => p.id));
    }
  };

  const handleBulkDelete = (type: "transactions" | "products") => {
    setDeleteType(type);
    setShowDeleteDialog(true);
  };

  const confirmBulkDelete = () => {
    if (deleteType === "transactions") {
      bulkDeleteTransactionsMutation.mutate(selectedTransactions);
    } else {
      bulkDeleteProductsMutation.mutate(selectedProducts);
    }
  };

  const isLoading = loadingTxn || loadingProducts || loadingLogs;

  if (isLoading) {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (!canExport) {
    return (
      <div className="p-4 md:p-6">
        <Card className="border-yellow-500/30 bg-yellow-500/10">
          <CardContent className="pt-6">
            <div className="text-center py-12">
              <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-yellow-400" />
              <h2 className="text-xl font-semibold mb-2">Akses Terbatas</h2>
              <p className="text-muted-foreground">
                Fitur bulk operations hanya tersedia untuk Owner.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <FileSpreadsheet className="h-6 w-6 text-cyan-400" />
          Operasi Massal
        </h1>
        <p className="text-muted-foreground">
          Import/Export data dan kelola data secara massal
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-cyan-500/30 bg-gradient-to-br from-cyan-500/10 to-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Transaksi
            </CardTitle>
            <FileSpreadsheet className="h-4 w-4 text-cyan-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-cyan-400" data-testid="text-total-transactions">
              {transactions.length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-500/30 bg-gradient-to-br from-purple-500/10 to-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Produk
            </CardTitle>
            <Package className="h-4 w-4 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-400" data-testid="text-total-products">
              {products.length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-500/30 bg-gradient-to-br from-green-500/10 to-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Riwayat Import
            </CardTitle>
            <History className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400" data-testid="text-import-count">
              {importLogs.length}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="import" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 bg-muted/30">
          <TabsTrigger value="import" data-testid="tab-import">
            <Upload className="h-4 w-4 mr-2" />
            Import
          </TabsTrigger>
          <TabsTrigger value="export" data-testid="tab-export">
            <Download className="h-4 w-4 mr-2" />
            Export
          </TabsTrigger>
          <TabsTrigger value="bulk-delete" data-testid="tab-bulk-delete">
            <Trash2 className="h-4 w-4 mr-2" />
            Hapus Massal
          </TabsTrigger>
          <TabsTrigger value="history" data-testid="tab-history">
            <History className="h-4 w-4 mr-2" />
            Riwayat
          </TabsTrigger>
        </TabsList>

        <TabsContent value="import">
          <Card className="border-cyan-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5 text-cyan-400" />
                Import Transaksi
              </CardTitle>
              <CardDescription>
                Upload file Excel (.xlsx) untuk import transaksi secara massal
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <Input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    onChange={handleFileUpload}
                    className="cursor-pointer"
                    data-testid="input-file-upload"
                  />
                </div>
                <Button variant="outline" onClick={handleDownloadTemplate} data-testid="button-download-template">
                  <Download className="h-4 w-4 mr-2" />
                  Download Template
                </Button>
              </div>

              {importData.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-muted-foreground">
                      <strong>{importData.length}</strong> baris siap diimport dari <strong>{importFileName}</strong>
                    </p>
                    <Button
                      onClick={() => bulkImportMutation.mutate({ transactions: importData, fileName: importFileName })}
                      disabled={bulkImportMutation.isPending}
                      className="bg-gradient-to-r from-cyan-600 to-purple-600"
                      data-testid="button-import"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Import Sekarang
                    </Button>
                  </div>

                  <div className="overflow-x-auto max-h-64 border rounded-lg">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produk</TableHead>
                          <TableHead>Jumlah</TableHead>
                          <TableHead>Harga Modal</TableHead>
                          <TableHead>Harga Jual</TableHead>
                          <TableHead>Kategori</TableHead>
                          <TableHead>Tanggal</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {importData.slice(0, 10).map((row, idx) => (
                          <TableRow key={idx}>
                            <TableCell>{row.productName}</TableCell>
                            <TableCell>{row.quantity}</TableCell>
                            <TableCell>{formatCurrency(row.costPrice)}</TableCell>
                            <TableCell>{formatCurrency(row.sellingPrice)}</TableCell>
                            <TableCell>{row.category || "-"}</TableCell>
                            <TableCell>{row.date}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    {importData.length > 10 && (
                      <p className="text-center text-sm text-muted-foreground py-2">
                        ... dan {importData.length - 10} baris lainnya
                      </p>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="export">
          <Card className="border-purple-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-5 w-5 text-purple-400" />
                Export Data
              </CardTitle>
              <CardDescription>
                Download data dalam format Excel (.xlsx)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="border-cyan-500/30 hover:border-cyan-400/50 transition-colors cursor-pointer" onClick={handleExportTransactions}>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-lg bg-cyan-500/20">
                        <FileSpreadsheet className="h-6 w-6 text-cyan-400" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Export Transaksi</h3>
                        <p className="text-sm text-muted-foreground">
                          {transactions.length} transaksi
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-purple-500/30 hover:border-purple-400/50 transition-colors cursor-pointer" onClick={handleExportProducts}>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-lg bg-purple-500/20">
                        <Package className="h-6 w-6 text-purple-400" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Export Produk</h3>
                        <p className="text-sm text-muted-foreground">
                          {products.length} produk
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bulk-delete">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-red-500/30">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <FileSpreadsheet className="h-5 w-5 text-cyan-400" />
                    Hapus Transaksi
                  </span>
                  {selectedTransactions.length > 0 && canDelete && (
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleBulkDelete("transactions")}
                      data-testid="button-delete-transactions"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Hapus ({selectedTransactions.length})
                    </Button>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">
                          <Checkbox
                            checked={selectedTransactions.length === transactions.length && transactions.length > 0}
                            onCheckedChange={selectAllTransactions}
                            data-testid="checkbox-select-all-transactions"
                          />
                        </TableHead>
                        <TableHead>Produk</TableHead>
                        <TableHead>Tanggal</TableHead>
                        <TableHead className="text-right">Profit</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {transactions.slice(0, 20).map((txn) => (
                        <TableRow key={txn.id} data-testid={`row-transaction-${txn.id}`}>
                          <TableCell>
                            <Checkbox
                              checked={selectedTransactions.includes(txn.id)}
                              onCheckedChange={() => toggleTransactionSelection(txn.id)}
                              data-testid={`checkbox-transaction-${txn.id}`}
                            />
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">{txn.productName}</div>
                            <div className="text-sm text-muted-foreground">{txn.quantity}x</div>
                          </TableCell>
                          <TableCell>{txn.date}</TableCell>
                          <TableCell className="text-right font-medium text-green-400">
                            {formatCurrency(txn.profit)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  {transactions.length > 20 && (
                    <p className="text-center text-sm text-muted-foreground py-2">
                      Menampilkan 20 dari {transactions.length} transaksi
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-red-500/30">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Package className="h-5 w-5 text-purple-400" />
                    Hapus Produk
                  </span>
                  {selectedProducts.length > 0 && canDelete && (
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleBulkDelete("products")}
                      data-testid="button-delete-products"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Hapus ({selectedProducts.length})
                    </Button>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">
                          <Checkbox
                            checked={selectedProducts.length === products.length && products.length > 0}
                            onCheckedChange={selectAllProducts}
                            data-testid="checkbox-select-all-products"
                          />
                        </TableHead>
                        <TableHead>Produk</TableHead>
                        <TableHead>Stok</TableHead>
                        <TableHead className="text-right">Harga</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {products.map((product) => (
                        <TableRow key={product.id} data-testid={`row-product-${product.id}`}>
                          <TableCell>
                            <Checkbox
                              checked={selectedProducts.includes(product.id)}
                              onCheckedChange={() => toggleProductSelection(product.id)}
                              data-testid={`checkbox-product-${product.id}`}
                            />
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">{product.name}</div>
                            <div className="text-sm text-muted-foreground">{product.categoryId ? `Kategori ${product.categoryId}` : "-"}</div>
                          </TableCell>
                          <TableCell>{product.stock}</TableCell>
                          <TableCell className="text-right">
                            {formatCurrency(product.sellingPrice)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card className="border-green-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5 text-green-400" />
                Riwayat Import
              </CardTitle>
            </CardHeader>
            <CardContent>
              {importLogs.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Belum ada riwayat import</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>File</TableHead>
                      <TableHead>Tipe</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Berhasil</TableHead>
                      <TableHead>Gagal</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Tanggal</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {importLogs.map((log) => (
                      <TableRow key={log.id} data-testid={`row-import-${log.id}`}>
                        <TableCell className="font-medium">{log.fileName}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">
                            {log.importType}
                          </Badge>
                        </TableCell>
                        <TableCell>{log.totalRows}</TableCell>
                        <TableCell className="text-green-400">{log.successRows}</TableCell>
                        <TableCell className="text-red-400">{log.failedRows}</TableCell>
                        <TableCell>
                          <Badge className={statusColors[log.status]}>
                            {statusLabels[log.status]}
                          </Badge>
                        </TableCell>
                        <TableCell>{formatDate(log.createdAt)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus {deleteType === "transactions" ? "Transaksi" : "Produk"}?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteType === "transactions"
                ? `${selectedTransactions.length} transaksi akan dihapus secara permanen.`
                : `${selectedProducts.length} produk akan dihapus secara permanen.`}
              <br />
              Tindakan ini tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmBulkDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
