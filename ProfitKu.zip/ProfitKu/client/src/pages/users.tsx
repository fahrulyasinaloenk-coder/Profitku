import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { NeonSkeleton } from "@/components/neon-skeleton";
import { Users, Crown, UserCog, Trash2, Shield, ShieldOff } from "lucide-react";
import { format } from "date-fns";
import { id as idLocale } from "date-fns/locale";
import type { User } from "@shared/schema";

export default function UsersPage() {
  const { user: currentUser, isOwner } = useAuth();
  const { toast } = useToast();

  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: isOwner,
  });

  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      const response = await apiRequest("PATCH", `/api/users/${userId}/role`, { role });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Role berhasil diubah",
        description: "Role user telah diperbarui",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Gagal mengubah role",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await apiRequest("DELETE", `/api/users/${userId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "User berhasil dihapus",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Gagal menghapus user",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (!isOwner) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="border-red-500/30 bg-red-500/5">
          <CardContent className="flex flex-col items-center gap-4 py-8">
            <ShieldOff className="h-16 w-16 text-red-400" />
            <div className="text-center">
              <h2 className="text-xl font-semibold text-red-400">Akses Ditolak</h2>
              <p className="text-gray-400 mt-2">
                Hanya Owner yang dapat mengakses halaman ini
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <div className="flex items-center gap-3">
          <Users className="h-8 w-8 text-cyan-400" />
          <h1 className="text-2xl font-bold text-white">Kelola User</h1>
        </div>
        <div className="grid gap-4">
          {[1, 2, 3].map((i) => (
            <NeonSkeleton key={i} className="h-24 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  const owners = users?.filter((u) => u.role === "owner") || [];
  const kasirs = users?.filter((u) => u.role === "kasir") || [];

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
          <Users className="h-6 w-6 text-cyan-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">Kelola User</h1>
          <p className="text-gray-400 text-sm">
            Atur role dan akses pengguna aplikasi
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="border-cyan-500/30 bg-gradient-to-br from-cyan-500/10 to-transparent">
          <CardContent className="flex items-center gap-4 py-4">
            <div className="p-3 rounded-full bg-cyan-500/20">
              <Crown className="h-6 w-6 text-cyan-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-cyan-400">{owners.length}</p>
              <p className="text-sm text-gray-400">Owner</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-purple-500/30 bg-gradient-to-br from-purple-500/10 to-transparent">
          <CardContent className="flex items-center gap-4 py-4">
            <div className="p-3 rounded-full bg-purple-500/20">
              <UserCog className="h-6 w-6 text-purple-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-purple-400">{kasirs.length}</p>
              <p className="text-sm text-gray-400">Kasir</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-cyan-500/30 shadow-[0_0_20px_rgba(34,211,238,0.1)]">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="h-5 w-5 text-cyan-400" />
            Daftar User
          </CardTitle>
          <CardDescription>
            Kelola role dan hapus user dari sistem
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users?.map((user) => {
              const isCurrentUser = user.id === currentUser?.id;
              const isLastOwner = user.role === "owner" && owners.length === 1;
              const initials = `${user.firstName?.[0] || ""}${user.lastName?.[0] || ""}`.toUpperCase() || "U";

              return (
                <div
                  key={user.id}
                  className="flex items-center justify-between gap-4 p-4 rounded-lg border border-gray-700/50 bg-gray-800/30 hover:border-cyan-500/30 transition-all"
                  data-testid={`user-row-${user.id}`}
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10 border border-cyan-500/30">
                      <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || "User"} />
                      <AvatarFallback className="bg-cyan-500/20 text-cyan-400">
                        {initials}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-white">
                          {user.firstName} {user.lastName}
                        </p>
                        {isCurrentUser && (
                          <Badge variant="outline" className="text-xs border-cyan-500/30 text-cyan-400">
                            Anda
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-400">{user.email}</p>
                      {user.createdAt && (
                        <p className="text-xs text-gray-500">
                          Bergabung {format(new Date(user.createdAt), "d MMM yyyy", { locale: idLocale })}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Select
                      value={user.role || "kasir"}
                      onValueChange={(value) => {
                        if (!isLastOwner || value === "owner") {
                          updateRoleMutation.mutate({ userId: user.id, role: value });
                        }
                      }}
                      disabled={updateRoleMutation.isPending || (isLastOwner && user.role === "owner")}
                    >
                      <SelectTrigger 
                        className="w-28 border-gray-700 bg-gray-800/50"
                        data-testid={`select-role-${user.id}`}
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        <SelectItem value="owner" data-testid="role-option-owner">
                          <div className="flex items-center gap-2">
                            <Crown className="h-4 w-4 text-cyan-400" />
                            Owner
                          </div>
                        </SelectItem>
                        <SelectItem value="kasir" data-testid="role-option-kasir">
                          <div className="flex items-center gap-2">
                            <UserCog className="h-4 w-4 text-purple-400" />
                            Kasir
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>

                    {!isCurrentUser && !isLastOwner && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                            data-testid={`delete-user-${user.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="bg-gray-900 border-gray-700">
                          <AlertDialogHeader>
                            <AlertDialogTitle className="text-white">
                              Hapus User?
                            </AlertDialogTitle>
                            <AlertDialogDescription>
                              Anda yakin ingin menghapus{" "}
                              <span className="font-semibold text-white">
                                {user.firstName} {user.lastName}
                              </span>
                              ? Aksi ini tidak dapat dibatalkan.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                              Batal
                            </AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => deleteUserMutation.mutate(user.id)}
                              className="bg-red-600 hover:bg-red-700"
                              data-testid="confirm-delete-user"
                            >
                              Hapus
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                  </div>
                </div>
              );
            })}

            {(!users || users.length === 0) && (
              <div className="text-center py-8 text-gray-400">
                Tidak ada user terdaftar
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="border-gray-700/50 bg-gray-800/30">
        <CardHeader>
          <CardTitle className="text-white text-lg">Tentang Role</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-3">
            <Crown className="h-5 w-5 text-cyan-400 mt-0.5" />
            <div>
              <p className="font-medium text-white">Owner</p>
              <p className="text-sm text-gray-400">
                Akses penuh: hapus transaksi, kategori, produk, export laporan, kelola user
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <UserCog className="h-5 w-5 text-purple-400 mt-0.5" />
            <div>
              <p className="font-medium text-white">Kasir</p>
              <p className="text-sm text-gray-400">
                Akses terbatas: input transaksi, lihat data, tidak bisa hapus atau export
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
