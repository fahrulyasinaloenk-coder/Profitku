import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Plus, FileText, Trash2, Eye, Download, Send, CheckCircle, Clock, XCircle, 
  Calendar, User, Building
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  insertInvoiceSchema,
  type InsertInvoice,
  type Invoice, 
  type InvoiceItem,
  type InvoiceStatus,
  type Customer,
  type Store,
  type Product,
} from "@shared/schema";
import { useState, useEffect } from "react";
import { z } from "zod";
import jsPDF from "jspdf";
import "jspdf-autotable";

declare module "jspdf" {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(value);
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

const statusConfig: Record<InvoiceStatus, { label: string; color: string; icon: any }> = {
  draft: { label: "Draft", color: "bg-gray-500/20 text-gray-400 border-gray-500/30", icon: FileText },
  sent: { label: "Terkirim", color: "bg-blue-500/20 text-blue-400 border-blue-500/30", icon: Send },
  paid: { label: "Lunas", color: "bg-green-500/20 text-green-400 border-green-500/30", icon: CheckCircle },
  overdue: { label: "Jatuh Tempo", color: "bg-red-500/20 text-red-400 border-red-500/30", icon: Clock },
  cancelled: { label: "Dibatalkan", color: "bg-gray-500/20 text-gray-400 border-gray-500/30", icon: XCircle },
};

const invoiceFormSchema = z.object({
  customerId: z.number().optional().nullable(),
  storeId: z.number().optional().nullable(),
  invoiceNumber: z.string().min(1, "Nomor invoice wajib diisi"),
  issueDate: z.string().optional(),
  dueDate: z.string().optional().nullable(),
  taxRate: z.number().min(0).max(100).default(0),
  discountRate: z.number().min(0).max(100).default(0),
  notes: z.string().optional().nullable(),
  terms: z.string().optional().nullable(),
  items: z.array(z.object({
    description: z.string().min(1, "Deskripsi wajib diisi"),
    quantity: z.number().min(1, "Minimal 1"),
    unitPrice: z.number().min(0, "Harga tidak boleh negatif"),
    productId: z.number().optional().nullable(),
  })).min(1, "Minimal 1 item"),
});

type InvoiceFormData = z.infer<typeof invoiceFormSchema>;

export default function InvoicePage() {
  const { toast } = useToast();
  const { canDelete } = useAuth();
  const queryClient = useQueryClient();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [viewingInvoice, setViewingInvoice] = useState<(Invoice & { items?: InvoiceItem[] }) | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);

  const today = new Date().toISOString().split("T")[0];

  const { data: invoices = [], isLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices"],
  });

  const { data: customers = [] } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const { data: stores = [] } = useQuery<Store[]>({
    queryKey: ["/api/stores"],
  });

  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const form = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      customerId: undefined,
      storeId: undefined,
      invoiceNumber: "",
      issueDate: today,
      dueDate: "",
      taxRate: 0,
      discountRate: 0,
      notes: "",
      terms: "Pembayaran dalam 30 hari",
      items: [{ description: "", quantity: 1, unitPrice: 0, productId: undefined }],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items",
  });

  const generateInvoiceNumber = async () => {
    try {
      const res = await fetch("/api/invoices/generate-number");
      const data = await res.json();
      form.setValue("invoiceNumber", data.invoiceNumber);
    } catch (error) {
      console.error("Failed to generate invoice number:", error);
    }
  };

  useEffect(() => {
    if (isCreateDialogOpen) {
      generateInvoiceNumber();
    }
  }, [isCreateDialogOpen]);

  const createInvoiceMutation = useMutation({
    mutationFn: async (data: InvoiceFormData) => {
      const res = await apiRequest("POST", "/api/invoices", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({ title: "Invoice berhasil dibuat" });
      setIsCreateDialogOpen(false);
      form.reset({
        customerId: undefined,
        storeId: undefined,
        invoiceNumber: "",
        issueDate: today,
        dueDate: "",
        taxRate: 0,
        discountRate: 0,
        notes: "",
        terms: "Pembayaran dalam 30 hari",
        items: [{ description: "", quantity: 1, unitPrice: 0, productId: undefined }],
      });
    },
    onError: (error: any) => {
      toast({ title: error.message || "Gagal membuat invoice", variant: "destructive" });
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: InvoiceStatus }) => {
      const res = await apiRequest("PATCH", `/api/invoices/${id}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({ title: "Status invoice diperbarui" });
    },
    onError: () => {
      toast({ title: "Gagal memperbarui status", variant: "destructive" });
    },
  });

  const deleteInvoiceMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/invoices/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({ title: "Invoice dihapus" });
    },
    onError: () => {
      toast({ title: "Gagal menghapus invoice", variant: "destructive" });
    },
  });

  const onSubmit = (data: InvoiceFormData) => {
    createInvoiceMutation.mutate(data);
  };

  const viewInvoice = async (invoice: Invoice) => {
    try {
      const res = await fetch(`/api/invoices/${invoice.id}`);
      const data = await res.json();
      setViewingInvoice(data);
      setIsViewDialogOpen(true);
    } catch (error) {
      toast({ title: "Gagal memuat invoice", variant: "destructive" });
    }
  };

  const downloadPdf = (invoice: Invoice & { items?: InvoiceItem[] }) => {
    const doc = new jsPDF();
    const customer = customers.find((c) => c.id === invoice.customerId);

    doc.setFontSize(20);
    doc.setTextColor(34, 211, 238);
    doc.text("INVOICE", 105, 20, { align: "center" });

    doc.setFontSize(12);
    doc.setTextColor(100);
    doc.text(invoice.invoiceNumber, 105, 30, { align: "center" });

    doc.setFontSize(10);
    doc.setTextColor(60);
    doc.text(`Tanggal: ${formatDate(invoice.issueDate)}`, 14, 45);
    if (invoice.dueDate) {
      doc.text(`Jatuh Tempo: ${formatDate(invoice.dueDate)}`, 14, 52);
    }

    if (customer) {
      doc.text("Kepada:", 14, 65);
      doc.setTextColor(0);
      doc.text(customer.name, 14, 72);
      if (customer.address) doc.text(customer.address, 14, 79);
      if (customer.phone) doc.text(`Tel: ${customer.phone}`, 14, 86);
    }

    const tableData = invoice.items?.map((item) => [
      item.description,
      item.quantity.toString(),
      formatCurrency(item.unitPrice),
      formatCurrency(item.totalPrice),
    ]) || [];

    doc.autoTable({
      startY: 95,
      head: [["Deskripsi", "Qty", "Harga", "Total"]],
      body: tableData,
      theme: "grid",
      headStyles: { fillColor: [34, 211, 238], textColor: [0, 0, 0] },
      styles: { fontSize: 10 },
    });

    const finalY = (doc as any).lastAutoTable.finalY + 10;

    doc.setFontSize(10);
    doc.text(`Subtotal: ${formatCurrency(invoice.subtotal)}`, 140, finalY);
    if (invoice.taxRate > 0) {
      doc.text(`Pajak (${invoice.taxRate}%): ${formatCurrency(invoice.taxAmount)}`, 140, finalY + 7);
    }
    if (invoice.discountRate > 0) {
      doc.text(`Diskon (${invoice.discountRate}%): -${formatCurrency(invoice.discountAmount)}`, 140, finalY + 14);
    }
    doc.setFontSize(12);
    doc.setTextColor(34, 211, 238);
    doc.text(`TOTAL: ${formatCurrency(invoice.totalAmount)}`, 140, finalY + 25);

    if (invoice.terms) {
      doc.setFontSize(8);
      doc.setTextColor(100);
      doc.text(`Syarat: ${invoice.terms}`, 14, finalY + 35);
    }

    doc.save(`${invoice.invoiceNumber}.pdf`);
    toast({ title: "PDF berhasil diunduh" });
  };

  const watchItems = form.watch("items");
  const watchTaxRate = form.watch("taxRate");
  const watchDiscountRate = form.watch("discountRate");

  const subtotal = watchItems.reduce((sum, item) => sum + (item.quantity || 0) * (item.unitPrice || 0), 0);
  const taxAmount = subtotal * (watchTaxRate || 0) / 100;
  const discountAmount = subtotal * (watchDiscountRate || 0) / 100;
  const totalAmount = subtotal + taxAmount - discountAmount;

  const totalInvoices = invoices.length;
  const paidInvoices = invoices.filter((i) => i.status === "paid");
  const unpaidTotal = invoices
    .filter((i) => i.status !== "paid" && i.status !== "cancelled")
    .reduce((sum, i) => sum + i.totalAmount, 0);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-500/10 neon-border">
            <FileText className="h-6 w-6 text-purple-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight neon-text">Invoice</h1>
            <p className="text-muted-foreground">Kelola invoice pelanggan Anda</p>
          </div>
        </div>
        <Button
          onClick={() => setIsCreateDialogOpen(true)}
          className="neon-border bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400"
          data-testid="button-create-invoice"
        >
          <Plus className="h-4 w-4 mr-2" />
          Buat Invoice
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="neon-border bg-card/50 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Invoice
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-cyan-400">{totalInvoices}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {paidInvoices.length} lunas
            </p>
          </CardContent>
        </Card>

        <Card className="neon-border bg-card/50 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Belum Dibayar
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-400">
              {formatCurrency(unpaidTotal)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {invoices.filter((i) => i.status !== "paid" && i.status !== "cancelled").length} invoice
            </p>
          </CardContent>
        </Card>

        <Card className="neon-border bg-card/50 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Terbayar
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">
              {formatCurrency(paidInvoices.reduce((sum, i) => sum + i.totalAmount, 0))}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {paidInvoices.length} invoice
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="neon-border bg-card/50 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-cyan-400" />
            Daftar Invoice
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : invoices.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Belum ada invoice
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-cyan-500/20">
                    <TableHead>No. Invoice</TableHead>
                    <TableHead>Pelanggan</TableHead>
                    <TableHead>Tanggal</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices.map((invoice) => {
                    const customer = customers.find((c) => c.id === invoice.customerId);
                    const config = statusConfig[invoice.status];
                    const StatusIcon = config.icon;
                    return (
                      <TableRow
                        key={invoice.id}
                        className="border-cyan-500/20 hover:bg-cyan-500/5"
                        data-testid={`row-invoice-${invoice.id}`}
                      >
                        <TableCell className="font-medium font-mono">
                          {invoice.invoiceNumber}
                        </TableCell>
                        <TableCell>
                          {customer ? (
                            <div className="flex items-center gap-2">
                              <User className="h-4 w-4 text-muted-foreground" />
                              {customer.name}
                            </div>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            {formatDate(invoice.issueDate)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={config.color}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {config.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-medium text-cyan-400">
                          {formatCurrency(invoice.totalAmount)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => viewInvoice(invoice)}
                              data-testid={`button-view-invoice-${invoice.id}`}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            {invoice.status === "draft" && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => updateStatusMutation.mutate({ id: invoice.id, status: "sent" })}
                                data-testid={`button-send-invoice-${invoice.id}`}
                              >
                                <Send className="h-4 w-4 text-blue-400" />
                              </Button>
                            )}
                            {invoice.status === "sent" && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => updateStatusMutation.mutate({ id: invoice.id, status: "paid" })}
                                data-testid={`button-paid-invoice-${invoice.id}`}
                              >
                                <CheckCircle className="h-4 w-4 text-green-400" />
                              </Button>
                            )}
                            {canDelete && (
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    data-testid={`button-delete-invoice-${invoice.id}`}
                                  >
                                    <Trash2 className="h-4 w-4 text-red-400" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent className="neon-border bg-card">
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Hapus Invoice?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Invoice "{invoice.invoiceNumber}" akan dihapus secara permanen.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Batal</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteInvoiceMutation.mutate(invoice.id)}
                                      className="bg-red-500 hover:bg-red-600"
                                    >
                                      Hapus
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="neon-border bg-card max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Buat Invoice Baru</DialogTitle>
            <DialogDescription>Buat invoice untuk pelanggan</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="invoiceNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>No. Invoice</FormLabel>
                      <FormControl>
                        <Input {...field} className="neon-border-subtle font-mono" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="customerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pelanggan</FormLabel>
                      <Select
                        onValueChange={(value) => field.onChange(value ? Number(value) : undefined)}
                        value={field.value?.toString() || ""}
                      >
                        <FormControl>
                          <SelectTrigger className="neon-border-subtle">
                            <SelectValue placeholder="Pilih pelanggan" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {customers.map((customer) => (
                            <SelectItem key={customer.id} value={customer.id.toString()}>
                              {customer.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="issueDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tanggal Invoice</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} className="neon-border-subtle" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="dueDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Jatuh Tempo</FormLabel>
                      <FormControl>
                        <Input
                          type="date"
                          {...field}
                          value={field.value || ""}
                          className="neon-border-subtle"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <FormLabel>Item</FormLabel>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => append({ description: "", quantity: 1, unitPrice: 0, productId: undefined })}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Tambah Item
                  </Button>
                </div>
                {fields.map((field, index) => (
                  <div key={field.id} className="flex gap-2 items-start">
                    <FormField
                      control={form.control}
                      name={`items.${index}.description`}
                      render={({ field }) => (
                        <FormItem className="flex-1">
                          <FormControl>
                            <Input
                              placeholder="Deskripsi item"
                              {...field}
                              className="neon-border-subtle"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name={`items.${index}.quantity`}
                      render={({ field }) => (
                        <FormItem className="w-20">
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="Qty"
                              {...field}
                              onChange={(e) => field.onChange(Number(e.target.value))}
                              className="neon-border-subtle"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name={`items.${index}.unitPrice`}
                      render={({ field }) => (
                        <FormItem className="w-32">
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="Harga"
                              {...field}
                              onChange={(e) => field.onChange(Number(e.target.value))}
                              className="neon-border-subtle"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => remove(index)}
                      disabled={fields.length === 1}
                    >
                      <Trash2 className="h-4 w-4 text-red-400" />
                    </Button>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="taxRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pajak (%)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number(e.target.value))}
                          className="neon-border-subtle"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="discountRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Diskon (%)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(Number(e.target.value))}
                          className="neon-border-subtle"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="bg-muted/50 p-4 rounded-lg space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                {(watchTaxRate || 0) > 0 && (
                  <div className="flex justify-between text-sm">
                    <span>Pajak ({watchTaxRate}%)</span>
                    <span>{formatCurrency(taxAmount)}</span>
                  </div>
                )}
                {(watchDiscountRate || 0) > 0 && (
                  <div className="flex justify-between text-sm text-red-400">
                    <span>Diskon ({watchDiscountRate}%)</span>
                    <span>-{formatCurrency(discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>Total</span>
                  <span className="text-cyan-400">{formatCurrency(totalAmount)}</span>
                </div>
              </div>

              <FormField
                control={form.control}
                name="terms"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Syarat Pembayaran</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Syarat pembayaran"
                        {...field}
                        value={field.value || ""}
                        className="neon-border-subtle"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Batal
                </Button>
                <Button
                  type="submit"
                  disabled={createInvoiceMutation.isPending}
                  className="neon-border bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400"
                  data-testid="button-submit-invoice"
                >
                  {createInvoiceMutation.isPending ? "Menyimpan..." : "Buat Invoice"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="neon-border bg-card max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span>Invoice {viewingInvoice?.invoiceNumber}</span>
              {viewingInvoice && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => downloadPdf(viewingInvoice)}
                  data-testid="button-download-pdf"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
              )}
            </DialogTitle>
          </DialogHeader>
          {viewingInvoice && (
            <div className="space-y-4">
              <div className="flex justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Tanggal</p>
                  <p className="font-medium">{formatDate(viewingInvoice.issueDate)}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Status</p>
                  <Badge className={statusConfig[viewingInvoice.status].color}>
                    {statusConfig[viewingInvoice.status].label}
                  </Badge>
                </div>
              </div>

              {viewingInvoice.customerId && (
                <div>
                  <p className="text-sm text-muted-foreground">Pelanggan</p>
                  <p className="font-medium">
                    {customers.find((c) => c.id === viewingInvoice.customerId)?.name}
                  </p>
                </div>
              )}

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Item</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Harga</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {viewingInvoice.items?.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.description}</TableCell>
                      <TableCell className="text-right">{item.quantity}</TableCell>
                      <TableCell className="text-right">{formatCurrency(item.unitPrice)}</TableCell>
                      <TableCell className="text-right">{formatCurrency(item.totalPrice)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <div className="bg-muted/50 p-4 rounded-lg space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>{formatCurrency(viewingInvoice.subtotal)}</span>
                </div>
                {viewingInvoice.taxRate > 0 && (
                  <div className="flex justify-between text-sm">
                    <span>Pajak ({viewingInvoice.taxRate}%)</span>
                    <span>{formatCurrency(viewingInvoice.taxAmount)}</span>
                  </div>
                )}
                {viewingInvoice.discountRate > 0 && (
                  <div className="flex justify-between text-sm text-red-400">
                    <span>Diskon ({viewingInvoice.discountRate}%)</span>
                    <span>-{formatCurrency(viewingInvoice.discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>Total</span>
                  <span className="text-cyan-400">{formatCurrency(viewingInvoice.totalAmount)}</span>
                </div>
              </div>

              {viewingInvoice.terms && (
                <div>
                  <p className="text-sm text-muted-foreground">Syarat Pembayaran</p>
                  <p className="text-sm">{viewingInvoice.terms}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
