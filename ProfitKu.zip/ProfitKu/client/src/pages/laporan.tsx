import { useQuery } from "@tanstack/react-query";
import {
  TrendingUp,
  TrendingDown,
  ShoppingBag,
  Wallet,
  Receipt,
  Download,
  FileSpreadsheet,
  FileText,
} from "lucide-react";
import { StatsCard } from "@/components/stats-card";
import { TransactionsTable } from "@/components/transactions-table";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import {
  getCurrentMonthYear,
  getMonthName,
  calculateProfitMargin,
  formatRupiah,
} from "@/lib/utils";
import type { MonthlySummary, Transaction } from "@shared/schema";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export default function Laporan() {
  const { toast } = useToast();
  const { canExport } = useAuth();
  const { month, year } = getCurrentMonthYear();

  const { data: summary, isLoading } = useQuery<MonthlySummary>({
    queryKey: ["/api/summary/monthly", month, year],
  });

  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const profitMargin = calculateProfitMargin(
    summary?.totalProfit || 0,
    summary?.totalRevenue || 0
  );
  const isProfit = (summary?.totalProfit || 0) >= 0;

  const exportToExcel = () => {
    try {
      const exportData = transactions.map((t) => ({
        Tanggal: t.date,
        Produk: t.productName,
        Kategori: t.category || "-",
        Jumlah: t.quantity,
        "Modal/Unit": t.costPrice,
        "Harga Jual/Unit": t.sellingPrice,
        "Biaya Operasional": t.operationalCost,
        "Total Modal": t.quantity * t.costPrice,
        "Total Penjualan": t.quantity * t.sellingPrice,
        Profit: t.profit,
      }));

      const summaryData = [
        {},
        { Produk: "RINGKASAN BULAN INI" },
        { Produk: "Total Penjualan", Profit: summary?.totalRevenue || 0 },
        { Produk: "Total Modal", Profit: summary?.totalCost || 0 },
        { Produk: "Biaya Operasional", Profit: summary?.totalOperational || 0 },
        { Produk: "Total Profit", Profit: summary?.totalProfit || 0 },
        { Produk: "Jumlah Transaksi", Profit: summary?.transactionCount || 0 },
      ];

      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet([...exportData, ...summaryData]);

      const colWidths = [
        { wch: 12 },
        { wch: 25 },
        { wch: 15 },
        { wch: 8 },
        { wch: 15 },
        { wch: 15 },
        { wch: 15 },
        { wch: 15 },
        { wch: 15 },
        { wch: 15 },
      ];
      ws["!cols"] = colWidths;

      XLSX.utils.book_append_sheet(wb, ws, "Laporan");
      XLSX.writeFile(wb, `BisnisKu_Laporan_${getMonthName(month)}_${year}.xlsx`);

      toast({
        title: "Berhasil",
        description: "Laporan Excel berhasil diunduh",
      });
    } catch (error) {
      toast({
        title: "Gagal",
        description: "Tidak dapat mengunduh laporan Excel",
        variant: "destructive",
      });
    }
  };

  const exportToPDF = () => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();

      doc.setFontSize(20);
      doc.text("BisnisKu - Laporan Keuangan", pageWidth / 2, 20, {
        align: "center",
      });

      doc.setFontSize(12);
      doc.text(`Periode: ${getMonthName(month)} ${year}`, pageWidth / 2, 30, {
        align: "center",
      });

      doc.setFontSize(14);
      doc.text("Ringkasan", 14, 45);

      const summaryData = [
        ["Total Penjualan", formatRupiah(summary?.totalRevenue || 0)],
        ["Total Modal", formatRupiah(summary?.totalCost || 0)],
        ["Biaya Operasional", formatRupiah(summary?.totalOperational || 0)],
        ["Total Profit", formatRupiah(summary?.totalProfit || 0)],
        ["Jumlah Transaksi", (summary?.transactionCount || 0).toString()],
        ["Margin Profit", `${profitMargin.toFixed(1)}%`],
      ];

      autoTable(doc, {
        startY: 50,
        head: [["Keterangan", "Nilai"]],
        body: summaryData,
        theme: "grid",
        headStyles: { fillColor: [99, 102, 241] },
        styles: { fontSize: 10 },
      });

      const finalY = (doc as any).lastAutoTable?.finalY || 100;
      doc.setFontSize(14);
      doc.text("Daftar Transaksi", 14, finalY + 15);

      const transactionData = transactions.map((t) => [
        t.date,
        t.productName,
        t.category || "-",
        t.quantity.toString(),
        formatRupiah(t.sellingPrice),
        formatRupiah(t.profit),
      ]);

      autoTable(doc, {
        startY: finalY + 20,
        head: [["Tanggal", "Produk", "Kategori", "Qty", "Harga", "Profit"]],
        body: transactionData,
        theme: "striped",
        headStyles: { fillColor: [99, 102, 241] },
        styles: { fontSize: 8 },
        columnStyles: {
          0: { cellWidth: 25 },
          1: { cellWidth: 45 },
          2: { cellWidth: 25 },
          3: { cellWidth: 15 },
          4: { cellWidth: 30 },
          5: { cellWidth: 30 },
        },
      });

      doc.save(`BisnisKu_Laporan_${getMonthName(month)}_${year}.pdf`);

      toast({
        title: "Berhasil",
        description: "Laporan PDF berhasil diunduh",
      });
    } catch (error) {
      toast({
        title: "Gagal",
        description: "Tidak dapat mengunduh laporan PDF",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Laporan</h1>
          <p className="text-muted-foreground mt-1">
            Ringkasan penjualan {getMonthName(month)} {year}
          </p>
        </div>
        {canExport && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button data-testid="button-export">
                <Download className="h-4 w-4 mr-2" />
                Ekspor Laporan
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={exportToExcel} data-testid="button-export-excel">
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Unduh Excel (.xlsx)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={exportToPDF} data-testid="button-export-pdf">
                <FileText className="h-4 w-4 mr-2" />
                Unduh PDF
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Total Penjualan"
            value={summary?.totalRevenue || 0}
            icon={ShoppingBag}
            trendLabel={`${summary?.transactionCount || 0} transaksi`}
          />
          <StatsCard
            title="Total Modal"
            value={summary?.totalCost || 0}
            icon={Wallet}
          />
          <StatsCard
            title="Biaya Operasional"
            value={summary?.totalOperational || 0}
            icon={Receipt}
          />
          <StatsCard
            title="Profit Bulan Ini"
            value={summary?.totalProfit || 0}
            icon={isProfit ? TrendingUp : TrendingDown}
            trend={profitMargin}
            trendLabel="margin"
            valueClassName={
              isProfit
                ? "text-green-600 dark:text-green-400"
                : "text-red-600 dark:text-red-400"
            }
          />
        </div>
      )}

      <TransactionsTable />
    </div>
  );
}
