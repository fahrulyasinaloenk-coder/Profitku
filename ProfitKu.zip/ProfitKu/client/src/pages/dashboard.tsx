import { useQuery } from "@tanstack/react-query";
import { DailySummary } from "@/components/daily-summary";
import { MonthlyTarget } from "@/components/monthly-target";
import { ProfitChart } from "@/components/profit-chart";
import { TransactionForm } from "@/components/transaction-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { AlertTriangle, Package, Trophy, TrendingUp } from "lucide-react";
import { getCurrentMonthYear, formatRupiah, getMonthName } from "@/lib/utils";
import type { Product, MonthlySummary } from "@shared/schema";

export default function Dashboard() {
  const { month, year } = getCurrentMonthYear();

  const { data: lowStockProducts = [] } = useQuery<Product[]>({
    queryKey: ["/api/products/low-stock"],
  });

  const { data: summary } = useQuery<MonthlySummary>({
    queryKey: ["/api/summary/monthly", month, year],
  });

  const hasLowStock = lowStockProducts.length > 0;
  const targetReached = summary && summary.target > 0 && summary.progressPercentage >= 100;
  const nearTarget = summary && summary.target > 0 && summary.progressPercentage >= 80 && summary.progressPercentage < 100;

  return (
    <div className="space-y-8 p-6 max-w-7xl mx-auto">
      {(hasLowStock || targetReached || nearTarget) && (
        <div className="space-y-3">
          {targetReached && (
            <Alert className="border-green-500 bg-green-50 dark:bg-green-950/50">
              <Trophy className="h-5 w-5 text-green-600 dark:text-green-400" />
              <AlertTitle className="text-green-700 dark:text-green-300">Selamat! Target Tercapai</AlertTitle>
              <AlertDescription className="text-green-600 dark:text-green-400">
                Anda telah mencapai {summary?.progressPercentage.toFixed(0)}% dari target bulan {getMonthName(month)}! 
                Profit: {formatRupiah(summary?.totalProfit || 0)} dari target {formatRupiah(summary?.target || 0)}.
              </AlertDescription>
            </Alert>
          )}

          {nearTarget && !targetReached && (
            <Alert className="border-yellow-500 bg-yellow-50 dark:bg-yellow-950/50">
              <TrendingUp className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
              <AlertTitle className="text-yellow-700 dark:text-yellow-300">Hampir Mencapai Target!</AlertTitle>
              <AlertDescription className="text-yellow-600 dark:text-yellow-400">
                Progress: {summary?.progressPercentage.toFixed(0)}% - Tinggal sedikit lagi! 
                Butuh {formatRupiah((summary?.target || 0) - (summary?.totalProfit || 0))} untuk mencapai target.
              </AlertDescription>
            </Alert>
          )}

          {hasLowStock && (
            <Alert className="border-red-500 bg-red-50 dark:bg-red-950/50">
              <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400" />
              <AlertTitle className="text-red-700 dark:text-red-300">Peringatan Stok Rendah</AlertTitle>
              <AlertDescription className="text-red-600 dark:text-red-400">
                <p className="mb-2">
                  {lowStockProducts.length} produk memiliki stok rendah dan perlu segera diisi ulang:
                </p>
                <div className="flex flex-wrap gap-2">
                  {lowStockProducts.slice(0, 5).map((product) => (
                    <Badge 
                      key={product.id} 
                      variant="outline" 
                      className="border-red-300 text-red-700 dark:border-red-700 dark:text-red-300"
                    >
                      <Package className="h-3 w-3 mr-1" />
                      {product.name} ({product.stock} sisa)
                    </Badge>
                  ))}
                  {lowStockProducts.length > 5 && (
                    <Link href="/stok">
                      <Badge variant="outline" className="cursor-pointer hover-elevate">
                        +{lowStockProducts.length - 5} lainnya
                      </Badge>
                    </Link>
                  )}
                </div>
              </AlertDescription>
            </Alert>
          )}
        </div>
      )}

      <DailySummary />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TransactionForm />
        <MonthlyTarget />
      </div>

      <ProfitChart />
    </div>
  );
}
