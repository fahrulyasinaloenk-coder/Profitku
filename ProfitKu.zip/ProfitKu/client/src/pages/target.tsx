import { MonthlyTarget } from "@/components/monthly-target";
import { ProfitChart } from "@/components/profit-chart";

export default function Target() {
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Target Bulanan</h1>
        <p className="text-muted-foreground mt-1">
          Pantau progress dan capai target profit Anda
        </p>
      </div>
      <MonthlyTarget />
      <ProfitChart />
    </div>
  );
}
