import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, DollarSign, Trash2, Edit, ArrowRightLeft, RefreshCw, TrendingUp } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertExchangeRateSchema, type InsertExchangeRate, type ExchangeRate, type Currency, supportedCurrencies } from "@shared/schema";
import { useState } from "react";
import { z } from "zod";

function formatCurrency(value: number, currency: string = "IDR"): string {
  const currencySymbols: Record<string, string> = {
    IDR: "Rp",
    USD: "$",
    SGD: "S$",
    MYR: "RM",
    EUR: "€",
    JPY: "¥",
    CNY: "¥",
    AUD: "A$",
    GBP: "£",
  };
  
  return new Intl.NumberFormat("id-ID", {
    minimumFractionDigits: currency === "IDR" ? 0 : 2,
    maximumFractionDigits: currency === "IDR" ? 0 : 2,
  }).format(value) + " " + (currencySymbols[currency] || currency);
}

function formatDate(dateString: string | Date | null): string {
  if (!dateString) return "-";
  return new Date(dateString).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

const formSchema = insertExchangeRateSchema.extend({
  rate: z.coerce.number().positive("Kurs harus lebih dari 0"),
  isDefault: z.coerce.number().min(0).max(1).default(1),
});

export default function KursPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingRate, setEditingRate] = useState<ExchangeRate | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [convertAmount, setConvertAmount] = useState<number>(1);
  const [convertFrom, setConvertFrom] = useState<string>("USD");
  const [convertTo, setConvertTo] = useState<string>("IDR");
  const [convertResult, setConvertResult] = useState<number | null>(null);

  const { data: currencies = [], isLoading: loadingCurrencies } = useQuery<Currency[]>({
    queryKey: ["/api/currencies"],
  });

  const { data: exchangeRates = [], isLoading: loadingRates } = useQuery<ExchangeRate[]>({
    queryKey: ["/api/exchange-rates"],
  });

  const form = useForm<InsertExchangeRate>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fromCurrency: "USD",
      toCurrency: "IDR",
      rate: 15500,
      isDefault: 1,
    },
  });

  const editForm = useForm<InsertExchangeRate>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fromCurrency: "USD",
      toCurrency: "IDR",
      rate: 15500,
      isDefault: 1,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertExchangeRate) => {
      const res = await apiRequest("POST", "/api/exchange-rates", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exchange-rates"] });
      toast({ title: "Kurs berhasil ditambahkan" });
      form.reset({
        fromCurrency: "USD",
        toCurrency: "IDR",
        rate: 15500,
        isDefault: 1,
      });
    },
    onError: () => {
      toast({ title: "Gagal menambahkan kurs", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertExchangeRate> }) => {
      const res = await apiRequest("PATCH", `/api/exchange-rates/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exchange-rates"] });
      toast({ title: "Kurs berhasil diperbarui" });
      setIsEditDialogOpen(false);
      setEditingRate(null);
    },
    onError: () => {
      toast({ title: "Gagal memperbarui kurs", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/exchange-rates/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exchange-rates"] });
      toast({ title: "Kurs berhasil dihapus" });
    },
    onError: () => {
      toast({ title: "Gagal menghapus kurs", variant: "destructive" });
    },
  });

  const convertMutation = useMutation({
    mutationFn: async ({ amount, fromCurrency, toCurrency }: { amount: number; fromCurrency: string; toCurrency: string }) => {
      const res = await apiRequest("POST", "/api/convert-currency", { amount, fromCurrency, toCurrency });
      return res.json();
    },
    onSuccess: (data) => {
      setConvertResult(data.convertedAmount);
    },
    onError: () => {
      toast({ title: "Gagal mengkonversi", variant: "destructive" });
    },
  });

  const handleEdit = (rate: ExchangeRate) => {
    setEditingRate(rate);
    editForm.reset({
      fromCurrency: rate.fromCurrency,
      toCurrency: rate.toCurrency,
      rate: rate.rate,
      isDefault: rate.isDefault,
    });
    setIsEditDialogOpen(true);
  };

  const onSubmit = (data: InsertExchangeRate) => {
    createMutation.mutate(data);
  };

  const onEditSubmit = (data: InsertExchangeRate) => {
    if (editingRate) {
      updateMutation.mutate({ id: editingRate.id, data });
    }
  };

  const handleConvert = () => {
    convertMutation.mutate({ amount: convertAmount, fromCurrency: convertFrom, toCurrency: convertTo });
  };

  const isLoading = loadingCurrencies || loadingRates;

  if (isLoading) {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <DollarSign className="h-6 w-6 text-cyan-400" />
          Kurs Mata Uang
        </h1>
        <p className="text-muted-foreground">
          Kelola kurs mata uang asing untuk konversi transaksi
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-cyan-500/30 bg-gradient-to-br from-cyan-500/10 to-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Mata Uang Tersedia
            </CardTitle>
            <DollarSign className="h-4 w-4 text-cyan-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-cyan-400" data-testid="text-total-currencies">
              {currencies.length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-500/30 bg-gradient-to-br from-purple-500/10 to-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Kurs Tersimpan
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-400" data-testid="text-total-rates">
              {exchangeRates.length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-500/30 bg-gradient-to-br from-green-500/10 to-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Kurs Default
            </CardTitle>
            <RefreshCw className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400" data-testid="text-default-rates">
              {exchangeRates.filter(r => r.isDefault === 1).length}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-6">
          <Card className="border-purple-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5 text-purple-400" />
                Tambah Kurs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="fromCurrency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Dari Mata Uang</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-from-currency">
                              <SelectValue placeholder="Pilih mata uang" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {supportedCurrencies.map((code) => (
                              <SelectItem key={code} value={code}>
                                {code}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="toCurrency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ke Mata Uang</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-to-currency">
                              <SelectValue placeholder="Pilih mata uang" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {supportedCurrencies.map((code) => (
                              <SelectItem key={code} value={code}>
                                {code}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="rate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nilai Kurs</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            step="0.0001" 
                            min="0" 
                            {...field} 
                            data-testid="input-rate"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="isDefault"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between">
                        <FormLabel>Jadikan Default</FormLabel>
                        <FormControl>
                          <Switch
                            checked={field.value === 1}
                            onCheckedChange={(checked) => field.onChange(checked ? 1 : 0)}
                            data-testid="switch-default"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500"
                    disabled={createMutation.isPending}
                    data-testid="button-submit"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Tambah Kurs
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card className="border-cyan-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ArrowRightLeft className="h-5 w-5 text-cyan-400" />
                Konversi Mata Uang
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Jumlah</label>
                <Input
                  type="number"
                  value={convertAmount}
                  onChange={(e) => setConvertAmount(parseFloat(e.target.value) || 0)}
                  data-testid="input-convert-amount"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Dari</label>
                  <Select value={convertFrom} onValueChange={setConvertFrom}>
                    <SelectTrigger data-testid="select-convert-from">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {supportedCurrencies.map((code) => (
                        <SelectItem key={code} value={code}>
                          {code}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium">Ke</label>
                  <Select value={convertTo} onValueChange={setConvertTo}>
                    <SelectTrigger data-testid="select-convert-to">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {supportedCurrencies.map((code) => (
                        <SelectItem key={code} value={code}>
                          {code}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                onClick={handleConvert}
                className="w-full"
                disabled={convertMutation.isPending}
                data-testid="button-convert"
              >
                <ArrowRightLeft className="mr-2 h-4 w-4" />
                Konversi
              </Button>

              {convertResult !== null && (
                <div className="p-4 rounded-lg bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/30">
                  <p className="text-sm text-muted-foreground">Hasil Konversi</p>
                  <p className="text-2xl font-bold text-cyan-400" data-testid="text-convert-result">
                    {formatCurrency(convertResult, convertTo)}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatCurrency(convertAmount, convertFrom)} = {formatCurrency(convertResult, convertTo)}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="lg:col-span-2 border-cyan-500/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-cyan-400" />
              Daftar Kurs
            </CardTitle>
            <CardDescription>
              Kurs mata uang yang tersimpan
            </CardDescription>
          </CardHeader>
          <CardContent>
            {exchangeRates.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <DollarSign className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Belum ada kurs tersimpan</p>
                <p className="text-sm">Tambahkan kurs mata uang pertama Anda</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Dari</TableHead>
                      <TableHead>Ke</TableHead>
                      <TableHead className="text-right">Kurs</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Tanggal</TableHead>
                      <TableHead className="text-right">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {exchangeRates.map((rate) => (
                      <TableRow key={rate.id} data-testid={`row-rate-${rate.id}`}>
                        <TableCell>
                          <Badge variant="outline" className="border-cyan-500/30">
                            {rate.fromCurrency}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <ArrowRightLeft className="h-4 w-4 inline mr-2 text-muted-foreground" />
                          <Badge variant="outline" className="border-purple-500/30">
                            {rate.toCurrency}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-mono font-medium">
                          {rate.rate.toLocaleString("id-ID", { maximumFractionDigits: 4 })}
                        </TableCell>
                        <TableCell>
                          {rate.isDefault === 1 ? (
                            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                              Default
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-muted-foreground">
                              Manual
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(rate.validFrom)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => handleEdit(rate)}
                              data-testid={`button-edit-${rate.id}`}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  className="text-red-400 hover:text-red-300"
                                  data-testid={`button-delete-${rate.id}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Hapus Kurs?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Kurs {rate.fromCurrency} → {rate.toCurrency} akan dihapus secara permanen.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Batal</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => deleteMutation.mutate(rate.id)}
                                    className="bg-red-600 hover:bg-red-700"
                                  >
                                    Hapus
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="border-purple-500/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-purple-400" />
            Mata Uang yang Didukung
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {currencies.map((currency) => (
              <Badge
                key={currency.code}
                variant="outline"
                className={`${currency.isActive ? "border-cyan-500/30" : "border-gray-500/30 opacity-50"}`}
                data-testid={`badge-currency-${currency.code}`}
              >
                <span className="font-bold mr-1">{currency.symbol}</span>
                {currency.code} - {currency.name}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Kurs</DialogTitle>
            <DialogDescription>
              Perbarui nilai kurs mata uang
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="fromCurrency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Dari</FormLabel>
                      <FormControl>
                        <Input {...field} disabled data-testid="input-edit-from" />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="toCurrency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ke</FormLabel>
                      <FormControl>
                        <Input {...field} disabled data-testid="input-edit-to" />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={editForm.control}
                name="rate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nilai Kurs</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.0001" 
                        min="0" 
                        {...field} 
                        data-testid="input-edit-rate"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={editForm.control}
                name="isDefault"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between">
                    <FormLabel>Jadikan Default</FormLabel>
                    <FormControl>
                      <Switch
                        checked={field.value === 1}
                        onCheckedChange={(checked) => field.onChange(checked ? 1 : 0)}
                        data-testid="switch-edit-default"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Batal
                </Button>
                <Button
                  type="submit"
                  disabled={updateMutation.isPending}
                  className="bg-gradient-to-r from-cyan-600 to-purple-600"
                  data-testid="button-edit-submit"
                >
                  Simpan
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
