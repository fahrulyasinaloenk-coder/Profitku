import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Home, AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-3.5rem)] p-6">
      <Card className="w-full max-w-md">
        <CardContent className="pt-6 text-center">
          <div className="flex h-16 w-16 mx-auto items-center justify-center rounded-full bg-muted">
            <AlertTriangle className="h-8 w-8 text-muted-foreground" />
          </div>
          <h1 className="mt-6 text-2xl font-bold">Halaman Tidak Ditemukan</h1>
          <p className="mt-2 text-muted-foreground">
            Maaf, halaman yang Anda cari tidak ada atau telah dipindahkan.
          </p>
          <Link href="/">
            <Button className="mt-6" data-testid="button-go-home">
              <Home className="h-4 w-4 mr-2" />
              Kembali ke Dashboard
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
