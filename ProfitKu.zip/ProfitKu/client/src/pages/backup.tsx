import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Download, 
  Upload, 
  Database, 
  History, 
  CheckCircle, 
  XCircle, 
  Clock,
  AlertTriangle,
  FileJson,
  ShieldAlert
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { type BackupLog } from "@shared/schema";

function formatDate(dateString: string | Date | null): string {
  if (!dateString) return "-";
  return new Date(dateString).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatBytes(bytes: number | null): string {
  if (!bytes) return "-";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

const statusConfig: Record<string, { icon: typeof CheckCircle; color: string; label: string }> = {
  pending: { icon: Clock, color: "text-yellow-400", label: "Menunggu" },
  completed: { icon: CheckCircle, color: "text-green-400", label: "Selesai" },
  failed: { icon: XCircle, color: "text-red-400", label: "Gagal" },
};

export default function BackupPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [showRestoreDialog, setShowRestoreDialog] = useState(false);
  const [restoreData, setRestoreData] = useState<any>(null);
  const [restoreFileName, setRestoreFileName] = useState("");

  // RBAC: Only Owner can access backup operations
  if (user?.role !== "owner") {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <Card className="bg-red-500/10 border-red-500/30">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ShieldAlert className="h-16 w-16 text-red-400 mb-4" />
            <h2 className="text-xl font-semibold text-red-400 mb-2">Akses Ditolak</h2>
            <p className="text-muted-foreground text-center max-w-md">
              Halaman ini hanya dapat diakses oleh pemilik toko (Owner).
            </p>
            <Button 
              className="mt-6" 
              variant="outline"
              onClick={() => navigate("/")}
              data-testid="button-back-home"
            >
              Kembali ke Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data: logs = [], isLoading } = useQuery<BackupLog[]>({
    queryKey: ["/api/backup/logs"],
  });

  const backupMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/backup");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/backup/logs"] });
      
      // Download the backup file
      const blob = new Blob([JSON.stringify(data.data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = data.fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Backup Berhasil",
        description: `${data.recordCount} data berhasil di-backup`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Backup Gagal",
        description: error.message || "Terjadi kesalahan saat membuat backup",
        variant: "destructive",
      });
    },
  });

  const restoreMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/backup/restore", { data });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/backup/logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stores"] });
      queryClient.invalidateQueries({ queryKey: ["/api/suppliers"] });
      
      setShowRestoreDialog(false);
      setRestoreData(null);
      setRestoreFileName("");
      
      toast({
        title: "Restore Berhasil",
        description: `${data.recordCount} data berhasil di-restore`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Restore Gagal",
        description: error.message || "Terjadi kesalahan saat restore data",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        setRestoreData(data);
        setRestoreFileName(file.name);
        setShowRestoreDialog(true);
      } catch (error) {
        toast({
          title: "File Tidak Valid",
          description: "File backup tidak dapat dibaca. Pastikan format JSON valid.",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
    
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-cyan-400 neon-text flex items-center gap-2">
            <Database className="h-7 w-7" />
            Backup & Restore
          </h1>
          <p className="text-muted-foreground mt-1">
            Kelola backup dan restore data bisnis Anda
          </p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-gradient-to-br from-cyan-500/10 to-transparent border-cyan-500/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-cyan-400">
              <Download className="h-5 w-5" />
              Backup Data
            </CardTitle>
            <CardDescription>
              Download semua data bisnis Anda dalam format JSON
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-sm text-muted-foreground space-y-2">
              <p>Data yang akan di-backup:</p>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>Transaksi</li>
                <li>Kategori & Produk</li>
                <li>Pelanggan</li>
                <li>Toko</li>
                <li>Pengeluaran</li>
                <li>Pemasok</li>
                <li>Invoice</li>
                <li>Transaksi Berulang</li>
                <li>Kurs Mata Uang</li>
              </ul>
            </div>
            <Button
              className="w-full bg-cyan-600 hover:bg-cyan-700"
              onClick={() => backupMutation.mutate()}
              disabled={backupMutation.isPending}
              data-testid="button-create-backup"
            >
              {backupMutation.isPending ? (
                <>Membuat Backup...</>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" />
                  Buat Backup Sekarang
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500/10 to-transparent border-purple-500/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-400">
              <Upload className="h-5 w-5" />
              Restore Data
            </CardTitle>
            <CardDescription>
              Pulihkan data dari file backup JSON
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-sm text-muted-foreground space-y-2">
              <div className="flex items-start gap-2 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                <AlertTriangle className="h-4 w-4 text-yellow-400 shrink-0 mt-0.5" />
                <p className="text-yellow-400 text-xs">
                  Restore akan menambahkan data baru, bukan menggantikan data yang sudah ada. 
                  Transaksi tidak akan di-restore untuk menghindari duplikasi.
                </p>
              </div>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleFileSelect}
              data-testid="input-restore-file"
            />
            <Button
              variant="outline"
              className="w-full border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
              onClick={() => fileInputRef.current?.click()}
              disabled={restoreMutation.isPending}
              data-testid="button-select-restore-file"
            >
              <FileJson className="h-4 w-4 mr-2" />
              Pilih File Backup
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-[hsl(230,40%,8%)]/80 border-cyan-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-cyan-400" />
            Riwayat Backup & Restore
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : logs.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">
              <History className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>Belum ada riwayat backup atau restore</p>
            </div>
          ) : (
            <div className="rounded-md border border-cyan-500/20 overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="border-cyan-500/20">
                    <TableHead>Tipe</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Tanggal</TableHead>
                    <TableHead>Ukuran</TableHead>
                    <TableHead>Jumlah Data</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((log) => {
                    const status = statusConfig[log.status] || statusConfig.pending;
                    const StatusIcon = status.icon;
                    return (
                      <TableRow key={log.id} className="border-cyan-500/10">
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              log.type === "backup"
                                ? "border-cyan-500/30 text-cyan-400"
                                : "border-purple-500/30 text-purple-400"
                            }
                          >
                            {log.type === "backup" ? "Backup" : "Restore"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className={`flex items-center gap-2 ${status.color}`}>
                            <StatusIcon className="h-4 w-4" />
                            <span className="text-sm">{status.label}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          {formatDate(log.createdAt)}
                        </TableCell>
                        <TableCell className="text-sm">
                          {formatBytes(log.fileSize)}
                        </TableCell>
                        <TableCell className="text-sm">
                          {log.recordCount || "-"}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={showRestoreDialog} onOpenChange={setShowRestoreDialog}>
        <AlertDialogContent className="bg-[hsl(230,40%,10%)] border-cyan-500/30">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-cyan-400">Konfirmasi Restore</AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              <p>Anda akan me-restore data dari file:</p>
              <p className="font-mono text-sm text-purple-400">{restoreFileName}</p>
              {restoreData && (
                <div className="mt-4 p-3 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-sm">
                  <p>Tanggal export: {restoreData.exportedAt ? new Date(restoreData.exportedAt).toLocaleString("id-ID") : "-"}</p>
                  <p className="mt-2">Data yang akan di-restore:</p>
                  <ul className="list-disc list-inside ml-2 text-muted-foreground">
                    <li>Kategori: {restoreData.categories?.length || 0}</li>
                    <li>Produk: {restoreData.products?.length || 0}</li>
                    <li>Pelanggan: {restoreData.customers?.length || 0}</li>
                    <li>Toko: {restoreData.stores?.length || 0}</li>
                    <li>Pemasok: {restoreData.suppliers?.length || 0}</li>
                  </ul>
                </div>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-restore">Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-purple-600 hover:bg-purple-700"
              onClick={() => restoreMutation.mutate(restoreData)}
              disabled={restoreMutation.isPending}
              data-testid="button-confirm-restore"
            >
              {restoreMutation.isPending ? "Memproses..." : "Restore Sekarang"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
