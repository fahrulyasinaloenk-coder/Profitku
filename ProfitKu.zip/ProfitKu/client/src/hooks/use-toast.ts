import { toast as sonnerToast, ExternalToast } from "sonner";

interface ToastProps {
  title?: string;
  description?: string;
  variant?: "default" | "destructive";
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

function toast({ title, description, variant, duration, action }: ToastProps) {
  const options: ExternalToast = {
    description,
    duration: duration || 4000,
  };

  if (action) {
    options.action = {
      label: action.label,
      onClick: action.onClick,
    };
  }

  if (variant === "destructive") {
    return sonnerToast.error(title || "Error", options);
  }
  
  return sonnerToast.success(title || "Success", options);
}

function useToast() {
  return {
    toast,
    dismiss: sonnerToast.dismiss,
  };
}

export { useToast, toast };
