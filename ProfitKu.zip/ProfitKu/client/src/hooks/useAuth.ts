import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export function useAuth() {
  const { data: user, isLoading } = useQuery<User>({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  const isOwner = user?.role === "owner";
  const isKasir = user?.role === "kasir";

  const canDelete = isOwner;
  const canExport = isOwner;
  const canManageUsers = isOwner;

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    role: user?.role || null,
    isOwner,
    isKasir,
    canDelete,
    canExport,
    canManageUsers,
  };
}
