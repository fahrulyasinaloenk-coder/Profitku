import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster as SonnerToaster } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { MobileBottomNav } from "@/components/mobile-bottom-nav";
import { CircuitBackground } from "@/components/circuit-background";
import { NotificationCenter } from "@/components/notification-center";
import { useAuth } from "@/hooks/useAuth";
import { NeonSkeleton } from "@/components/neon-skeleton";
import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import Transaksi from "@/pages/transaksi";
import Kategori from "@/pages/kategori";
import Stok from "@/pages/stok";
import Analitik from "@/pages/analitik";
import Target from "@/pages/target";
import Laporan from "@/pages/laporan";
import Users from "@/pages/users";
import Toko from "@/pages/toko";
import Pelanggan from "@/pages/pelanggan";
import Pengeluaran from "@/pages/pengeluaran";
import Pemasok from "@/pages/pemasok";
import Invoice from "@/pages/invoice";
import Recurring from "@/pages/recurring";
import BulkOperations from "@/pages/bulk-operations";
import Kurs from "@/pages/kurs";
import Backup from "@/pages/backup";
import NotFound from "@/pages/not-found";
import asfLogo from "@assets/IMG_6514_1764421052224.jpeg";

function LoadingSkeleton() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[hsl(230,60%,6%)] relative overflow-hidden">
      <div className="fixed inset-0 z-0 pointer-events-none">
        <CircuitBackground />
      </div>
      <div className="text-center space-y-4 z-10 relative">
        <div className="relative">
          <img 
            src={asfLogo} 
            alt="aSF" 
            className="h-20 w-20 rounded-xl mx-auto animate-pulse shadow-[0_0_30px_rgba(34,211,238,0.4)]" 
          />
          <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-cyan-500/20 to-purple-500/20 animate-pulse" />
        </div>
        <NeonSkeleton className="h-4 w-32 mx-auto" />
        <p className="text-cyan-400 text-sm animate-pulse">Memuat...</p>
      </div>
    </div>
  );
}

function AuthenticatedRouter() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/transaksi" component={Transaksi} />
      <Route path="/kategori" component={Kategori} />
      <Route path="/stok" component={Stok} />
      <Route path="/analitik" component={Analitik} />
      <Route path="/target" component={Target} />
      <Route path="/laporan" component={Laporan} />
      <Route path="/users" component={Users} />
      <Route path="/toko" component={Toko} />
      <Route path="/pelanggan" component={Pelanggan} />
      <Route path="/pengeluaran" component={Pengeluaran} />
      <Route path="/pemasok" component={Pemasok} />
      <Route path="/invoice" component={Invoice} />
      <Route path="/recurring" component={Recurring} />
      <Route path="/bulk" component={BulkOperations} />
      <Route path="/kurs" component={Kurs} />
      <Route path="/backup" component={Backup} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AuthenticatedApp() {
  const { user } = useAuth();
  
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3.5rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="fixed inset-0 z-0 pointer-events-none">
        <CircuitBackground />
      </div>
      <div className="flex min-h-screen w-full relative z-10">
        <div className="hidden md:block">
          <AppSidebar user={user} />
        </div>
        <div className="flex flex-col flex-1 min-w-0">
          <header className="sticky top-0 z-50 flex h-14 items-center justify-between gap-4 border-b border-cyan-500/20 bg-[hsl(230,60%,6%)]/90 backdrop-blur-lg shadow-[0_4px_20px_rgba(34,211,238,0.1)] px-4">
            <SidebarTrigger data-testid="button-sidebar-toggle" className="hidden md:flex" />
            <div className="flex items-center gap-2 md:hidden">
              <img src={asfLogo} alt="aSF" className="h-8 w-8 rounded-lg shadow-[0_0_15px_rgba(34,211,238,0.3)]" />
              <span className="font-bold text-cyan-400 neon-text">aSF</span>
            </div>
            <div className="flex items-center gap-2">
              <NotificationCenter />
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-auto pb-20 md:pb-0">
            <AuthenticatedRouter />
          </main>
        </div>
      </div>
      <MobileBottomNav />
    </SidebarProvider>
  );
}

function AppRouter() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingSkeleton />;
  }

  if (!isAuthenticated) {
    return <Landing />;
  }

  return <AuthenticatedApp />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" storageKey="bisnisKu-theme">
        <TooltipProvider>
          <AppRouter />
          <SonnerToaster
            position="top-right"
            toastOptions={{
              style: {
                background: "hsl(230, 55%, 10%)",
                border: "1px solid rgba(34, 211, 238, 0.3)",
                color: "hsl(180, 100%, 95%)",
                boxShadow: "0 0 20px rgba(34, 211, 238, 0.2)",
              },
              className: "neon-border",
            }}
          />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
