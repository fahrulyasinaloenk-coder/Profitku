import { cn } from "@/lib/utils";

interface NeonSkeletonProps {
  className?: string;
}

export function NeonSkeleton({ className }: NeonSkeletonProps) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-md bg-[hsl(230,55%,12%)]",
        "before:absolute before:inset-0",
        "before:bg-gradient-to-r before:from-transparent before:via-[rgba(34,211,238,0.15)] before:to-transparent",
        "before:animate-[shimmer_2s_infinite]",
        "border border-cyan-500/20",
        "shadow-[0_0_10px_rgba(34,211,238,0.1)]",
        className
      )}
    />
  );
}

export function NeonSkeletonCard({ className }: NeonSkeletonProps) {
  return (
    <div className={cn("space-y-3 p-4 rounded-lg bg-[hsl(230,55%,10%)] border border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.1)]", className)}>
      <NeonSkeleton className="h-4 w-3/4" />
      <NeonSkeleton className="h-8 w-1/2" />
      <NeonSkeleton className="h-3 w-full" />
    </div>
  );
}

export function NeonSkeletonTable({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-2 p-4 rounded-lg bg-[hsl(230,55%,10%)] border border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.1)]">
      <div className="flex gap-4 pb-2 border-b border-cyan-500/20">
        <NeonSkeleton className="h-4 w-1/4" />
        <NeonSkeleton className="h-4 w-1/4" />
        <NeonSkeleton className="h-4 w-1/4" />
        <NeonSkeleton className="h-4 w-1/4" />
      </div>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex gap-4 py-2">
          <NeonSkeleton className="h-4 w-1/4" />
          <NeonSkeleton className="h-4 w-1/4" />
          <NeonSkeleton className="h-4 w-1/4" />
          <NeonSkeleton className="h-4 w-1/4" />
        </div>
      ))}
    </div>
  );
}
