import { useLocation, Link } from "wouter";
import {
  Calculator,
  LayoutDashboard,
  FileText,
  Target,
  Tag,
  Package,
  BarChart3,
  LogOut,
  Users,
  Crown,
  Store,
  UserCircle,
  Receipt,
  Truck,
  RefreshCw,
  FileSpreadsheet,
  DollarSign,
  Database,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { User } from "@shared/schema";
import asfLogo from "@assets/IMG_6514_1764421052224.jpeg";

type NavItem = {
  title: string;
  url: string;
  icon: typeof LayoutDashboard;
  description: string;
  ownerOnly?: boolean;
};

const navigationItems: NavItem[] = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
    description: "Ringkasan harian",
  },
  {
    title: "Transaksi",
    url: "/transaksi",
    icon: Calculator,
    description: "Input transaksi baru",
  },
  {
    title: "Kategori",
    url: "/kategori",
    icon: Tag,
    description: "Kelola kategori produk",
  },
  {
    title: "Stok",
    url: "/stok",
    icon: Package,
    description: "Manajemen stok barang",
  },
  {
    title: "Pelanggan",
    url: "/pelanggan",
    icon: UserCircle,
    description: "Database pelanggan",
  },
  {
    title: "Pengeluaran",
    url: "/pengeluaran",
    icon: Receipt,
    description: "Kelola pengeluaran bisnis",
  },
  {
    title: "Pemasok",
    url: "/pemasok",
    icon: Truck,
    description: "Database pemasok",
  },
  {
    title: "Invoice",
    url: "/invoice",
    icon: FileText,
    description: "Buat & kelola invoice",
  },
  {
    title: "Transaksi Berulang",
    url: "/recurring",
    icon: RefreshCw,
    description: "Kelola transaksi otomatis",
  },
  {
    title: "Operasi Massal",
    url: "/bulk",
    icon: FileSpreadsheet,
    description: "Import/Export data",
    ownerOnly: true,
  },
  {
    title: "Kurs Mata Uang",
    url: "/kurs",
    icon: DollarSign,
    description: "Kelola kurs asing",
  },
  {
    title: "Backup & Restore",
    url: "/backup",
    icon: Database,
    description: "Backup dan restore data",
    ownerOnly: true,
  },
  {
    title: "Analitik",
    url: "/analitik",
    icon: BarChart3,
    description: "Analisis produk & kategori",
  },
  {
    title: "Target",
    url: "/target",
    icon: Target,
    description: "Target bulanan",
  },
  {
    title: "Laporan",
    url: "/laporan",
    icon: FileText,
    description: "Riwayat transaksi",
  },
  {
    title: "Kelola Toko",
    url: "/toko",
    icon: Store,
    description: "Kelola cabang/toko",
    ownerOnly: true,
  },
  {
    title: "Kelola User",
    url: "/users",
    icon: Users,
    description: "Manajemen pengguna",
    ownerOnly: true,
  },
];

interface AppSidebarProps {
  user?: User;
}

export function AppSidebar({ user }: AppSidebarProps) {
  const [location] = useLocation();
  const isOwner = user?.role === "owner";

  const filteredNavItems = navigationItems.filter(
    (item) => !item.ownerOnly || isOwner
  );

  const getInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.firstName) {
      return user.firstName.slice(0, 2).toUpperCase();
    }
    if (user?.email) {
      return user.email.slice(0, 2).toUpperCase();
    }
    return "U";
  };

  const getDisplayName = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    if (user?.firstName) {
      return user.firstName;
    }
    return user?.email || "Pengguna";
  };

  return (
    <Sidebar className="border-r border-cyan-500/20 shadow-[4px_0_20px_rgba(34,211,238,0.1)]">
      <SidebarHeader className="p-4">
        <Link href="/">
          <div className="flex items-center gap-3 hover-elevate rounded-lg p-2 -m-2 cursor-pointer group">
            <img 
              src={asfLogo} 
              alt="aSF" 
              className="h-10 w-10 rounded-lg shadow-[0_0_15px_rgba(34,211,238,0.3)] group-hover:shadow-[0_0_20px_rgba(34,211,238,0.5)] transition-shadow" 
            />
            <div>
              <h1 className="text-lg font-bold tracking-tight bg-gradient-to-r from-cyan-400 to-cyan-300 bg-clip-text text-transparent neon-text">aSF</h1>
              <p className="text-[8px] text-purple-400/70">alung SF</p>
            </div>
          </div>
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {filteredNavItems.map((item) => {
                const isActive = location === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive}
                      tooltip={item.description}
                    >
                      <Link
                        href={item.url}
                        data-testid={`link-nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        <item.icon className="h-5 w-5" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 space-y-4">
        {user && (
          <div className="flex items-center gap-3 p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20">
            <Avatar className="h-9 w-9 ring-2 ring-cyan-500/30">
              <AvatarImage src={user.profileImageUrl || undefined} alt={getDisplayName()} />
              <AvatarFallback className="bg-gradient-to-br from-cyan-500/20 to-purple-500/20 text-cyan-400">{getInitials()}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-sm font-medium truncate text-cyan-100">{getDisplayName()}</p>
                <Badge 
                  variant="outline" 
                  className={`text-[10px] px-1.5 py-0 ${
                    isOwner 
                      ? "border-cyan-500/50 text-cyan-400 bg-cyan-500/10" 
                      : "border-purple-500/50 text-purple-400 bg-purple-500/10"
                  }`}
                >
                  {isOwner ? (
                    <span className="flex items-center gap-1">
                      <Crown className="h-2.5 w-2.5" />
                      Owner
                    </span>
                  ) : (
                    "Kasir"
                  )}
                </Badge>
              </div>
              <p className="text-xs text-cyan-400/60 truncate">{user.email}</p>
            </div>
          </div>
        )}
        <Button
          variant="outline"
          className="w-full justify-start gap-2 border-purple-500/30 text-purple-300 hover:border-purple-500/50 hover:bg-purple-500/10"
          asChild
          data-testid="button-logout"
        >
          <a href="/api/logout">
            <LogOut className="h-4 w-4" />
            Keluar
          </a>
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
