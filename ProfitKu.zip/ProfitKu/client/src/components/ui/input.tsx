import * as React from "react"

import { cn } from "@/lib/utils"

const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<"input">>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-9 w-full rounded-md border bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm transition-all duration-200",
          "border-cyan-500/20 focus-visible:border-cyan-500/50 focus-visible:shadow-[0_0_10px_rgba(34,211,238,0.2)]",
          "dark:bg-[hsl(230,55%,10%)] dark:border-cyan-500/30 dark:focus-visible:border-cyan-500/60 dark:focus-visible:shadow-[0_0_15px_rgba(34,211,238,0.25)]",
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Input.displayName = "Input"

export { Input }
