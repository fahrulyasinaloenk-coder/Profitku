import { cn } from "@/lib/utils"

function Skeleton({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-md bg-[hsl(230,55%,12%)]",
        "before:absolute before:inset-0",
        "before:bg-gradient-to-r before:from-transparent before:via-[rgba(34,211,238,0.1)] before:to-transparent",
        "before:animate-[shimmer_2s_infinite]",
        "border border-cyan-500/10",
        className
      )}
      {...props}
    />
  )
}

export { Skeleton }
