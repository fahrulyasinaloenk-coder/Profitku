import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { TrendingUp, BarChart3, Calendar } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatRupiah, getMonthName, getCurrentMonthYear } from "@/lib/utils";
import type { DailySummary } from "@shared/schema";

interface ChartDataPoint {
  date: string;
  profit: number;
  revenue: number;
  displayDate: string;
}

interface WeeklyDataPoint {
  week: string;
  profit: number;
  revenue: number;
  displayLabel: string;
}

function getWeekOfMonth(date: Date): number {
  const firstDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1);
  const firstDayOfWeek = firstDayOfMonth.getDay();
  const dayOfMonth = date.getDate();
  return Math.ceil((dayOfMonth + firstDayOfWeek) / 7);
}

export function ProfitChart() {
  const { month, year } = getCurrentMonthYear();
  const [viewType, setViewType] = useState<"daily" | "weekly">("daily");

  const { data: dailySummaries = [], isLoading } = useQuery<DailySummary[]>({
    queryKey: ["/api/summary/daily-range", month, year],
  });

  const chartData: ChartDataPoint[] = dailySummaries.map((summary) => {
    const date = new Date(summary.date);
    return {
      date: summary.date,
      profit: summary.totalProfit,
      revenue: summary.totalRevenue,
      displayDate: date.getDate().toString(),
    };
  });

  const weeklyData: WeeklyDataPoint[] = (() => {
    const weekMap = new Map<number, { profit: number; revenue: number }>();
    
    dailySummaries.forEach((summary) => {
      const date = new Date(summary.date);
      const week = getWeekOfMonth(date);
      const existing = weekMap.get(week) || { profit: 0, revenue: 0 };
      existing.profit += summary.totalProfit;
      existing.revenue += summary.totalRevenue;
      weekMap.set(week, existing);
    });

    return Array.from(weekMap.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([week, data]) => ({
        week: `W${week}`,
        profit: data.profit,
        revenue: data.revenue,
        displayLabel: `Minggu ${week}`,
      }));
  })();

  const totalProfit = chartData.reduce((sum, d) => sum + d.profit, 0);
  const avgProfit = chartData.length > 0 ? totalProfit / chartData.length : 0;
  const avgWeeklyProfit = weeklyData.length > 0 
    ? weeklyData.reduce((sum, w) => sum + w.profit, 0) / weeklyData.length 
    : 0;

  if (isLoading) {
    return (
      <Card className="border-card-border">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-xl font-semibold">
            <Skeleton className="h-9 w-9 rounded-lg" />
            <Skeleton className="h-6 w-48" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-card-border">
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2 text-xl font-semibold">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
              <BarChart3 className="h-5 w-5 text-primary" />
            </div>
            Trend Profit {getMonthName(month)}
          </CardTitle>
          <Tabs value={viewType} onValueChange={(v) => setViewType(v as "daily" | "weekly")}>
            <TabsList>
              <TabsTrigger value="daily" className="flex items-center gap-1" data-testid="tab-daily">
                <Calendar className="h-3 w-3" />
                Harian
              </TabsTrigger>
              <TabsTrigger value="weekly" className="flex items-center gap-1" data-testid="tab-weekly">
                <BarChart3 className="h-3 w-3" />
                Mingguan
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        {chartData.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="mt-4 text-lg font-semibold">Belum ada data</h3>
            <p className="mt-2 text-sm text-muted-foreground max-w-xs">
              Grafik akan muncul setelah Anda menambahkan transaksi
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg border p-4">
                <p className="text-sm text-muted-foreground">Total Profit Bulan Ini</p>
                <p className="text-2xl font-bold font-mono tabular-nums text-green-600 dark:text-green-400">
                  {formatRupiah(totalProfit)}
                </p>
              </div>
              <div className="rounded-lg border p-4">
                <p className="text-sm text-muted-foreground">
                  {viewType === "daily" ? "Rata-rata Harian" : "Rata-rata Mingguan"}
                </p>
                <p className="text-2xl font-bold font-mono tabular-nums">
                  {formatRupiah(viewType === "daily" ? avgProfit : avgWeeklyProfit)}
                </p>
              </div>
            </div>

            <div className="h-64">
              {viewType === "daily" ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={chartData}
                    margin={{ top: 5, right: 10, left: 10, bottom: 5 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      className="stroke-muted"
                      vertical={false}
                    />
                    <XAxis
                      dataKey="displayDate"
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                      className="text-muted-foreground"
                    />
                    <YAxis
                      tickFormatter={(value) =>
                        new Intl.NumberFormat("id-ID", {
                          notation: "compact",
                          compactDisplay: "short",
                        }).format(value)
                      }
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                      className="text-muted-foreground"
                      width={60}
                    />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload as ChartDataPoint;
                          return (
                            <div className="rounded-lg border bg-background p-3 shadow-lg">
                              <p className="text-sm text-muted-foreground mb-1">
                                Tanggal {data.displayDate}
                              </p>
                              <p className="font-semibold font-mono">
                                {formatRupiah(data.profit)}
                              </p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="profit"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--primary))", strokeWidth: 0, r: 4 }}
                      activeDot={{ r: 6, strokeWidth: 0 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={weeklyData}
                    margin={{ top: 5, right: 10, left: 10, bottom: 5 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      className="stroke-muted"
                      vertical={false}
                    />
                    <XAxis
                      dataKey="displayLabel"
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                      className="text-muted-foreground"
                    />
                    <YAxis
                      tickFormatter={(value) =>
                        new Intl.NumberFormat("id-ID", {
                          notation: "compact",
                          compactDisplay: "short",
                        }).format(value)
                      }
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                      className="text-muted-foreground"
                      width={60}
                    />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload as WeeklyDataPoint;
                          return (
                            <div className="rounded-lg border bg-background p-3 shadow-lg">
                              <p className="text-sm text-muted-foreground mb-1">
                                {data.displayLabel}
                              </p>
                              <p className="font-semibold font-mono text-green-600 dark:text-green-400">
                                Profit: {formatRupiah(data.profit)}
                              </p>
                              <p className="text-sm font-mono text-muted-foreground">
                                Omzet: {formatRupiah(data.revenue)}
                              </p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Bar
                      dataKey="profit"
                      fill="hsl(var(--primary))"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
