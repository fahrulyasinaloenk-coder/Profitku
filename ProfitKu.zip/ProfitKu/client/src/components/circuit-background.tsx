import { useEffect, useRef } from "react";

export function CircuitBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      life: number;
      maxLife: number;
      color: string;
    }> = [];

    const colors = [
      "rgba(34, 211, 238, 0.6)",
      "rgba(139, 92, 246, 0.5)",
      "rgba(236, 72, 153, 0.4)",
      "rgba(34, 197, 94, 0.5)",
    ];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const createParticle = () => {
      const edge = Math.floor(Math.random() * 4);
      let x, y, vx, vy;

      switch (edge) {
        case 0:
          x = Math.random() * canvas.width;
          y = 0;
          vx = (Math.random() - 0.5) * 0.5;
          vy = Math.random() * 0.3 + 0.1;
          break;
        case 1:
          x = canvas.width;
          y = Math.random() * canvas.height;
          vx = -(Math.random() * 0.3 + 0.1);
          vy = (Math.random() - 0.5) * 0.5;
          break;
        case 2:
          x = Math.random() * canvas.width;
          y = canvas.height;
          vx = (Math.random() - 0.5) * 0.5;
          vy = -(Math.random() * 0.3 + 0.1);
          break;
        default:
          x = 0;
          y = Math.random() * canvas.height;
          vx = Math.random() * 0.3 + 0.1;
          vy = (Math.random() - 0.5) * 0.5;
      }

      return {
        x,
        y,
        vx,
        vy,
        life: 0,
        maxLife: Math.random() * 300 + 200,
        color: colors[Math.floor(Math.random() * colors.length)],
      };
    };

    const drawCircuitLines = () => {
      ctx.strokeStyle = "rgba(34, 211, 238, 0.03)";
      ctx.lineWidth = 1;

      const gridSize = 60;
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      const nodeCount = 15;
      for (let i = 0; i < nodeCount; i++) {
        const x = Math.floor(Math.random() * (canvas.width / gridSize)) * gridSize;
        const y = Math.floor(Math.random() * (canvas.height / gridSize)) * gridSize;
        
        ctx.beginPath();
        ctx.arc(x, y, 2, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(34, 211, 238, 0.1)";
        ctx.fill();
      }
    };

    const animate = () => {
      ctx.fillStyle = "rgba(10, 13, 26, 0.1)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (Math.random() < 0.02 && particles.length < 30) {
        particles.push(createParticle());
      }

      particles = particles.filter((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.life++;

        const alpha = Math.sin((p.life / p.maxLife) * Math.PI) * 0.8;
        
        ctx.beginPath();
        ctx.arc(p.x, p.y, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = p.color.replace(/[\d.]+\)$/, `${alpha})`);
        ctx.fill();

        ctx.beginPath();
        ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = p.color.replace(/[\d.]+\)$/, `${alpha * 0.3})`);
        ctx.fill();

        return p.life < p.maxLife && 
               p.x >= -10 && p.x <= canvas.width + 10 && 
               p.y >= -10 && p.y <= canvas.height + 10;
      });

      animationId = requestAnimationFrame(animate);
    };

    resize();
    drawCircuitLines();
    animate();

    window.addEventListener("resize", resize);

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ opacity: 0.4 }}
    />
  );
}
