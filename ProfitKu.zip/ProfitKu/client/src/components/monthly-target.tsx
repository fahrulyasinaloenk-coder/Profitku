import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Target, Edit2, Check, X, Flag, TrendingUp, Calendar, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CurrencyInput } from "@/components/currency-input";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  cn,
  formatRupiah,
  getMonthName,
  getCurrentMonthYear,
  getDaysRemainingInMonth,
  getCurrentDate,
} from "@/lib/utils";
import type { MonthlySummary } from "@shared/schema";

export function MonthlyTarget() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { month, year } = getCurrentMonthYear();
  const daysRemaining = getDaysRemainingInMonth();
  const today = getCurrentDate();

  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(0);

  const { data: summary, isLoading } = useQuery<MonthlySummary>({
    queryKey: ["/api/summary/monthly", month, year],
  });

  useEffect(() => {
    if (summary?.target) {
      setEditValue(summary.target);
    }
  }, [summary?.target]);

  const updateTargetMutation = useMutation({
    mutationFn: async (targetAmount: number) => {
      const res = await apiRequest("POST", "/api/targets", {
        month,
        year,
        targetAmount,
      });
      return res.json();
    },
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["/api/summary/daily", today] }),
        queryClient.invalidateQueries({ queryKey: ["/api/summary/monthly", month, year] }),
        queryClient.invalidateQueries({ queryKey: ["/api/summary/daily-range", month, year] }),
      ]);
      toast({
        title: "Target berhasil diperbarui",
        description: `Target bulan ${getMonthName(month)}: ${formatRupiah(editValue)}`,
      });
      setIsEditing(false);
    },
    onError: () => {
      toast({
        title: "Gagal memperbarui target",
        description: "Silakan coba lagi",
        variant: "destructive",
      });
    },
  });

  const handleSaveTarget = () => {
    updateTargetMutation.mutate(editValue);
  };

  const handleCancelEdit = () => {
    setEditValue(summary?.target || 0);
    setIsEditing(false);
  };

  const progressPercentage = summary?.progressPercentage || 0;
  const remaining = Math.max(0, (summary?.target || 0) - (summary?.totalProfit || 0));
  const dailyTarget = daysRemaining > 0 ? remaining / daysRemaining : 0;
  const isOnTrack = progressPercentage >= (new Date().getDate() / new Date(year, month, 0).getDate()) * 100;

  if (isLoading) {
    return (
      <Card className="border-card-border">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-xl font-semibold">
            <Skeleton className="h-9 w-9 rounded-lg" />
            <Skeleton className="h-6 w-40" />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <Skeleton className="h-4 w-full rounded-full" />
          <div className="grid grid-cols-2 gap-4">
            <Skeleton className="h-20 rounded-lg" />
            <Skeleton className="h-20 rounded-lg" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-card-border">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <CardTitle className="flex items-center gap-2 text-xl font-semibold">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
              <Target className="h-5 w-5 text-primary" />
            </div>
            Target {getMonthName(month)} {year}
          </CardTitle>
          {!isEditing ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsEditing(true)}
              data-testid="button-edit-target"
            >
              <Edit2 className="h-4 w-4 mr-1.5" />
              Ubah Target
            </Button>
          ) : (
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleCancelEdit}
                data-testid="button-cancel-target"
              >
                <X className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                onClick={handleSaveTarget}
                disabled={updateTargetMutation.isPending}
                data-testid="button-save-target"
              >
                <Check className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {isEditing ? (
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">
              Target Profit Bulanan
            </label>
            <CurrencyInput
              value={editValue}
              onChange={setEditValue}
              data-testid="input-monthly-target"
            />
          </div>
        ) : (
          <>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-medium">
                  {formatRupiah(summary?.totalProfit || 0)} / {formatRupiah(summary?.target || 0)}
                </span>
              </div>
              <div className="relative">
                <Progress
                  value={Math.min(progressPercentage, 100)}
                  className="h-4"
                  data-testid="progress-monthly-target"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xs font-bold text-primary-foreground drop-shadow-sm">
                    {progressPercentage.toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg border p-4 space-y-1">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Flag className="h-4 w-4" />
                  <span className="text-xs font-medium">Sisa Target</span>
                </div>
                <p
                  className={cn(
                    "text-lg font-bold font-mono tabular-nums",
                    remaining > 0 ? "text-foreground" : "text-green-600 dark:text-green-400"
                  )}
                  data-testid="text-remaining-target"
                >
                  {remaining > 0 ? formatRupiah(remaining) : "Tercapai!"}
                </p>
              </div>

              <div className="rounded-lg border p-4 space-y-1">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span className="text-xs font-medium">Sisa Hari</span>
                </div>
                <p className="text-lg font-bold" data-testid="text-days-remaining">
                  {daysRemaining} hari
                </p>
              </div>
            </div>

            {remaining > 0 && daysRemaining > 0 && (
              <div
                className={cn(
                  "rounded-lg p-4 flex items-center gap-4",
                  isOnTrack
                    ? "bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800"
                    : "bg-yellow-50 dark:bg-yellow-950/30 border border-yellow-200 dark:border-yellow-800"
                )}
              >
                <div
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-full",
                    isOnTrack
                      ? "bg-green-100 dark:bg-green-900/50 text-green-600 dark:text-green-400"
                      : "bg-yellow-100 dark:bg-yellow-900/50 text-yellow-600 dark:text-yellow-400"
                  )}
                >
                  <TrendingUp className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">
                    Target harian yang dibutuhkan
                  </p>
                  <p className="text-lg font-bold font-mono tabular-nums">
                    {formatRupiah(dailyTarget)}
                    <span className="text-sm font-normal text-muted-foreground"> /hari</span>
                  </p>
                </div>
              </div>
            )}

            {remaining <= 0 && (
              <div className="rounded-lg p-4 bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 text-center">
                <div className="flex items-center justify-center gap-2 text-green-600 dark:text-green-400">
                  <Check className="h-5 w-5" />
                  <span className="font-semibold">Selamat! Target bulan ini tercapai!</span>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
