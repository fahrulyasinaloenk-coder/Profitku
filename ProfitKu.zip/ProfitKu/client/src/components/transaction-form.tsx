import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Calculator, Package, Hash, Coins, DollarSign, Truck, Tag, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CurrencyInput } from "@/components/currency-input";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { insertTransactionSchema, type InsertTransaction, type Category } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { cn, formatRupiah, calculateProfit, calculateProfitMargin, getCurrentDate, getCurrentMonthYear } from "@/lib/utils";

const paymentMethods = [
  { value: "cash", label: "Tunai (Cash)" },
  { value: "transfer", label: "Transfer Bank" },
  { value: "ewallet", label: "E-Wallet (GoPay, OVO, dll)" },
];

export function TransactionForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [calculatedProfit, setCalculatedProfit] = useState(0);
  const [profitMargin, setProfitMargin] = useState(0);
  const { month, year } = getCurrentMonthYear();
  const today = getCurrentDate();

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const form = useForm<InsertTransaction>({
    resolver: zodResolver(insertTransactionSchema),
    defaultValues: {
      productName: "",
      quantity: 1,
      costPrice: 0,
      sellingPrice: 0,
      operationalCost: 0,
      date: getCurrentDate(),
      category: null,
      paymentMethod: "cash",
    },
  });

  const watchedValues = form.watch(["quantity", "costPrice", "sellingPrice", "operationalCost"]);

  useEffect(() => {
    const [quantity, costPrice, sellingPrice, operationalCost] = watchedValues;
    const profit = calculateProfit(quantity || 0, costPrice || 0, sellingPrice || 0, operationalCost || 0);
    const revenue = (quantity || 0) * (sellingPrice || 0);
    const margin = calculateProfitMargin(profit, revenue);
    setCalculatedProfit(profit);
    setProfitMargin(margin);
  }, [watchedValues]);

  const createTransactionMutation = useMutation({
    mutationFn: async (data: InsertTransaction) => {
      const res = await apiRequest("POST", "/api/transactions", data);
      return res.json();
    },
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["/api/transactions"] }),
        queryClient.invalidateQueries({ queryKey: ["/api/summary/daily", today] }),
        queryClient.invalidateQueries({ queryKey: ["/api/summary/monthly", month, year] }),
        queryClient.invalidateQueries({ queryKey: ["/api/summary/daily-range", month, year] }),
        queryClient.invalidateQueries({ queryKey: ["/api/analytics/payment-methods", month, year] }),
      ]);
      toast({
        title: "Transaksi berhasil ditambahkan",
        description: `Profit: ${formatRupiah(calculatedProfit)}`,
      });
      form.reset({
        productName: "",
        quantity: 1,
        costPrice: 0,
        sellingPrice: 0,
        operationalCost: 0,
        date: getCurrentDate(),
        category: null,
        paymentMethod: "cash",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Sesi berakhir",
          description: "Silakan login kembali...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Gagal menambahkan transaksi",
        description: "Silakan coba lagi",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertTransaction) => {
    createTransactionMutation.mutate(data);
  };

  const isProfit = calculatedProfit >= 0;

  return (
    <Card className="border-card-border">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-xl font-semibold">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
            <Plus className="h-5 w-5 text-primary" />
          </div>
          Tambah Transaksi
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="productName"
                render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-muted-foreground" />
                      Nama Produk
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Contoh: Kaos Polos Hitam"
                        data-testid="input-product-name"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Tag className="h-4 w-4 text-muted-foreground" />
                      Kategori
                    </FormLabel>
                    <Select
                      value={field.value || ""}
                      onValueChange={(value) => field.onChange(value || null)}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-category">
                          <SelectValue placeholder="Pilih kategori" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat.id} value={cat.name}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="paymentMethod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Wallet className="h-4 w-4 text-muted-foreground" />
                      Metode Pembayaran
                    </FormLabel>
                    <Select
                      value={field.value || "cash"}
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-payment-method">
                          <SelectValue placeholder="Pilih metode" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {paymentMethods.map((method) => (
                          <SelectItem key={method.value} value={method.value}>
                            {method.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Hash className="h-4 w-4 text-muted-foreground" />
                      Jumlah
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min={1}
                        data-testid="input-quantity"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tanggal</FormLabel>
                    <FormControl>
                      <Input
                        type="date"
                        data-testid="input-date"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="costPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Coins className="h-4 w-4 text-muted-foreground" />
                      Modal per Unit
                    </FormLabel>
                    <FormControl>
                      <CurrencyInput
                        value={field.value}
                        onChange={field.onChange}
                        data-testid="input-cost-price"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="sellingPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      Harga Jual per Unit
                    </FormLabel>
                    <FormControl>
                      <CurrencyInput
                        value={field.value}
                        onChange={field.onChange}
                        data-testid="input-selling-price"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="operationalCost"
                render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel className="flex items-center gap-2">
                      <Truck className="h-4 w-4 text-muted-foreground" />
                      Biaya Operasional (ongkir, packing, dll)
                    </FormLabel>
                    <FormControl>
                      <CurrencyInput
                        value={field.value}
                        onChange={field.onChange}
                        data-testid="input-operational-cost"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="rounded-lg border border-dashed p-4 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Total Modal:</span>
                <span className="font-mono font-medium">
                  {formatRupiah((form.watch("quantity") || 0) * (form.watch("costPrice") || 0))}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Total Penjualan:</span>
                <span className="font-mono font-medium">
                  {formatRupiah((form.watch("quantity") || 0) * (form.watch("sellingPrice") || 0))}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Biaya Operasional:</span>
                <span className="font-mono font-medium">
                  {formatRupiah(form.watch("operationalCost") || 0)}
                </span>
              </div>
              <div className="border-t pt-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <span className="font-semibold">Profit:</span>
                </div>
                <div className="text-right">
                  <span
                    className={cn(
                      "text-2xl font-bold font-mono tabular-nums",
                      isProfit ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"
                    )}
                    data-testid="text-calculated-profit"
                  >
                    {formatRupiah(calculatedProfit)}
                  </span>
                  <p className={cn(
                    "text-sm",
                    isProfit ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"
                  )}>
                    Margin: {profitMargin.toFixed(1)}%
                  </p>
                </div>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full"
              size="lg"
              disabled={createTransactionMutation.isPending}
              data-testid="button-submit-transaction"
            >
              {createTransactionMutation.isPending ? (
                <span className="flex items-center gap-2">
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                  Menyimpan...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Plus className="h-5 w-5" />
                  Simpan Transaksi
                </span>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
