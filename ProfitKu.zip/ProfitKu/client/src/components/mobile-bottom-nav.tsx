import { useLocation, Link } from "wouter";
import {
  LayoutDashboard,
  Calculator,
  BarChart3,
  FileText,
  Menu,
  Tag,
  Package,
  Target,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const mainNavItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Transaksi", url: "/transaksi", icon: Calculator },
  { title: "Analitik", url: "/analitik", icon: BarChart3 },
  { title: "Laporan", url: "/laporan", icon: FileText },
];

const moreNavItems = [
  { title: "Kategori", url: "/kategori", icon: Tag },
  { title: "Stok", url: "/stok", icon: Package },
  { title: "Target", url: "/target", icon: Target },
];

export function MobileBottomNav() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden">
      <div className="bg-[hsl(230,60%,6%)]/95 backdrop-blur-lg border-t border-cyan-500/30 shadow-[0_-4px_20px_rgba(34,211,238,0.15)]">
        <div className="flex items-center justify-around px-2 py-2 pb-[max(0.5rem,env(safe-area-inset-bottom))]">
          {mainNavItems.map((item) => {
            const isActive = location === item.url;
            return (
              <Link key={item.title} href={item.url} asChild>
                <a
                  className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all ${
                    isActive
                      ? "text-cyan-400 bg-cyan-500/10"
                      : "text-gray-400 hover:text-cyan-300"
                  }`}
                  data-testid={`nav-mobile-${item.title.toLowerCase()}`}
                >
                  <item.icon
                    className={`h-5 w-5 ${
                      isActive ? "drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]" : ""
                    }`}
                  />
                  <span className="text-[10px] font-medium">{item.title}</span>
                </a>
              </Link>
            );
          })}
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                className="flex flex-col items-center gap-1 px-3 py-2 rounded-lg text-gray-400 hover:text-cyan-300 transition-all"
                data-testid="nav-mobile-more"
              >
                <Menu className="h-5 w-5" />
                <span className="text-[10px] font-medium">Lainnya</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="end"
              side="top"
              sideOffset={8}
              className="bg-[hsl(230,55%,10%)] border-cyan-500/30 shadow-[0_0_20px_rgba(34,211,238,0.2)] z-[60]"
            >
              {moreNavItems.map((item) => (
                <DropdownMenuItem key={item.title} asChild className="cursor-pointer">
                  <Link href={item.url} asChild>
                    <a
                      className={`flex items-center gap-2 w-full px-2 py-1.5 ${
                        location === item.url ? "text-cyan-400" : "text-gray-300"
                      }`}
                      data-testid={`nav-mobile-${item.title.toLowerCase()}`}
                    >
                      <item.icon className="h-4 w-4" />
                      {item.title}
                    </a>
                  </Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}
