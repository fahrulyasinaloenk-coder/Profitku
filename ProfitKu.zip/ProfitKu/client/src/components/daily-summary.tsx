import { useQuery } from "@tanstack/react-query";
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  ShoppingBag,
  Receipt,
  BadgePercent,
} from "lucide-react";
import { StatsCard } from "@/components/stats-card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatRupiah, calculateProfitMargin, getCurrentDate, formatDate } from "@/lib/utils";
import type { DailySummary as DailySummaryType } from "@shared/schema";

export function DailySummary() {
  const today = getCurrentDate();

  const { data: summary, isLoading } = useQuery<DailySummaryType>({
    queryKey: ["/api/summary/daily", today],
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-6 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  const profitMargin = calculateProfitMargin(
    summary?.totalProfit || 0,
    summary?.totalRevenue || 0
  );

  const isProfit = (summary?.totalProfit || 0) >= 0;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <h2 className="text-2xl font-bold">Ringkasan Hari Ini</h2>
        <p className="text-sm text-muted-foreground">{formatDate(today)}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Penjualan"
          value={summary?.totalRevenue || 0}
          icon={ShoppingBag}
          trendLabel={`${summary?.transactionCount || 0} transaksi`}
        />

        <StatsCard
          title="Total Modal"
          value={summary?.totalCost || 0}
          icon={Wallet}
        />

        <StatsCard
          title="Biaya Operasional"
          value={summary?.totalOperational || 0}
          icon={Receipt}
        />

        <StatsCard
          title="Profit Hari Ini"
          value={summary?.totalProfit || 0}
          icon={isProfit ? TrendingUp : TrendingDown}
          trend={profitMargin}
          trendLabel="margin"
          valueClassName={
            isProfit
              ? "text-green-600 dark:text-green-400"
              : "text-red-600 dark:text-red-400"
          }
        />
      </div>
    </div>
  );
}
