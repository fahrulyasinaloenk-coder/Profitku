import { Card, CardContent } from "@/components/ui/card";
import { cn, formatRupiah } from "@/lib/utils";
import { LucideIcon, TrendingUp, TrendingDown, Minus } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  trend?: number;
  trendLabel?: string;
  isCurrency?: boolean;
  className?: string;
  valueClassName?: string;
}

export function StatsCard({
  title,
  value,
  icon: Icon,
  trend,
  trendLabel,
  isCurrency = true,
  className,
  valueClassName,
}: StatsCardProps) {
  const isPositive = trend !== undefined && trend > 0;
  const isNegative = trend !== undefined && trend < 0;
  const isNeutral = trend === undefined || trend === 0;

  const TrendIcon = isPositive ? TrendingUp : isNegative ? TrendingDown : Minus;

  return (
    <Card className={cn("hover-elevate transition-all duration-200", className)}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-muted-foreground truncate">
              {title}
            </p>
            <p
              className={cn(
                "mt-2 text-2xl font-bold tabular-nums tracking-tight",
                valueClassName
              )}
              data-testid={`text-stats-${title.toLowerCase().replace(/\s+/g, "-")}`}
            >
              {isCurrency ? formatRupiah(value) : value.toLocaleString("id-ID")}
            </p>
            {trend !== undefined && (
              <div className="mt-2 flex items-center gap-1.5">
                <div
                  className={cn(
                    "flex items-center gap-1 text-xs font-medium",
                    isPositive && "text-green-600 dark:text-green-400",
                    isNegative && "text-red-600 dark:text-red-400",
                    isNeutral && "text-muted-foreground"
                  )}
                >
                  <TrendIcon className="h-3.5 w-3.5" />
                  <span>{Math.abs(trend).toFixed(1)}%</span>
                </div>
                {trendLabel && (
                  <span className="text-xs text-muted-foreground">
                    {trendLabel}
                  </span>
                )}
              </div>
            )}
          </div>
          <div
            className={cn(
              "flex h-12 w-12 shrink-0 items-center justify-center rounded-lg",
              "bg-primary/10 text-primary"
            )}
          >
            <Icon className="h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
