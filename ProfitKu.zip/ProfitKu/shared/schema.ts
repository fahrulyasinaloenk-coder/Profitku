import { pgTable, text, integer, real, serial, varchar, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User roles
export const userRoles = ["owner", "kasir"] as const;
export type UserRole = typeof userRoles[number];

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").$type<UserRole>().notNull().default("kasir"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// User role check helper
export const isOwner = (user: User | null | undefined): boolean => {
  return user?.role === "owner";
};

export const isKasir = (user: User | null | undefined): boolean => {
  return user?.role === "kasir";
};

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  productName: text("product_name").notNull(),
  quantity: integer("quantity").notNull(),
  costPrice: real("cost_price").notNull(),
  sellingPrice: real("selling_price").notNull(),
  operationalCost: real("operational_cost").notNull().default(0),
  profit: real("profit").notNull(),
  date: text("date").notNull(),
  category: text("category"),
  paymentMethod: text("payment_method").default("cash"),
});

export const monthlyTargets = pgTable("monthly_targets", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  targetAmount: real("target_amount").notNull(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#6366f1"),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  categoryId: integer("category_id"),
  costPrice: real("cost_price").notNull().default(0),
  sellingPrice: real("selling_price").notNull().default(0),
  stock: integer("stock").notNull().default(0),
  minStock: integer("min_stock").notNull().default(5),
});

// ========== NEW TABLES ==========

// Toko (Store) table - multi-store support
export const stores = pgTable("stores", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(), // owner of the store
  name: text("name").notNull(),
  address: text("address"),
  phone: varchar("phone"),
  description: text("description"),
  isActive: integer("is_active").notNull().default(1), // 1 = active, 0 = inactive
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Pelanggan (Customer) table
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(), // owner of customer data
  storeId: integer("store_id"), // optional: link to specific store
  name: text("name").notNull(),
  phone: varchar("phone"),
  email: varchar("email"),
  address: text("address"),
  notes: text("notes"),
  totalTransactions: integer("total_transactions").notNull().default(0),
  totalSpent: real("total_spent").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Audit Log table - track all important actions
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(), // who performed the action
  action: varchar("action").notNull(), // create, update, delete
  entityType: varchar("entity_type").notNull(), // transaction, product, category, etc.
  entityId: varchar("entity_id"), // ID of affected entity
  oldData: jsonb("old_data"), // previous state (for updates/deletes)
  newData: jsonb("new_data"), // new state (for creates/updates)
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Subscription plans
export const subscriptionPlans = ["free", "basic", "pro", "enterprise"] as const;
export type SubscriptionPlan = typeof subscriptionPlans[number];

// Subscription status
export const subscriptionStatuses = ["active", "expired", "cancelled", "trial"] as const;
export type SubscriptionStatus = typeof subscriptionStatuses[number];

// Subscription table
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().unique(), // one subscription per user
  plan: varchar("plan").$type<SubscriptionPlan>().notNull().default("free"),
  status: varchar("status").$type<SubscriptionStatus>().notNull().default("trial"),
  startDate: timestamp("start_date").defaultNow(),
  endDate: timestamp("end_date"),
  trialEndsAt: timestamp("trial_ends_at"),
  maxStores: integer("max_stores").notNull().default(1), // limit based on plan
  maxProducts: integer("max_products").notNull().default(50), // limit based on plan
  maxTransactionsPerMonth: integer("max_transactions_per_month").notNull().default(100),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({ 
  id: true,
  profit: true,
  userId: true,
}).extend({
  productName: z.string().min(1, "Nama produk wajib diisi"),
  quantity: z.number().min(1, "Jumlah minimal 1"),
  costPrice: z.number().min(0, "Modal tidak boleh negatif"),
  sellingPrice: z.number().min(0, "Harga jual tidak boleh negatif"),
  operationalCost: z.number().min(0, "Biaya operasional tidak boleh negatif").default(0),
  date: z.string().optional(),
  category: z.string().optional().nullable(),
  paymentMethod: z.enum(["cash", "transfer", "ewallet"]).default("cash"),
});

export const insertMonthlyTargetSchema = createInsertSchema(monthlyTargets).omit({ id: true, userId: true }).extend({
  month: z.number().min(1).max(12),
  year: z.number().min(2020).max(2100),
  targetAmount: z.number().min(0, "Target tidak boleh negatif"),
});

export const insertCategorySchema = createInsertSchema(categories).omit({ id: true, userId: true }).extend({
  name: z.string().min(1, "Nama kategori wajib diisi"),
  color: z.string().default("#6366f1"),
});

export const insertProductSchema = createInsertSchema(products).omit({ id: true, userId: true }).extend({
  name: z.string().min(1, "Nama produk wajib diisi"),
  categoryId: z.number().optional().nullable(),
  costPrice: z.number().min(0, "Modal tidak boleh negatif").default(0),
  sellingPrice: z.number().min(0, "Harga jual tidak boleh negatif").default(0),
  stock: z.number().min(0, "Stok tidak boleh negatif").default(0),
  minStock: z.number().min(0, "Stok minimum tidak boleh negatif").default(5),
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

export type InsertMonthlyTarget = z.infer<typeof insertMonthlyTargetSchema>;
export type MonthlyTarget = typeof monthlyTargets.$inferSelect;

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

// ========== NEW TABLE SCHEMAS ==========

// Store schemas
export const insertStoreSchema = createInsertSchema(stores).omit({ 
  id: true, 
  userId: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  name: z.string().min(1, "Nama toko wajib diisi"),
  address: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  description: z.string().optional().nullable(),
  isActive: z.number().default(1),
});

export type InsertStore = z.infer<typeof insertStoreSchema>;
export type Store = typeof stores.$inferSelect;

// Customer schemas
export const insertCustomerSchema = createInsertSchema(customers).omit({ 
  id: true, 
  userId: true,
  totalTransactions: true,
  totalSpent: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  name: z.string().min(1, "Nama pelanggan wajib diisi"),
  storeId: z.number().optional().nullable(),
  phone: z.string().optional().nullable(),
  email: z.string().email("Email tidak valid").optional().nullable(),
  address: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

// Audit Log schemas
export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ 
  id: true, 
  createdAt: true,
}).extend({
  userId: z.string(),
  action: z.enum(["create", "update", "delete"]),
  entityType: z.string(),
  entityId: z.string().optional().nullable(),
  oldData: z.any().optional().nullable(),
  newData: z.any().optional().nullable(),
  ipAddress: z.string().optional().nullable(),
  userAgent: z.string().optional().nullable(),
});

export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;

// Subscription schemas
export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({ 
  id: true, 
  createdAt: true,
  updatedAt: true,
}).extend({
  userId: z.string(),
  plan: z.enum(subscriptionPlans).optional().default("free"),
  status: z.enum(subscriptionStatuses).optional().default("trial"),
  startDate: z.date().optional(),
  endDate: z.date().optional().nullable(),
  trialEndsAt: z.date().optional().nullable(),
  maxStores: z.number().optional().default(1),
  maxProducts: z.number().optional().default(50),
  maxTransactionsPerMonth: z.number().optional().default(100),
});

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

export type DailySummary = {
  date: string;
  totalRevenue: number;
  totalCost: number;
  totalOperational: number;
  totalProfit: number;
  transactionCount: number;
};

export type MonthlySummary = {
  month: number;
  year: number;
  totalRevenue: number;
  totalCost: number;
  totalOperational: number;
  totalProfit: number;
  transactionCount: number;
  target: number;
  progressPercentage: number;
};

export type CategorySummary = {
  category: string;
  totalRevenue: number;
  totalProfit: number;
  transactionCount: number;
  productCount: number;
};

export type ProductSummary = {
  productName: string;
  category: string | null;
  totalQuantity: number;
  totalRevenue: number;
  totalProfit: number;
  transactionCount: number;
};

export type PaymentMethodSummary = {
  method: string;
  totalRevenue: number;
  transactionCount: number;
};

// ========== EXPENSE TRACKING TABLES ==========

// Expense Categories table
export const expenseCategories = pgTable("expense_categories", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#ef4444"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Expenses table
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  storeId: integer("store_id"), // optional: link to specific store
  categoryId: integer("category_id"), // link to expense_categories
  description: text("description").notNull(),
  amount: real("amount").notNull(),
  date: text("date").notNull(),
  paymentMethod: text("payment_method").default("cash"),
  receipt: text("receipt"), // optional: receipt image URL or reference
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ========== SUPPLIER MANAGEMENT TABLES ==========

// Suppliers table
export const suppliers = pgTable("suppliers", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  contactPerson: text("contact_person"),
  phone: varchar("phone"),
  email: varchar("email"),
  address: text("address"),
  paymentTerms: text("payment_terms"), // e.g., "Net 30", "COD"
  notes: text("notes"),
  isActive: integer("is_active").notNull().default(1), // 1 = active, 0 = inactive
  totalPurchases: real("total_purchases").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ========== INVOICE TABLES ==========

// Invoice statuses
export const invoiceStatuses = ["draft", "sent", "paid", "overdue", "cancelled"] as const;
export type InvoiceStatus = typeof invoiceStatuses[number];

// Invoices table
export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  storeId: integer("store_id"), // optional: link to store
  customerId: integer("customer_id"), // link to customer
  invoiceNumber: varchar("invoice_number").notNull(), // e.g., "INV-2025-001"
  status: varchar("status").$type<InvoiceStatus>().notNull().default("draft"),
  issueDate: text("issue_date").notNull(),
  dueDate: text("due_date"),
  subtotal: real("subtotal").notNull().default(0),
  taxRate: real("tax_rate").notNull().default(0), // percentage
  taxAmount: real("tax_amount").notNull().default(0),
  discountRate: real("discount_rate").notNull().default(0), // percentage
  discountAmount: real("discount_amount").notNull().default(0),
  totalAmount: real("total_amount").notNull().default(0),
  notes: text("notes"),
  terms: text("terms"), // payment terms
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Invoice Items table
export const invoiceItems = pgTable("invoice_items", {
  id: serial("id").primaryKey(),
  invoiceId: integer("invoice_id").notNull(), // link to invoice
  productId: integer("product_id"), // optional: link to product
  description: text("description").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: real("unit_price").notNull(),
  totalPrice: real("total_price").notNull(),
});

// ========== EXPENSE SCHEMAS ==========

export const insertExpenseCategorySchema = createInsertSchema(expenseCategories).omit({ 
  id: true, 
  userId: true,
  createdAt: true,
}).extend({
  name: z.string().min(1, "Nama kategori wajib diisi"),
  color: z.string().default("#ef4444"),
  description: z.string().optional().nullable(),
});

export type InsertExpenseCategory = z.infer<typeof insertExpenseCategorySchema>;
export type ExpenseCategory = typeof expenseCategories.$inferSelect;

export const insertExpenseSchema = createInsertSchema(expenses).omit({ 
  id: true, 
  userId: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  storeId: z.number().optional().nullable(),
  categoryId: z.number().optional().nullable(),
  description: z.string().min(1, "Deskripsi pengeluaran wajib diisi"),
  amount: z.number().min(0, "Jumlah tidak boleh negatif"),
  date: z.string().optional(),
  paymentMethod: z.enum(["cash", "transfer", "ewallet"]).default("cash"),
  receipt: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;

// ========== SUPPLIER SCHEMAS ==========

export const insertSupplierSchema = createInsertSchema(suppliers).omit({ 
  id: true, 
  userId: true,
  totalPurchases: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  name: z.string().min(1, "Nama pemasok wajib diisi"),
  contactPerson: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  email: z.string().email("Email tidak valid").optional().nullable().or(z.literal("")),
  address: z.string().optional().nullable(),
  paymentTerms: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
  isActive: z.number().default(1),
});

export type InsertSupplier = z.infer<typeof insertSupplierSchema>;
export type Supplier = typeof suppliers.$inferSelect;

// ========== INVOICE SCHEMAS ==========

export const insertInvoiceSchema = createInsertSchema(invoices).omit({ 
  id: true, 
  userId: true,
  subtotal: true,
  taxAmount: true,
  discountAmount: true,
  totalAmount: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  storeId: z.number().optional().nullable(),
  customerId: z.number().optional().nullable(),
  invoiceNumber: z.string().min(1, "Nomor invoice wajib diisi"),
  status: z.enum(invoiceStatuses).default("draft"),
  issueDate: z.string().optional(),
  dueDate: z.string().optional().nullable(),
  taxRate: z.number().min(0).max(100).default(0),
  discountRate: z.number().min(0).max(100).default(0),
  notes: z.string().optional().nullable(),
  terms: z.string().optional().nullable(),
});

export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;

export const insertInvoiceItemSchema = createInsertSchema(invoiceItems).omit({ 
  id: true, 
  totalPrice: true,
}).extend({
  invoiceId: z.number(),
  productId: z.number().optional().nullable(),
  description: z.string().min(1, "Deskripsi item wajib diisi"),
  quantity: z.number().min(1, "Jumlah minimal 1"),
  unitPrice: z.number().min(0, "Harga tidak boleh negatif"),
});

export type InsertInvoiceItem = z.infer<typeof insertInvoiceItemSchema>;
export type InvoiceItem = typeof invoiceItems.$inferSelect;

// ========== EXPENSE SUMMARY TYPES ==========

export type ExpenseSummary = {
  categoryId: number | null;
  categoryName: string;
  categoryColor: string;
  totalAmount: number;
  transactionCount: number;
};

export type MonthlyExpenseSummary = {
  month: number;
  year: number;
  totalExpenses: number;
  expenseCount: number;
  categories: ExpenseSummary[];
};

// ========== ADVANCED ANALYTICS TYPES ==========

// Hourly sales breakdown
export type HourlySales = {
  hour: number; // 0-23
  totalRevenue: number;
  totalProfit: number;
  transactionCount: number;
};

// Day of week sales breakdown
export type DayOfWeekSales = {
  dayOfWeek: number; // 0-6 (Sunday-Saturday)
  dayName: string;
  totalRevenue: number;
  totalProfit: number;
  transactionCount: number;
};

// Customer insights
export type CustomerInsight = {
  customerId: number;
  customerName: string;
  totalTransactions: number;
  totalSpent: number;
  averageTransactionValue: number;
  lastTransactionDate: string | null;
};

// Product profitability
export type ProductProfitability = {
  productName: string;
  category: string | null;
  totalRevenue: number;
  totalCost: number;
  totalProfit: number;
  profitMargin: number; // percentage
  totalQuantity: number;
  transactionCount: number;
};

// Period comparison (weekly/monthly trends)
export type PeriodComparison = {
  currentPeriod: {
    label: string;
    totalRevenue: number;
    totalProfit: number;
    transactionCount: number;
    averageTransactionValue: number;
  };
  previousPeriod: {
    label: string;
    totalRevenue: number;
    totalProfit: number;
    transactionCount: number;
    averageTransactionValue: number;
  };
  revenueChange: number; // percentage
  profitChange: number; // percentage
  transactionCountChange: number; // percentage
};

// Top performer summary
export type TopPerformer = {
  type: 'product' | 'category' | 'customer';
  name: string;
  value: number;
  metric: string; // e.g., "revenue", "profit", "quantity"
};

// ========== BULK OPERATIONS ==========

// Bulk Import Status
export const bulkImportStatuses = ["pending", "processing", "completed", "failed"] as const;
export type BulkImportStatus = typeof bulkImportStatuses[number];

// Bulk Import Types
export const bulkImportTypes = ["transactions", "products", "customers", "expenses"] as const;
export type BulkImportType = typeof bulkImportTypes[number];

// Bulk Import Logs table
export const bulkImportLogs = pgTable("bulk_import_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  importType: varchar("import_type").$type<BulkImportType>().notNull(),
  fileName: varchar("file_name").notNull(),
  status: varchar("status").$type<BulkImportStatus>().notNull().default("pending"),
  totalRows: integer("total_rows").notNull().default(0),
  successRows: integer("success_rows").notNull().default(0),
  failedRows: integer("failed_rows").notNull().default(0),
  errorDetails: jsonb("error_details"), // array of {row, error} objects
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertBulkImportLogSchema = createInsertSchema(bulkImportLogs).omit({
  id: true,
  userId: true,
  successRows: true,
  failedRows: true,
  errorDetails: true,
  createdAt: true,
  completedAt: true,
}).extend({
  importType: z.enum(bulkImportTypes),
  fileName: z.string().min(1),
  totalRows: z.number().min(0).default(0),
  status: z.enum(bulkImportStatuses).default("pending"),
});

export type InsertBulkImportLog = z.infer<typeof insertBulkImportLogSchema>;
export type BulkImportLog = typeof bulkImportLogs.$inferSelect;

// ========== RECURRING TRANSACTIONS ==========

// Recurring frequency types
export const recurringFrequencies = ["daily", "weekly", "biweekly", "monthly", "yearly"] as const;
export type RecurringFrequency = typeof recurringFrequencies[number];

// Recurring transaction status
export const recurringStatuses = ["active", "paused", "completed", "cancelled"] as const;
export type RecurringStatus = typeof recurringStatuses[number];

// Recurring Transactions table
export const recurringTransactions = pgTable("recurring_transactions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  storeId: integer("store_id"),
  
  // Transaction template
  productName: text("product_name").notNull(),
  quantity: integer("quantity").notNull(),
  costPrice: real("cost_price").notNull(),
  sellingPrice: real("selling_price").notNull(),
  operationalCost: real("operational_cost").notNull().default(0),
  category: text("category"),
  paymentMethod: text("payment_method").default("cash"),
  
  // Recurring settings
  frequency: varchar("frequency").$type<RecurringFrequency>().notNull(),
  status: varchar("status").$type<RecurringStatus>().notNull().default("active"),
  startDate: text("start_date").notNull(),
  endDate: text("end_date"), // null = no end date
  lastGeneratedDate: text("last_generated_date"),
  nextScheduledDate: text("next_scheduled_date").notNull(),
  
  // Metadata
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertRecurringTransactionSchema = createInsertSchema(recurringTransactions).omit({
  id: true,
  userId: true,
  lastGeneratedDate: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  storeId: z.number().optional().nullable(),
  productName: z.string().min(1, "Nama produk wajib diisi"),
  quantity: z.number().min(1, "Jumlah minimal 1"),
  costPrice: z.number().min(0, "Harga modal tidak boleh negatif"),
  sellingPrice: z.number().min(0, "Harga jual tidak boleh negatif"),
  operationalCost: z.number().min(0).default(0),
  category: z.string().optional().nullable(),
  paymentMethod: z.string().default("cash"),
  frequency: z.enum(recurringFrequencies),
  status: z.enum(recurringStatuses).default("active"),
  startDate: z.string().min(1, "Tanggal mulai wajib diisi"),
  endDate: z.string().optional().nullable(),
  nextScheduledDate: z.string().min(1),
  notes: z.string().optional().nullable(),
});

export type InsertRecurringTransaction = z.infer<typeof insertRecurringTransactionSchema>;
export type RecurringTransaction = typeof recurringTransactions.$inferSelect;

// ========== MULTI-CURRENCY SUPPORT ==========

// Supported currencies
export const supportedCurrencies = ["IDR", "USD", "SGD", "MYR", "EUR", "JPY", "CNY", "AUD", "GBP"] as const;
export type SupportedCurrency = typeof supportedCurrencies[number];

// Currencies table
export const currencies = pgTable("currencies", {
  id: serial("id").primaryKey(),
  code: varchar("code").$type<SupportedCurrency>().notNull().unique(),
  name: varchar("name").notNull(),
  symbol: varchar("symbol").notNull(),
  isActive: integer("is_active").notNull().default(1),
});

// Exchange Rates table
export const exchangeRates = pgTable("exchange_rates", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(), // user who set this rate
  fromCurrency: varchar("from_currency").$type<SupportedCurrency>().notNull(),
  toCurrency: varchar("to_currency").$type<SupportedCurrency>().notNull().default("IDR"),
  rate: real("rate").notNull(), // 1 fromCurrency = rate toCurrency
  isDefault: integer("is_default").notNull().default(0), // 1 = default rate for this pair
  validFrom: timestamp("valid_from").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCurrencySchema = createInsertSchema(currencies).omit({
  id: true,
}).extend({
  code: z.enum(supportedCurrencies),
  name: z.string().min(1),
  symbol: z.string().min(1),
  isActive: z.number().default(1),
});

export type InsertCurrency = z.infer<typeof insertCurrencySchema>;
export type Currency = typeof currencies.$inferSelect;

export const insertExchangeRateSchema = createInsertSchema(exchangeRates).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  fromCurrency: z.enum(supportedCurrencies),
  toCurrency: z.enum(supportedCurrencies).default("IDR"),
  rate: z.number().positive("Kurs harus lebih dari 0"),
  isDefault: z.number().default(0),
  validFrom: z.date().optional(),
});

export type InsertExchangeRate = z.infer<typeof insertExchangeRateSchema>;
export type ExchangeRate = typeof exchangeRates.$inferSelect;

// ========== BULK OPERATION TYPES ==========

export type BulkUpdateStockItem = {
  productId: number;
  newStock: number;
};

export type BulkDeleteResult = {
  success: number;
  failed: number;
  errors: { id: number; error: string }[];
};

export type ImportRowError = {
  row: number;
  errors: string[];
  data?: Record<string, any>;
};

export type ImportResult = {
  success: number;
  failed: number;
  errors: ImportRowError[];
};

// ========== NOTIFICATION SYSTEM ==========

export const notificationTypes = ["low_stock", "invoice_due", "target_achieved", "target_warning", "system", "info"] as const;
export type NotificationType = typeof notificationTypes[number];

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  type: varchar("type").$type<NotificationType>().notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  entityType: varchar("entity_type"), // product, invoice, target, etc.
  entityId: integer("entity_id"), // ID of related entity
  isRead: integer("is_read").notNull().default(0), // 0 = unread, 1 = read
  priority: varchar("priority").notNull().default("normal"), // low, normal, high
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  userId: true,
  createdAt: true,
}).extend({
  type: z.enum(notificationTypes),
  title: z.string().min(1),
  message: z.string().min(1),
  entityType: z.string().optional().nullable(),
  entityId: z.number().optional().nullable(),
  isRead: z.number().default(0),
  priority: z.enum(["low", "normal", "high"]).default("normal"),
});

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

// ========== NOTES SYSTEM ==========

export const noteEntityTypes = ["transaction", "customer", "product", "invoice", "supplier"] as const;
export type NoteEntityType = typeof noteEntityTypes[number];

export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  entityType: varchar("entity_type").$type<NoteEntityType>().notNull(),
  entityId: integer("entity_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertNoteSchema = createInsertSchema(notes).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  entityType: z.enum(noteEntityTypes),
  entityId: z.number().min(1),
  content: z.string().min(1, "Catatan tidak boleh kosong"),
});

export type InsertNote = z.infer<typeof insertNoteSchema>;
export type Note = typeof notes.$inferSelect;

// ========== BACKUP SYSTEM ==========

export const backupStatuses = ["pending", "completed", "failed"] as const;
export type BackupStatus = typeof backupStatuses[number];

export const backupLogs = pgTable("backup_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  type: varchar("type").notNull(), // "backup" or "restore"
  status: varchar("status").$type<BackupStatus>().notNull().default("pending"),
  fileName: varchar("file_name"),
  fileSize: integer("file_size"), // in bytes
  tablesIncluded: text("tables_included").array(), // list of tables backed up
  recordCount: integer("record_count"), // total records
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertBackupLogSchema = createInsertSchema(backupLogs).omit({
  id: true,
  userId: true,
  createdAt: true,
  completedAt: true,
}).extend({
  type: z.enum(["backup", "restore"]),
  status: z.enum(backupStatuses).default("pending"),
  fileName: z.string().optional().nullable(),
  fileSize: z.number().optional().nullable(),
  tablesIncluded: z.array(z.string()).optional().nullable(),
  recordCount: z.number().optional().nullable(),
  errorMessage: z.string().optional().nullable(),
});

export type InsertBackupLog = z.infer<typeof insertBackupLogSchema>;
export type BackupLog = typeof backupLogs.$inferSelect;
