# aSF - alung SF | Business Management Platform

## Overview
aSF (alung SF) is a comprehensive business management platform for entrepreneurs and online merchants. It enables real-time transaction tracking, profit calculation, revenue target setting, inventory management with low-stock alerts, sales analysis by category and payment method, and professional report generation (Excel, PDF). Designed as a mobile-first PWA, it offers quick access to business metrics on any device.

The platform is a full-stack web application, featuring a React-based frontend, an Express backend, and a PostgreSQL database for multi-user persistent data storage, integrated with Replit Auth.

## User Preferences
Preferred communication style: Simple, everyday language (Bahasa Indonesia).
Design theme: Premium cyberpunk neon (dark navy with cyan/purple glow effects).

## System Architecture

### Frontend Architecture
- **Framework & Build System**: React 18 with TypeScript, Vite for fast HMR, Wouter for routing, PWA support.
- **UI Component Strategy**: Radix UI primitives, shadcn/ui components, Tailwind CSS with custom design tokens, CVA for variant management.
- **State Management**: TanStack Query for server state, React Hook Form with Zod for form validation, custom `useAuth` hook.
- **Design System**: Mobile-first responsive design, custom color system with dark theme, Indonesian Rupiah (IDR) formatting, typography optimized for numerical data.
- **Key Features**: Real-time profit calculation, dashboard with summaries and notifications, monthly target tracking, transaction history, category/product analytics, stock management with alerts, report export, responsive sidebar.

### Backend Architecture
- **Server Framework**: Express.js with TypeScript for REST API.
- **Authentication**: Replit Auth via OpenID Connect, Passport.js, PostgreSQL-backed session storage, `isAuthenticated` middleware for protected routes.
- **API Design**: RESTful endpoints for CRUD operations (transactions, categories, products, targets, users, stores, customers, expenses, suppliers, invoices, recurring transactions, currencies), analytics, and calculated summaries. All data is user-isolated.
- **Data Layer**: PostgreSQL via Neon serverless driver, Drizzle ORM for type-safe operations, `IStorage` abstraction.
- **Data Models**: User, Session, Transaction, Category, Product, MonthlyTarget, Store, Customer, AuditLog, Subscription, Expense, ExpenseCategory, Supplier, Invoice, InvoiceItem, RecurringTransaction, Currency, Notification, BackupLog.
- **Summary Types**: DailySummary, MonthlySummary, CategorySummary, ProductSummary, PaymentMethodSummary.

### Application Structure
- **Monorepo Layout**: `/client` for React frontend, `/server` for Express backend, `/shared` for common code (Drizzle schemas, Zod schemas, types).
- **Build Process**: Vite for client, esbuild for server.

### Core Features & Implementations
- **Role-Based Access Control (RBAC)**: Owner (full access) and Kasir (restricted) roles. First user is Owner. Owner manages users and roles. Middleware protects sensitive endpoints.
- **Multi-Store Support**: Create and manage multiple business locations with subscription-based quotas. Owner-only management.
- **Customer Database**: Track customer information, total transactions, and spending.
- **Subscription System**: Plan-based quotas (stores, products, transactions) with Free, Basic, Pro, Enterprise tiers and a 14-day trial.
- **Audit Logging**: Tracks user actions (create, update, delete) with details. Owner-only access.
- **Expense Tracking**: Manage business expenses with categories, monthly summaries, and payment methods.
- **Supplier Management**: Database for supplier information, payment terms, and purchase history.
- **Invoice Generation**: Create professional invoices with auto-numbering, line items, tax/discount, status tracking, and PDF export.
- **Bulk Operations**: Excel/CSV import, bulk export, bulk stock update, bulk delete. Owner-only access.
- **Recurring Transactions**: Schedule daily/weekly/monthly/yearly transactions with auto-generation.
- **Multi-Currency Support**: Manage multiple currencies, exchange rates, and conversion.
- **Notification Center**: Real-time notifications for low stock alerts, invoice due dates, target achievements. Bell icon in header with unread count badge.
- **Backup & Restore**: Full data backup export (JSON), restore from backup files. Owner-only access with RBAC enforcement on both frontend and backend.
- **Authentication & Multi-User Support**: Replit Auth, user isolation, session management, landing page for unauthenticated users.
- **PWA Support**: Installable on mobile devices with offline capabilities.
- **UI/UX**: Cyberpunk Neon theme with specific fonts, background, glow effects, Sonner notifications, mobile bottom navigation.

## External Dependencies

**Authentication:**
- `openid-client`
- `passport`
- `express-session`
- `connect-pg-simple`
- `memoizee`

**Database:**
- `@neondatabase/serverless`
- `drizzle-orm`
- `drizzle-kit`
- `drizzle-zod`

**Export:**
- `xlsx`
- `jspdf`
- `jspdf-autotable`

**UI Component Libraries:**
- `@radix-ui/*`
- `recharts`
- `lucide-react`

**Form Management:**
- `react-hook-form`
- `@hookform/resolvers`
- `zod`

**Data Fetching:**
- `@tanstack/react-query`

**Styling:**
- `tailwindcss`
- `tailwind-merge`, `clsx`

**Date Handling:**
- `date-fns`