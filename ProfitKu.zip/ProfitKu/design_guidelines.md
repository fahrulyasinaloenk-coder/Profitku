# Design Guidelines: UMKM Business Calculator

## Design Approach
**Utility-First Productivity System** inspired by modern financial dashboards (Stripe Dashboard, QuickBooks) with emphasis on clarity, efficiency, and mobile-first design for busy merchants. Clean, professional aesthetic that builds trust for financial data.

## Typography System
**Font Stack:**
- Primary: Inter (Google Fonts) - clean, readable for numbers and data
- Monospace: JetBrains Mono - for currency amounts and calculations

**Hierarchy:**
- Page titles: text-3xl font-bold
- Section headers: text-xl font-semibold
- Card titles: text-lg font-medium
- Body text: text-base
- Labels: text-sm font-medium text-gray-600
- Large numbers (profit display): text-4xl md:text-5xl font-bold tabular-nums
- Currency amounts: text-lg font-semibold tabular-nums

## Layout System
**Spacing Primitives:** Consistent use of 4, 6, 8, and 12 units
- Component padding: p-6
- Section spacing: space-y-8
- Card gaps: gap-6
- Form field spacing: space-y-4
- Tight groupings: space-y-2

**Container Strategy:**
- Dashboard: max-w-7xl mx-auto px-4
- Forms/Cards: max-w-2xl for focused input
- Tables: full-width with horizontal scroll on mobile

## Component Library

### Dashboard Layout
**Stats Cards Grid:**
- 3-column grid on desktop (grid-cols-1 md:grid-cols-3)
- Each card shows: icon, label, large value, percentage change
- Consistent card pattern: rounded-xl border shadow-sm p-6

### Transaction Input Form
**Structure:**
- Sticky header with section title
- Two-column layout on desktop for form fields (grid-cols-1 md:grid-cols-2)
- Large input fields (h-12) for easy mobile tapping
- Inline validation with helper text
- Prominent submit button (w-full md:w-auto)

### Profit Calculator Display
**Real-time Calculation Panel:**
- Large, centered profit number with green/red indicator
- Breakdown table showing: Modal, Harga Jual, Biaya, Profit Margin
- Visual separator lines between calculation steps

### Monthly Target Section
**Progress Visualization:**
- Large progress bar (h-4 rounded-full)
- Target metrics in grid: Achieved, Remaining, Percentage
- Daily average calculation display

### Report Table
**Data Display:**
- Sticky header row
- Alternating row backgrounds for readability
- Right-aligned numbers with tabular-nums
- Action column for edit/delete (icon buttons)
- Mobile: Collapse to card layout with key info stacked

### Navigation
**Top Bar:**
- Logo/title left-aligned
- Icon-based quick actions right-aligned
- Dropdown menu for mobile (hamburger)

**Tab Navigation:**
- Horizontal tabs for sections: Input, Dashboard, Laporan
- Active state with bottom border indicator

## Icons
Use **Heroicons** (outline and solid variants) via CDN:
- Calculator (calculator icon) - primary action
- Chart (chart-bar) - reports
- Target (flag) - monthly goals
- Plus/minus (plus-circle, minus-circle) - transactions
- Currency (currency-dollar adapted to Rp)

## Animations
**Minimal, Purposeful:**
- Number count-up on dashboard stats (using CountUp.js)
- Progress bar fill animation on load
- Smooth transitions on tab switching (transition-opacity duration-200)

## Images
**No hero image required** - This is a utility dashboard that should load quickly and get users directly to their tools.

**Icon Graphics:**
- Small illustration in empty states ("Belum ada transaksi hari ini")
- Success checkmark animation after transaction submission

## Mobile Optimization
**Touch-First Design:**
- Minimum touch target: 44px height
- Bottom-sticky action buttons for primary actions
- Collapsible sections to reduce scroll
- Numeric keyboard triggers for input type="number"

## Accessibility
- Labels paired with all inputs
- ARIA labels for icon-only buttons
- Focus visible states on all interactive elements (ring-2 ring-offset-2)
- Color not sole indicator (icons + text for profit/loss)

## Data Visualization
**Chart Library:** Chart.js for simple line/bar charts
- Weekly profit trend line chart
- Category breakdown pie chart
- Minimal styling, emphasize data clarity

## Form Patterns
**Consistent Input Structure:**
- Label above input (mb-2)
- Input with border and focus ring
- Helper text below (text-sm text-gray-500)
- Error states with red border and text

**Currency Input:**
- Prefix "Rp" visually attached
- Thousand separators for readability
- Large font size for entered amounts

This utility-focused design prioritizes speed, clarity, and mobile usability for merchants managing daily transactions efficiently.