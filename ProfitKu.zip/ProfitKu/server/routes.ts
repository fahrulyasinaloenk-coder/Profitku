import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { requirePermission, requireOwner } from "./rbac";
import { 
  insertTransactionSchema, 
  insertMonthlyTargetSchema,
  insertCategorySchema,
  insertProductSchema,
  insertStoreSchema,
  insertCustomerSchema,
  insertExpenseCategorySchema,
  insertExpenseSchema,
  insertSupplierSchema,
  insertInvoiceSchema,
  insertInvoiceItemSchema,
  insertRecurringTransactionSchema,
  insertExchangeRateSchema,
  type InvoiceStatus,
  type RecurringStatus,
  type InsertTransaction,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Get current user
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Get all transactions
  app.get("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transactions = await storage.getTransactions(userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  // Create a new transaction
  app.post("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertTransactionSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const transaction = await storage.createTransaction(userId, parsed.data);
      res.status(201).json(transaction);
    } catch (error) {
      res.status(500).json({ error: "Failed to create transaction" });
    }
  });

  // Delete a transaction (Owner only)
  app.delete("/api/transactions/:id", isAuthenticated, requirePermission("delete:transaction"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid transaction ID" });
      }
      const deleted = await storage.deleteTransaction(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Transaction not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete transaction" });
    }
  });

  // Set/update monthly target
  app.post("/api/targets", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertMonthlyTargetSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const target = await storage.setMonthlyTarget(userId, parsed.data);
      res.status(201).json(target);
    } catch (error) {
      res.status(500).json({ error: "Failed to set monthly target" });
    }
  });

  // Get daily summary
  app.get("/api/summary/daily/:date", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const summary = await storage.getDailySummary(userId, req.params.date);
      res.json(summary);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch daily summary" });
    }
  });

  // Get monthly summary
  app.get("/api/summary/monthly/:month/:year", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const month = parseInt(req.params.month);
      const year = parseInt(req.params.year);
      if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
        return res.status(400).json({ error: "Invalid month or year" });
      }
      const summary = await storage.getMonthlySummary(userId, month, year);
      res.json(summary);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch monthly summary" });
    }
  });

  // Get daily summaries for a month (for chart)
  app.get("/api/summary/daily-range/:month/:year", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const month = parseInt(req.params.month);
      const year = parseInt(req.params.year);
      if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
        return res.status(400).json({ error: "Invalid month or year" });
      }
      const summaries = await storage.getDailySummariesForMonth(userId, month, year);
      res.json(summaries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch daily summaries" });
    }
  });

  // Categories
  app.get("/api/categories", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const categoryList = await storage.getCategories(userId);
      res.json(categoryList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  app.post("/api/categories", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertCategorySchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const category = await storage.createCategory(userId, parsed.data);
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ error: "Failed to create category" });
    }
  });

  // Delete category (Owner only)
  app.delete("/api/categories/:id", isAuthenticated, requirePermission("delete:category"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid category ID" });
      }
      const deleted = await storage.deleteCategory(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Category not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete category" });
    }
  });

  // Category analytics
  app.get("/api/analytics/categories/:month/:year", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const month = parseInt(req.params.month);
      const year = parseInt(req.params.year);
      if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
        return res.status(400).json({ error: "Invalid month or year" });
      }
      const summaries = await storage.getCategorySummaries(userId, month, year);
      res.json(summaries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch category analytics" });
    }
  });

  // Product analytics - best sellers
  app.get("/api/analytics/products/:month/:year", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const month = parseInt(req.params.month);
      const year = parseInt(req.params.year);
      if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
        return res.status(400).json({ error: "Invalid month or year" });
      }
      const summaries = await storage.getProductSummaries(userId, month, year);
      res.json(summaries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product analytics" });
    }
  });

  // Payment method analytics
  app.get("/api/analytics/payment-methods/:month/:year", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const month = parseInt(req.params.month);
      const year = parseInt(req.params.year);
      if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
        return res.status(400).json({ error: "Invalid month or year" });
      }
      const summaries = await storage.getPaymentMethodSummaries(userId, month, year);
      res.json(summaries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch payment method analytics" });
    }
  });

  // ============ Advanced Analytics ============

  // Hourly sales breakdown
  app.get("/api/analytics/hourly/:month/:year", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const month = parseInt(req.params.month);
      const year = parseInt(req.params.year);
      if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
        return res.status(400).json({ error: "Invalid month or year" });
      }
      const data = await storage.getHourlySales(userId, month, year);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch hourly sales" });
    }
  });

  // Day of week sales breakdown
  app.get("/api/analytics/day-of-week/:month/:year", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const month = parseInt(req.params.month);
      const year = parseInt(req.params.year);
      if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
        return res.status(400).json({ error: "Invalid month or year" });
      }
      const data = await storage.getDayOfWeekSales(userId, month, year);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch day of week sales" });
    }
  });

  // Customer insights
  app.get("/api/analytics/customers", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 10;
      const data = await storage.getCustomerInsights(userId, limit);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch customer insights" });
    }
  });

  // Product profitability
  app.get("/api/analytics/profitability/:month/:year", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const month = parseInt(req.params.month);
      const year = parseInt(req.params.year);
      if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
        return res.status(400).json({ error: "Invalid month or year" });
      }
      const data = await storage.getProductProfitability(userId, month, year);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product profitability" });
    }
  });

  // Period comparison (weekly/monthly trends)
  app.get("/api/analytics/comparison/:periodType", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const periodType = req.params.periodType as 'weekly' | 'monthly';
      if (periodType !== 'weekly' && periodType !== 'monthly') {
        return res.status(400).json({ error: "Invalid period type. Use 'weekly' or 'monthly'" });
      }
      const data = await storage.getPeriodComparison(userId, periodType);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch period comparison" });
    }
  });

  // Products (inventory)
  app.get("/api/products", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const productList = await storage.getProducts(userId);
      res.json(productList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/low-stock", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const lowStockProducts = await storage.getLowStockProducts(userId);
      res.json(lowStockProducts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch low stock products" });
    }
  });

  app.get("/api/products/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const product = await storage.getProduct(id, userId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  app.post("/api/products", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertProductSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const product = await storage.createProduct(userId, parsed.data);
      res.status(201).json(product);
    } catch (error: any) {
      // Handle quota limit errors using structured error codes
      if (error?.code === 'PRODUCT_QUOTA_EXCEEDED') {
        return res.status(403).json({ error: error.message, code: error.code });
      }
      res.status(500).json({ error: "Failed to create product" });
    }
  });

  app.patch("/api/products/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const product = await storage.updateProduct(id, userId, req.body);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  // Delete product (Owner only)
  app.delete("/api/products/:id", isAuthenticated, requirePermission("delete:product"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const deleted = await storage.deleteProduct(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  app.patch("/api/products/:id/stock", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const { quantity } = req.body;
      if (isNaN(id) || typeof quantity !== "number") {
        return res.status(400).json({ error: "Invalid product ID or quantity" });
      }
      const product = await storage.updateProductStock(id, userId, quantity);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to update product stock" });
    }
  });

  // ============ User Management (Owner only) ============

  // Get all users
  app.get("/api/users", isAuthenticated, requireOwner(), async (req: any, res) => {
    try {
      const userList = await storage.getAllUsers();
      res.json(userList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  // Update user role
  app.patch("/api/users/:id/role", isAuthenticated, requireOwner(), async (req: any, res) => {
    try {
      const { id } = req.params;
      const { role } = req.body;
      
      if (!role || !["owner", "kasir"].includes(role)) {
        return res.status(400).json({ error: "Invalid role. Must be 'owner' or 'kasir'" });
      }

      // Prevent removing the last owner
      if (role === "kasir") {
        const allUsers = await storage.getAllUsers();
        const owners = allUsers.filter(u => u.role === "owner");
        if (owners.length === 1 && owners[0].id === id) {
          return res.status(400).json({ error: "Tidak dapat mengubah role owner terakhir" });
        }
      }

      const user = await storage.updateUserRole(id, role);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to update user role" });
    }
  });

  // Delete user (Owner only)
  app.delete("/api/users/:id", isAuthenticated, requirePermission("delete:user"), async (req: any, res) => {
    try {
      const { id } = req.params;
      const currentUserId = req.user.claims.sub;

      // Prevent self-deletion
      if (id === currentUserId) {
        return res.status(400).json({ error: "Tidak dapat menghapus akun sendiri" });
      }

      // Prevent deleting the last owner
      const allUsers = await storage.getAllUsers();
      const targetUser = allUsers.find(u => u.id === id);
      if (targetUser?.role === "owner") {
        const owners = allUsers.filter(u => u.role === "owner");
        if (owners.length === 1) {
          return res.status(400).json({ error: "Tidak dapat menghapus owner terakhir" });
        }
      }

      const deleted = await storage.deleteUser(id);
      if (!deleted) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete user" });
    }
  });

  // ============ Store Management ============

  // Get all stores
  app.get("/api/stores", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const storeList = await storage.getStores(userId);
      res.json(storeList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stores" });
    }
  });

  // Get single store
  app.get("/api/stores/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid store ID" });
      }
      const store = await storage.getStore(id, userId);
      if (!store) {
        return res.status(404).json({ error: "Store not found" });
      }
      res.json(store);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch store" });
    }
  });

  // Create store (Owner only - manages multi-store)
  app.post("/api/stores", isAuthenticated, requireOwner(), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertStoreSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const store = await storage.createStore(userId, parsed.data);
      res.status(201).json(store);
    } catch (error: any) {
      // Handle quota limit errors using structured error codes
      if (error?.code === 'STORE_QUOTA_EXCEEDED') {
        return res.status(403).json({ error: error.message, code: error.code });
      }
      res.status(500).json({ error: "Failed to create store" });
    }
  });

  // Update store (Owner only)
  app.patch("/api/stores/:id", isAuthenticated, requireOwner(), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid store ID" });
      }
      const store = await storage.updateStore(id, userId, req.body);
      if (!store) {
        return res.status(404).json({ error: "Store not found" });
      }
      res.json(store);
    } catch (error) {
      res.status(500).json({ error: "Failed to update store" });
    }
  });

  // Delete store (Owner only)
  app.delete("/api/stores/:id", isAuthenticated, requireOwner(), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid store ID" });
      }
      const deleted = await storage.deleteStore(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Store not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete store" });
    }
  });

  // ============ Customer Management ============

  // Get all customers
  app.get("/api/customers", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const customerList = await storage.getCustomers(userId);
      res.json(customerList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch customers" });
    }
  });

  // Get single customer
  app.get("/api/customers/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid customer ID" });
      }
      const customer = await storage.getCustomer(id, userId);
      if (!customer) {
        return res.status(404).json({ error: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch customer" });
    }
  });

  // Create customer
  app.post("/api/customers", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertCustomerSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const customer = await storage.createCustomer(userId, parsed.data);
      res.status(201).json(customer);
    } catch (error) {
      res.status(500).json({ error: "Failed to create customer" });
    }
  });

  // Update customer
  app.patch("/api/customers/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid customer ID" });
      }
      const customer = await storage.updateCustomer(id, userId, req.body);
      if (!customer) {
        return res.status(404).json({ error: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ error: "Failed to update customer" });
    }
  });

  // Delete customer (Owner only)
  app.delete("/api/customers/:id", isAuthenticated, requirePermission("delete:customer"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid customer ID" });
      }
      const deleted = await storage.deleteCustomer(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Customer not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete customer" });
    }
  });

  // ============ Audit Log (Owner only) ============

  // Get audit logs
  app.get("/api/audit-logs", isAuthenticated, requireOwner(), async (req: any, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const userId = req.query.userId as string | undefined;
      const logs = await storage.getAuditLogs(userId, limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch audit logs" });
    }
  });

  // ============ Subscription Management ============

  // Get current user's subscription
  app.get("/api/subscription", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let subscription = await storage.getSubscription(userId);
      
      // Create default subscription if not exists (defaults based on plan in storage layer)
      if (!subscription) {
        subscription = await storage.createSubscription({ userId });
      }
      
      res.json(subscription);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch subscription" });
    }
  });

  // Update subscription (Owner only - for admin purposes)
  app.patch("/api/subscription/:userId", isAuthenticated, requireOwner(), async (req: any, res) => {
    try {
      const { userId } = req.params;
      const subscription = await storage.updateSubscription(userId, req.body);
      if (!subscription) {
        return res.status(404).json({ error: "Subscription not found" });
      }
      res.json(subscription);
    } catch (error) {
      res.status(500).json({ error: "Failed to update subscription" });
    }
  });

  // ============ Expense Categories ============

  // Get all expense categories
  app.get("/api/expense-categories", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const categoryList = await storage.getExpenseCategories(userId);
      res.json(categoryList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch expense categories" });
    }
  });

  // Create expense category
  app.post("/api/expense-categories", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertExpenseCategorySchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const category = await storage.createExpenseCategory(userId, parsed.data);
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ error: "Failed to create expense category" });
    }
  });

  // Update expense category
  app.patch("/api/expense-categories/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid category ID" });
      }
      const category = await storage.updateExpenseCategory(id, userId, req.body);
      if (!category) {
        return res.status(404).json({ error: "Expense category not found" });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ error: "Failed to update expense category" });
    }
  });

  // Delete expense category (Owner only)
  app.delete("/api/expense-categories/:id", isAuthenticated, requirePermission("delete:expense"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid category ID" });
      }
      const deleted = await storage.deleteExpenseCategory(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Expense category not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete expense category" });
    }
  });

  // ============ Expenses ============

  // Get all expenses
  app.get("/api/expenses", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const expenseList = await storage.getExpenses(userId);
      res.json(expenseList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch expenses" });
    }
  });

  // Get single expense
  app.get("/api/expenses/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid expense ID" });
      }
      const expense = await storage.getExpense(id, userId);
      if (!expense) {
        return res.status(404).json({ error: "Expense not found" });
      }
      res.json(expense);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch expense" });
    }
  });

  // Create expense
  app.post("/api/expenses", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertExpenseSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const expense = await storage.createExpense(userId, parsed.data);
      res.status(201).json(expense);
    } catch (error) {
      res.status(500).json({ error: "Failed to create expense" });
    }
  });

  // Update expense
  app.patch("/api/expenses/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid expense ID" });
      }
      const expense = await storage.updateExpense(id, userId, req.body);
      if (!expense) {
        return res.status(404).json({ error: "Expense not found" });
      }
      res.json(expense);
    } catch (error) {
      res.status(500).json({ error: "Failed to update expense" });
    }
  });

  // Delete expense (Owner only)
  app.delete("/api/expenses/:id", isAuthenticated, requirePermission("delete:expense"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid expense ID" });
      }
      const deleted = await storage.deleteExpense(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Expense not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete expense" });
    }
  });

  // Get expense summary
  app.get("/api/expenses/summary/:month/:year", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const month = parseInt(req.params.month);
      const year = parseInt(req.params.year);
      if (isNaN(month) || isNaN(year) || month < 1 || month > 12) {
        return res.status(400).json({ error: "Invalid month or year" });
      }
      const summary = await storage.getExpenseSummary(userId, month, year);
      res.json(summary);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch expense summary" });
    }
  });

  // ============ Suppliers ============

  // Get all suppliers
  app.get("/api/suppliers", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const supplierList = await storage.getSuppliers(userId);
      res.json(supplierList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch suppliers" });
    }
  });

  // Get single supplier
  app.get("/api/suppliers/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid supplier ID" });
      }
      const supplier = await storage.getSupplier(id, userId);
      if (!supplier) {
        return res.status(404).json({ error: "Supplier not found" });
      }
      res.json(supplier);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch supplier" });
    }
  });

  // Create supplier
  app.post("/api/suppliers", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertSupplierSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const supplier = await storage.createSupplier(userId, parsed.data);
      res.status(201).json(supplier);
    } catch (error) {
      res.status(500).json({ error: "Failed to create supplier" });
    }
  });

  // Update supplier
  app.patch("/api/suppliers/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid supplier ID" });
      }
      const supplier = await storage.updateSupplier(id, userId, req.body);
      if (!supplier) {
        return res.status(404).json({ error: "Supplier not found" });
      }
      res.json(supplier);
    } catch (error) {
      res.status(500).json({ error: "Failed to update supplier" });
    }
  });

  // Delete supplier (Owner only)
  app.delete("/api/suppliers/:id", isAuthenticated, requirePermission("delete:supplier"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid supplier ID" });
      }
      const deleted = await storage.deleteSupplier(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Supplier not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete supplier" });
    }
  });

  // ============ Invoices ============

  // Get all invoices
  app.get("/api/invoices", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const invoiceList = await storage.getInvoices(userId);
      res.json(invoiceList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch invoices" });
    }
  });

  // Generate invoice number (MUST be before :id route)
  app.get("/api/invoices/generate-number", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const invoiceNumber = await storage.generateInvoiceNumber(userId);
      res.json({ invoiceNumber });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate invoice number" });
    }
  });

  // Get single invoice with items
  app.get("/api/invoices/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid invoice ID" });
      }
      const invoice = await storage.getInvoice(id, userId);
      if (!invoice) {
        return res.status(404).json({ error: "Invoice not found" });
      }
      const items = await storage.getInvoiceItems(id);
      res.json({ ...invoice, items });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch invoice" });
    }
  });

  // Create invoice with items
  app.post("/api/invoices", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { items, ...invoiceData } = req.body;
      
      const parsedInvoice = insertInvoiceSchema.safeParse(invoiceData);
      if (!parsedInvoice.success) {
        return res.status(400).json({ error: parsedInvoice.error.errors });
      }
      
      // Validate items
      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: "Invoice must have at least one item" });
      }
      
      const parsedItems = items.map((item: any) => {
        const parsed = insertInvoiceItemSchema.omit({ invoiceId: true }).safeParse(item);
        if (!parsed.success) {
          throw new Error("Invalid invoice item");
        }
        return parsed.data;
      });
      
      const invoice = await storage.createInvoice(userId, parsedInvoice.data, parsedItems as any);
      const createdItems = await storage.getInvoiceItems(invoice.id);
      res.status(201).json({ ...invoice, items: createdItems });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to create invoice" });
    }
  });

  // Update invoice
  app.patch("/api/invoices/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid invoice ID" });
      }
      const invoice = await storage.updateInvoice(id, userId, req.body);
      if (!invoice) {
        return res.status(404).json({ error: "Invoice not found" });
      }
      res.json(invoice);
    } catch (error) {
      res.status(500).json({ error: "Failed to update invoice" });
    }
  });

  // Update invoice status
  app.patch("/api/invoices/:id/status", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid invoice ID" });
      }
      
      const validStatuses: InvoiceStatus[] = ["draft", "sent", "paid", "overdue", "cancelled"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ error: "Invalid status" });
      }
      
      const invoice = await storage.updateInvoiceStatus(id, userId, status);
      if (!invoice) {
        return res.status(404).json({ error: "Invoice not found" });
      }
      res.json(invoice);
    } catch (error) {
      res.status(500).json({ error: "Failed to update invoice status" });
    }
  });

  // Delete invoice (Owner only)
  app.delete("/api/invoices/:id", isAuthenticated, requirePermission("delete:invoice"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid invoice ID" });
      }
      const deleted = await storage.deleteInvoice(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Invoice not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete invoice" });
    }
  });

  // ========== BULK OPERATIONS ==========

  // Get bulk import logs
  app.get("/api/bulk/logs", isAuthenticated, requirePermission("export:reports"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const logs = await storage.getBulkImportLogs(userId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch import logs" });
    }
  });

  // Bulk import transactions (Owner only)
  app.post("/api/bulk/transactions", isAuthenticated, requirePermission("export:reports"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { transactions: txnData, fileName } = req.body;
      
      if (!Array.isArray(txnData) || txnData.length === 0) {
        return res.status(400).json({ error: "No transactions provided" });
      }

      // Create import log
      const log = await storage.createBulkImportLog(userId, {
        importType: "transactions",
        fileName: fileName || "import.xlsx",
        totalRows: txnData.length,
        status: "processing",
      });

      // Parse and validate transactions
      const parsedTransactions: InsertTransaction[] = [];
      const parseErrors: { row: number; errors: string[] }[] = [];

      for (let i = 0; i < txnData.length; i++) {
        const parsed = insertTransactionSchema.safeParse(txnData[i]);
        if (parsed.success) {
          parsedTransactions.push(parsed.data);
        } else {
          parseErrors.push({
            row: i + 1,
            errors: parsed.error.errors.map(e => e.message),
          });
        }
      }

      // Import valid transactions
      const result = await storage.bulkCreateTransactions(userId, parsedTransactions);

      // Combine parse errors with import errors
      const allErrors = [...parseErrors, ...result.errors];

      // Update import log
      await storage.updateBulkImportLog(log.id, {
        status: allErrors.length === 0 ? "completed" : "completed",
        successRows: result.success,
        failedRows: allErrors.length,
        errorDetails: allErrors,
        completedAt: new Date(),
      });

      res.json({
        success: result.success,
        failed: allErrors.length,
        total: txnData.length,
        errors: allErrors.slice(0, 10), // Return first 10 errors
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to import transactions" });
    }
  });

  // Bulk update stock (Owner only)
  app.post("/api/bulk/stock", isAuthenticated, requirePermission("export:reports"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { items } = req.body;
      
      if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: "No stock updates provided" });
      }

      const result = await storage.bulkUpdateStock(userId, items);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to update stock" });
    }
  });

  // Bulk delete transactions (Owner only)
  app.post("/api/bulk/delete/transactions", isAuthenticated, requirePermission("delete:transaction"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { ids } = req.body;
      
      if (!Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ error: "No transaction IDs provided" });
      }

      const result = await storage.bulkDeleteTransactions(userId, ids);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to delete transactions" });
    }
  });

  // Bulk delete products (Owner only)
  app.post("/api/bulk/delete/products", isAuthenticated, requirePermission("delete:product"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { ids } = req.body;
      
      if (!Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ error: "No product IDs provided" });
      }

      const result = await storage.bulkDeleteProducts(userId, ids);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to delete products" });
    }
  });

  // ========== RECURRING TRANSACTIONS ==========

  // Get all recurring transactions
  app.get("/api/recurring", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const recurring = await storage.getRecurringTransactions(userId);
      res.json(recurring);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recurring transactions" });
    }
  });

  // Get due recurring transactions (for processing)
  app.get("/api/recurring/due", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const due = await storage.getDueRecurringTransactions(userId);
      res.json(due);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch due recurring transactions" });
    }
  });

  // Get single recurring transaction
  app.get("/api/recurring/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid recurring transaction ID" });
      }
      const recurring = await storage.getRecurringTransaction(id, userId);
      if (!recurring) {
        return res.status(404).json({ error: "Recurring transaction not found" });
      }
      res.json(recurring);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recurring transaction" });
    }
  });

  // Create recurring transaction
  app.post("/api/recurring", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertRecurringTransactionSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const recurring = await storage.createRecurringTransaction(userId, parsed.data);
      res.status(201).json(recurring);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to create recurring transaction" });
    }
  });

  // Update recurring transaction
  app.patch("/api/recurring/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid recurring transaction ID" });
      }
      const recurring = await storage.updateRecurringTransaction(id, userId, req.body);
      if (!recurring) {
        return res.status(404).json({ error: "Recurring transaction not found" });
      }
      res.json(recurring);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to update recurring transaction" });
    }
  });

  // Update recurring transaction status
  app.patch("/api/recurring/:id/status", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid recurring transaction ID" });
      }
      
      const validStatuses: RecurringStatus[] = ["active", "paused", "completed", "cancelled"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ error: "Invalid status" });
      }
      
      const recurring = await storage.updateRecurringStatus(id, userId, status);
      if (!recurring) {
        return res.status(404).json({ error: "Recurring transaction not found" });
      }
      res.json(recurring);
    } catch (error) {
      res.status(500).json({ error: "Failed to update recurring status" });
    }
  });

  // Process recurring transaction (generate actual transaction)
  app.post("/api/recurring/:id/process", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid recurring transaction ID" });
      }
      const transaction = await storage.processRecurringTransaction(id, userId);
      if (!transaction) {
        return res.status(400).json({ error: "Cannot process this recurring transaction" });
      }
      res.json(transaction);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to process recurring transaction" });
    }
  });

  // Process all due recurring transactions
  app.post("/api/recurring/process-all", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const dueTransactions = await storage.getDueRecurringTransactions(userId);
      const results = [];
      
      for (const recurring of dueTransactions) {
        try {
          const txn = await storage.processRecurringTransaction(recurring.id, userId);
          if (txn) {
            results.push({ id: recurring.id, success: true, transaction: txn });
          }
        } catch (error: any) {
          results.push({ id: recurring.id, success: false, error: error.message });
        }
      }
      
      res.json({
        processed: results.filter(r => r.success).length,
        failed: results.filter(r => !r.success).length,
        results,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to process recurring transactions" });
    }
  });

  // Delete recurring transaction
  app.delete("/api/recurring/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid recurring transaction ID" });
      }
      const deleted = await storage.deleteRecurringTransaction(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Recurring transaction not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete recurring transaction" });
    }
  });

  // ========== CURRENCIES ==========

  // Get all currencies
  app.get("/api/currencies", isAuthenticated, async (req: any, res) => {
    try {
      // Initialize default currencies if needed
      await storage.initializeDefaultCurrencies();
      const currencies = await storage.getCurrencies();
      res.json(currencies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch currencies" });
    }
  });

  // ========== EXCHANGE RATES ==========

  // Get all exchange rates for user
  app.get("/api/exchange-rates", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const rates = await storage.getExchangeRates(userId);
      res.json(rates);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch exchange rates" });
    }
  });

  // Create exchange rate
  app.post("/api/exchange-rates", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const parsed = insertExchangeRateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const rate = await storage.createExchangeRate(userId, parsed.data);
      res.status(201).json(rate);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to create exchange rate" });
    }
  });

  // Update exchange rate
  app.patch("/api/exchange-rates/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid exchange rate ID" });
      }
      const rate = await storage.updateExchangeRate(id, userId, req.body);
      if (!rate) {
        return res.status(404).json({ error: "Exchange rate not found" });
      }
      res.json(rate);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to update exchange rate" });
    }
  });

  // Delete exchange rate
  app.delete("/api/exchange-rates/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid exchange rate ID" });
      }
      const deleted = await storage.deleteExchangeRate(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Exchange rate not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete exchange rate" });
    }
  });

  // Convert currency
  app.post("/api/convert-currency", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { amount, fromCurrency, toCurrency } = req.body;
      
      if (typeof amount !== "number" || amount < 0) {
        return res.status(400).json({ error: "Invalid amount" });
      }
      
      const converted = await storage.convertCurrency(amount, fromCurrency, toCurrency, userId);
      res.json({
        originalAmount: amount,
        fromCurrency,
        toCurrency,
        convertedAmount: converted,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to convert currency" });
    }
  });

  // ========== NOTIFICATIONS ==========

  // Get all notifications
  app.get("/api/notifications", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const notifs = await storage.getNotifications(userId);
      res.json(notifs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  // Get unread notification count
  app.get("/api/notifications/unread-count", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const count = await storage.getUnreadNotificationCount(userId);
      res.json({ count });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notification count" });
    }
  });

  // Generate notifications (check for low stock, due invoices, targets)
  app.post("/api/notifications/generate", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const lowStock = await storage.generateLowStockNotifications(userId);
      const dueInvoices = await storage.generateDueInvoiceNotifications(userId);
      const targets = await storage.generateTargetNotifications(userId);
      
      res.json({
        generated: {
          lowStock,
          dueInvoices,
          targets,
          total: lowStock + dueInvoices + targets,
        },
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to generate notifications" });
    }
  });

  // Mark notification as read
  app.patch("/api/notifications/:id/read", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid notification ID" });
      }
      const notif = await storage.markNotificationAsRead(id, userId);
      if (!notif) {
        return res.status(404).json({ error: "Notification not found" });
      }
      res.json(notif);
    } catch (error) {
      res.status(500).json({ error: "Failed to mark notification as read" });
    }
  });

  // Mark all notifications as read
  app.post("/api/notifications/read-all", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const count = await storage.markAllNotificationsAsRead(userId);
      res.json({ marked: count });
    } catch (error) {
      res.status(500).json({ error: "Failed to mark notifications as read" });
    }
  });

  // Delete notification
  app.delete("/api/notifications/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid notification ID" });
      }
      const deleted = await storage.deleteNotification(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Notification not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete notification" });
    }
  });

  // Delete all notifications
  app.delete("/api/notifications", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const count = await storage.deleteAllNotifications(userId);
      res.json({ deleted: count });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete notifications" });
    }
  });

  // ========== NOTES ==========

  // Get notes (optionally filtered by entity)
  app.get("/api/notes", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { entityType, entityId } = req.query;
      const notesList = await storage.getNotes(
        userId,
        entityType as string | undefined,
        entityId ? parseInt(entityId as string) : undefined
      );
      res.json(notesList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notes" });
    }
  });

  // Get single note
  app.get("/api/notes/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid note ID" });
      }
      const note = await storage.getNote(id, userId);
      if (!note) {
        return res.status(404).json({ error: "Note not found" });
      }
      res.json(note);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch note" });
    }
  });

  // Create note
  app.post("/api/notes", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { entityType, entityId, content } = req.body;
      
      if (!entityType || !entityId || !content) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      const note = await storage.createNote(userId, {
        entityType,
        entityId,
        content,
      });
      res.status(201).json(note);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to create note" });
    }
  });

  // Update note
  app.patch("/api/notes/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      const { content } = req.body;
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid note ID" });
      }
      if (!content) {
        return res.status(400).json({ error: "Content is required" });
      }
      
      const note = await storage.updateNote(id, userId, content);
      if (!note) {
        return res.status(404).json({ error: "Note not found" });
      }
      res.json(note);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to update note" });
    }
  });

  // Delete note
  app.delete("/api/notes/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid note ID" });
      }
      const deleted = await storage.deleteNote(id, userId);
      if (!deleted) {
        return res.status(404).json({ error: "Note not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete note" });
    }
  });

  // ========== BACKUP ==========

  // Get backup logs
  app.get("/api/backup/logs", isAuthenticated, requirePermission("export:reports"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const logs = await storage.getBackupLogs(userId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch backup logs" });
    }
  });

  // Create backup
  app.post("/api/backup", isAuthenticated, requirePermission("export:reports"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Create pending backup log
      const log = await storage.createBackupLog(userId, {
        type: "backup",
        status: "pending",
      });
      
      try {
        const { data, fileName, recordCount } = await storage.createBackup(userId);
        
        // Update log with success
        await storage.updateBackupLog(log.id, {
          status: "completed",
          fileName,
          fileSize: JSON.stringify(data).length,
          tablesIncluded: Object.keys(data).filter(k => k !== "version" && k !== "exportedAt" && k !== "userId"),
          recordCount,
          completedAt: new Date(),
        });
        
        res.json({
          success: true,
          fileName,
          recordCount,
          data,
        });
      } catch (backupError: any) {
        // Update log with failure
        await storage.updateBackupLog(log.id, {
          status: "failed",
          errorMessage: backupError.message,
          completedAt: new Date(),
        });
        throw backupError;
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to create backup" });
    }
  });

  // Restore backup
  app.post("/api/backup/restore", isAuthenticated, requirePermission("export:reports"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { data } = req.body;
      
      if (!data || typeof data !== "object") {
        return res.status(400).json({ error: "Invalid backup data" });
      }
      
      // Create pending restore log
      const log = await storage.createBackupLog(userId, {
        type: "restore",
        status: "pending",
        fileName: data.exportedAt ? `backup_${data.exportedAt}` : undefined,
      });
      
      try {
        const { success, recordCount } = await storage.restoreBackup(userId, data);
        
        // Update log with result
        await storage.updateBackupLog(log.id, {
          status: success ? "completed" : "failed",
          recordCount,
          completedAt: new Date(),
        });
        
        res.json({ success, recordCount });
      } catch (restoreError: any) {
        // Update log with failure
        await storage.updateBackupLog(log.id, {
          status: "failed",
          errorMessage: restoreError.message,
          completedAt: new Date(),
        });
        throw restoreError;
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to restore backup" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
