import { db } from "./db";
import { eq, and, desc, asc, sql, gte, lte } from "drizzle-orm";
import {
  transactions,
  monthlyTargets,
  categories,
  products,
  users,
  stores,
  customers,
  auditLogs,
  subscriptions,
  expenseCategories,
  expenses,
  suppliers,
  invoices,
  invoiceItems,
  bulkImportLogs,
  recurringTransactions,
  currencies,
  exchangeRates,
  notifications,
  notes,
  backupLogs,
  type Transaction,
  type InsertTransaction,
  type MonthlyTarget,
  type InsertMonthlyTarget,
  type Category,
  type InsertCategory,
  type Product,
  type InsertProduct,
  type DailySummary,
  type MonthlySummary,
  type CategorySummary,
  type ProductSummary,
  type User,
  type UpsertUser,
  type PaymentMethodSummary,
  type Store,
  type InsertStore,
  type Customer,
  type InsertCustomer,
  type AuditLog,
  type InsertAuditLog,
  type Subscription,
  type InsertSubscription,
  type HourlySales,
  type DayOfWeekSales,
  type CustomerInsight,
  type ProductProfitability,
  type PeriodComparison,
  type ExpenseCategory,
  type InsertExpenseCategory,
  type Expense,
  type InsertExpense,
  type ExpenseSummary,
  type MonthlyExpenseSummary,
  type Supplier,
  type InsertSupplier,
  type Invoice,
  type InsertInvoice,
  type InvoiceItem,
  type InsertInvoiceItem,
  type InvoiceStatus,
  type BulkImportLog,
  type InsertBulkImportLog,
  type BulkImportStatus,
  type RecurringTransaction,
  type InsertRecurringTransaction,
  type RecurringStatus,
  type Currency,
  type InsertCurrency,
  type ExchangeRate,
  type InsertExchangeRate,
  type BulkUpdateStockItem,
  type BulkDeleteResult,
  type ImportResult,
  type Notification,
  type InsertNotification,
  type Note,
  type InsertNote,
  type BackupLog,
  type InsertBackupLog,
} from "@shared/schema";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUserRole(id: string, role: "owner" | "kasir"): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;

  // Transaction operations
  getTransactions(userId: string): Promise<Transaction[]>;
  getTransaction(id: number, userId: string): Promise<Transaction | undefined>;
  createTransaction(userId: string, transaction: InsertTransaction): Promise<Transaction>;
  deleteTransaction(id: number, userId: string): Promise<boolean>;
  
  // Target operations
  getMonthlyTarget(userId: string, month: number, year: number): Promise<MonthlyTarget | undefined>;
  setMonthlyTarget(userId: string, target: InsertMonthlyTarget): Promise<MonthlyTarget>;
  
  // Summary operations
  getDailySummary(userId: string, date: string): Promise<DailySummary>;
  getMonthlySummary(userId: string, month: number, year: number): Promise<MonthlySummary>;
  getDailySummariesForMonth(userId: string, month: number, year: number): Promise<DailySummary[]>;
  
  // Category operations
  getCategories(userId: string): Promise<Category[]>;
  createCategory(userId: string, category: InsertCategory): Promise<Category>;
  deleteCategory(id: number, userId: string): Promise<boolean>;
  getCategorySummaries(userId: string, month: number, year: number): Promise<CategorySummary[]>;
  
  // Product operations
  getProducts(userId: string): Promise<Product[]>;
  getProduct(id: number, userId: string): Promise<Product | undefined>;
  createProduct(userId: string, product: InsertProduct): Promise<Product>;
  updateProduct(id: number, userId: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number, userId: string): Promise<boolean>;
  getLowStockProducts(userId: string): Promise<Product[]>;
  updateProductStock(id: number, userId: string, quantity: number): Promise<Product | undefined>;
  
  // Analytics
  getProductSummaries(userId: string, month: number, year: number): Promise<ProductSummary[]>;
  getPaymentMethodSummaries(userId: string, month: number, year: number): Promise<PaymentMethodSummary[]>;
  
  // Advanced Analytics
  getHourlySales(userId: string, month: number, year: number): Promise<HourlySales[]>;
  getDayOfWeekSales(userId: string, month: number, year: number): Promise<DayOfWeekSales[]>;
  getCustomerInsights(userId: string, limit?: number): Promise<CustomerInsight[]>;
  getProductProfitability(userId: string, month: number, year: number): Promise<ProductProfitability[]>;
  getPeriodComparison(userId: string, periodType: 'weekly' | 'monthly'): Promise<PeriodComparison>;
  
  // Store operations
  getStores(userId: string): Promise<Store[]>;
  getStore(id: number, userId: string): Promise<Store | undefined>;
  createStore(userId: string, store: InsertStore): Promise<Store>;
  updateStore(id: number, userId: string, store: Partial<InsertStore>): Promise<Store | undefined>;
  deleteStore(id: number, userId: string): Promise<boolean>;
  
  // Customer operations
  getCustomers(userId: string): Promise<Customer[]>;
  getCustomer(id: number, userId: string): Promise<Customer | undefined>;
  createCustomer(userId: string, customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, userId: string, customer: Partial<InsertCustomer>): Promise<Customer | undefined>;
  deleteCustomer(id: number, userId: string): Promise<boolean>;
  updateCustomerStats(id: number, userId: string, transactionAmount: number): Promise<Customer | undefined>;
  
  // Audit Log operations
  getAuditLogs(userId?: string, limit?: number): Promise<AuditLog[]>;
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  
  // Subscription operations
  getSubscription(userId: string): Promise<Subscription | undefined>;
  createSubscription(subscription: Partial<InsertSubscription> & { userId: string }): Promise<Subscription>;
  updateSubscription(userId: string, updates: Partial<InsertSubscription>): Promise<Subscription | undefined>;
  
  // Expense Category operations
  getExpenseCategories(userId: string): Promise<ExpenseCategory[]>;
  getExpenseCategory(id: number, userId: string): Promise<ExpenseCategory | undefined>;
  createExpenseCategory(userId: string, category: InsertExpenseCategory): Promise<ExpenseCategory>;
  updateExpenseCategory(id: number, userId: string, category: Partial<InsertExpenseCategory>): Promise<ExpenseCategory | undefined>;
  deleteExpenseCategory(id: number, userId: string): Promise<boolean>;
  
  // Expense operations
  getExpenses(userId: string): Promise<Expense[]>;
  getExpense(id: number, userId: string): Promise<Expense | undefined>;
  createExpense(userId: string, expense: InsertExpense): Promise<Expense>;
  updateExpense(id: number, userId: string, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: number, userId: string): Promise<boolean>;
  getExpenseSummary(userId: string, month: number, year: number): Promise<MonthlyExpenseSummary>;
  
  // Supplier operations
  getSuppliers(userId: string): Promise<Supplier[]>;
  getSupplier(id: number, userId: string): Promise<Supplier | undefined>;
  createSupplier(userId: string, supplier: InsertSupplier): Promise<Supplier>;
  updateSupplier(id: number, userId: string, supplier: Partial<InsertSupplier>): Promise<Supplier | undefined>;
  deleteSupplier(id: number, userId: string): Promise<boolean>;
  
  // Invoice operations
  getInvoices(userId: string): Promise<Invoice[]>;
  getInvoice(id: number, userId: string): Promise<Invoice | undefined>;
  createInvoice(userId: string, invoice: InsertInvoice, items: InsertInvoiceItem[]): Promise<Invoice>;
  updateInvoice(id: number, userId: string, invoice: Partial<InsertInvoice>): Promise<Invoice | undefined>;
  updateInvoiceStatus(id: number, userId: string, status: InvoiceStatus): Promise<Invoice | undefined>;
  deleteInvoice(id: number, userId: string): Promise<boolean>;
  
  // Invoice Item operations
  getInvoiceItems(invoiceId: number): Promise<InvoiceItem[]>;
  addInvoiceItem(item: InsertInvoiceItem): Promise<InvoiceItem>;
  deleteInvoiceItem(id: number): Promise<boolean>;
  generateInvoiceNumber(userId: string): Promise<string>;
  
  // Bulk Import operations
  getBulkImportLogs(userId: string): Promise<BulkImportLog[]>;
  createBulkImportLog(userId: string, log: InsertBulkImportLog): Promise<BulkImportLog>;
  updateBulkImportLog(id: number, updates: Partial<BulkImportLog>): Promise<BulkImportLog | undefined>;
  bulkCreateTransactions(userId: string, transactions: InsertTransaction[]): Promise<ImportResult>;
  bulkUpdateStock(userId: string, items: BulkUpdateStockItem[]): Promise<BulkDeleteResult>;
  bulkDeleteTransactions(userId: string, ids: number[]): Promise<BulkDeleteResult>;
  bulkDeleteProducts(userId: string, ids: number[]): Promise<BulkDeleteResult>;
  
  // Recurring Transaction operations
  getRecurringTransactions(userId: string): Promise<RecurringTransaction[]>;
  getRecurringTransaction(id: number, userId: string): Promise<RecurringTransaction | undefined>;
  createRecurringTransaction(userId: string, recurring: InsertRecurringTransaction): Promise<RecurringTransaction>;
  updateRecurringTransaction(id: number, userId: string, recurring: Partial<InsertRecurringTransaction>): Promise<RecurringTransaction | undefined>;
  deleteRecurringTransaction(id: number, userId: string): Promise<boolean>;
  updateRecurringStatus(id: number, userId: string, status: RecurringStatus): Promise<RecurringTransaction | undefined>;
  getDueRecurringTransactions(userId: string): Promise<RecurringTransaction[]>;
  processRecurringTransaction(id: number, userId: string): Promise<Transaction | undefined>;
  
  // Currency operations
  getCurrencies(): Promise<Currency[]>;
  getCurrency(code: string): Promise<Currency | undefined>;
  createCurrency(currency: InsertCurrency): Promise<Currency>;
  updateCurrency(id: number, currency: Partial<InsertCurrency>): Promise<Currency | undefined>;
  
  // Exchange Rate operations
  getExchangeRates(userId: string): Promise<ExchangeRate[]>;
  getExchangeRate(fromCurrency: string, toCurrency: string, userId: string): Promise<ExchangeRate | undefined>;
  createExchangeRate(userId: string, rate: InsertExchangeRate): Promise<ExchangeRate>;
  updateExchangeRate(id: number, userId: string, rate: Partial<InsertExchangeRate>): Promise<ExchangeRate | undefined>;
  deleteExchangeRate(id: number, userId: string): Promise<boolean>;
  convertCurrency(amount: number, fromCurrency: string, toCurrency: string, userId: string): Promise<number>;
  
  // Notification operations
  getNotifications(userId: string): Promise<Notification[]>;
  getUnreadNotificationCount(userId: string): Promise<number>;
  createNotification(userId: string, notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number, userId: string): Promise<Notification | undefined>;
  markAllNotificationsAsRead(userId: string): Promise<number>;
  deleteNotification(id: number, userId: string): Promise<boolean>;
  deleteAllNotifications(userId: string): Promise<number>;
  generateLowStockNotifications(userId: string): Promise<number>;
  generateDueInvoiceNotifications(userId: string): Promise<number>;
  generateTargetNotifications(userId: string): Promise<number>;
  
  // Notes operations
  getNotes(userId: string, entityType?: string, entityId?: number): Promise<Note[]>;
  getNote(id: number, userId: string): Promise<Note | undefined>;
  createNote(userId: string, note: InsertNote): Promise<Note>;
  updateNote(id: number, userId: string, content: string): Promise<Note | undefined>;
  deleteNote(id: number, userId: string): Promise<boolean>;
  
  // Backup operations
  getBackupLogs(userId: string): Promise<BackupLog[]>;
  createBackupLog(userId: string, log: InsertBackupLog): Promise<BackupLog>;
  updateBackupLog(id: number, updates: Partial<BackupLog>): Promise<BackupLog | undefined>;
  createBackup(userId: string): Promise<{ data: any; fileName: string; recordCount: number }>;
  restoreBackup(userId: string, data: any): Promise<{ success: boolean; recordCount: number }>;
}

function calculateProfit(
  quantity: number,
  costPrice: number,
  sellingPrice: number,
  operationalCost: number
): number {
  const totalRevenue = quantity * sellingPrice;
  const totalCost = quantity * costPrice;
  return totalRevenue - totalCost - operationalCost;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // Check if user already exists
    const existingUser = await this.getUser(userData.id || "");
    
    if (existingUser) {
      // Update existing user but preserve their role
      const [user] = await db
        .update(users)
        .set({
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          profileImageUrl: userData.profileImageUrl,
          updatedAt: new Date(),
        })
        .where(eq(users.id, existingUser.id))
        .returning();
      return user;
    }
    
    // New user - check if this is the first user (should be owner)
    const allUsers = await db.select().from(users);
    const isFirstUser = allUsers.length === 0;
    
    // First user becomes owner, others become kasir
    const role = isFirstUser ? "owner" : "kasir";
    
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        role,
      })
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(asc(users.createdAt));
  }

  async updateUserRole(id: string, role: "owner" | "kasir"): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async deleteUser(id: string): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id)).returning();
    return result.length > 0;
  }

  // Transaction operations
  async getTransactions(userId: string): Promise<Transaction[]> {
    return db.select().from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.date), desc(transactions.id));
  }

  async getTransaction(id: number, userId: string): Promise<Transaction | undefined> {
    const result = await db.select().from(transactions).where(
      and(eq(transactions.id, id), eq(transactions.userId, userId))
    );
    return result[0];
  }

  async createTransaction(userId: string, insertTransaction: InsertTransaction): Promise<Transaction> {
    const date = insertTransaction.date || new Date().toISOString().split("T")[0];
    const profit = calculateProfit(
      insertTransaction.quantity,
      insertTransaction.costPrice,
      insertTransaction.sellingPrice,
      insertTransaction.operationalCost || 0
    );

    const result = await db.insert(transactions).values({
      userId,
      productName: insertTransaction.productName,
      quantity: insertTransaction.quantity,
      costPrice: insertTransaction.costPrice,
      sellingPrice: insertTransaction.sellingPrice,
      operationalCost: insertTransaction.operationalCost || 0,
      profit,
      date,
      category: insertTransaction.category || null,
      paymentMethod: insertTransaction.paymentMethod || "cash",
    }).returning();

    return result[0];
  }

  async deleteTransaction(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(transactions).where(
      and(eq(transactions.id, id), eq(transactions.userId, userId))
    ).returning();
    return result.length > 0;
  }

  // Target operations
  async getMonthlyTarget(userId: string, month: number, year: number): Promise<MonthlyTarget | undefined> {
    const result = await db.select().from(monthlyTargets).where(
      and(
        eq(monthlyTargets.userId, userId),
        eq(monthlyTargets.month, month),
        eq(monthlyTargets.year, year)
      )
    );
    return result[0];
  }

  async setMonthlyTarget(userId: string, insertTarget: InsertMonthlyTarget): Promise<MonthlyTarget> {
    const existing = await this.getMonthlyTarget(userId, insertTarget.month, insertTarget.year);
    
    if (existing) {
      const result = await db.update(monthlyTargets)
        .set({ targetAmount: insertTarget.targetAmount })
        .where(eq(monthlyTargets.id, existing.id))
        .returning();
      return result[0];
    }

    const result = await db.insert(monthlyTargets).values({
      userId,
      month: insertTarget.month,
      year: insertTarget.year,
      targetAmount: insertTarget.targetAmount,
    }).returning();
    return result[0];
  }

  // Summary operations
  async getDailySummary(userId: string, date: string): Promise<DailySummary> {
    const dayTransactions = await db.select().from(transactions).where(
      and(eq(transactions.userId, userId), eq(transactions.date, date))
    );
    
    return {
      date,
      totalRevenue: dayTransactions.reduce((sum, t) => sum + t.quantity * t.sellingPrice, 0),
      totalCost: dayTransactions.reduce((sum, t) => sum + t.quantity * t.costPrice, 0),
      totalOperational: dayTransactions.reduce((sum, t) => sum + t.operationalCost, 0),
      totalProfit: dayTransactions.reduce((sum, t) => sum + t.profit, 0),
      transactionCount: dayTransactions.length,
    };
  }

  async getMonthlySummary(userId: string, month: number, year: number): Promise<MonthlySummary> {
    const allTransactions = await db.select().from(transactions).where(eq(transactions.userId, userId));
    const monthTransactions = allTransactions.filter((t) => {
      const transactionDate = new Date(t.date);
      return (
        transactionDate.getMonth() + 1 === month &&
        transactionDate.getFullYear() === year
      );
    });

    const target = await this.getMonthlyTarget(userId, month, year);
    const totalProfit = monthTransactions.reduce((sum, t) => sum + t.profit, 0);
    const targetAmount = target?.targetAmount || 0;

    return {
      month,
      year,
      totalRevenue: monthTransactions.reduce((sum, t) => sum + t.quantity * t.sellingPrice, 0),
      totalCost: monthTransactions.reduce((sum, t) => sum + t.quantity * t.costPrice, 0),
      totalOperational: monthTransactions.reduce((sum, t) => sum + t.operationalCost, 0),
      totalProfit,
      transactionCount: monthTransactions.length,
      target: targetAmount,
      progressPercentage: targetAmount > 0 ? (totalProfit / targetAmount) * 100 : 0,
    };
  }

  async getDailySummariesForMonth(userId: string, month: number, year: number): Promise<DailySummary[]> {
    const allTransactions = await db.select().from(transactions).where(eq(transactions.userId, userId));
    const monthTransactions = allTransactions.filter((t) => {
      const transactionDate = new Date(t.date);
      return (
        transactionDate.getMonth() + 1 === month &&
        transactionDate.getFullYear() === year
      );
    });

    const groupedByDate = new Map<string, Transaction[]>();
    for (const t of monthTransactions) {
      const existing = groupedByDate.get(t.date) || [];
      existing.push(t);
      groupedByDate.set(t.date, existing);
    }

    const summaries: DailySummary[] = [];
    Array.from(groupedByDate.entries()).forEach(([date, dayTransactions]) => {
      summaries.push({
        date,
        totalRevenue: dayTransactions.reduce((sum: number, t: Transaction) => sum + t.quantity * t.sellingPrice, 0),
        totalCost: dayTransactions.reduce((sum: number, t: Transaction) => sum + t.quantity * t.costPrice, 0),
        totalOperational: dayTransactions.reduce((sum: number, t: Transaction) => sum + t.operationalCost, 0),
        totalProfit: dayTransactions.reduce((sum: number, t: Transaction) => sum + t.profit, 0),
        transactionCount: dayTransactions.length,
      });
    });

    return summaries.sort((a, b) => a.date.localeCompare(b.date));
  }

  // Category operations
  async getCategories(userId: string): Promise<Category[]> {
    return db.select().from(categories)
      .where(eq(categories.userId, userId))
      .orderBy(asc(categories.name));
  }

  async createCategory(userId: string, insertCategory: InsertCategory): Promise<Category> {
    const result = await db.insert(categories).values({
      userId,
      name: insertCategory.name,
      color: insertCategory.color || "#6366f1",
    }).returning();
    return result[0];
  }

  async deleteCategory(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(categories).where(
      and(eq(categories.id, id), eq(categories.userId, userId))
    ).returning();
    return result.length > 0;
  }

  async getCategorySummaries(userId: string, month: number, year: number): Promise<CategorySummary[]> {
    const allTransactions = await db.select().from(transactions).where(eq(transactions.userId, userId));
    const monthTransactions = allTransactions.filter((t) => {
      const transactionDate = new Date(t.date);
      return (
        transactionDate.getMonth() + 1 === month &&
        transactionDate.getFullYear() === year
      );
    });

    const categoryMap = new Map<string, { revenue: number; profit: number; count: number; products: Set<string> }>();
    
    for (const t of monthTransactions) {
      const cat = t.category || "Tanpa Kategori";
      const existing = categoryMap.get(cat) || { revenue: 0, profit: 0, count: 0, products: new Set() };
      existing.revenue += t.quantity * t.sellingPrice;
      existing.profit += t.profit;
      existing.count += 1;
      existing.products.add(t.productName);
      categoryMap.set(cat, existing);
    }

    const summaries: CategorySummary[] = [];
    Array.from(categoryMap.entries()).forEach(([category, data]) => {
      summaries.push({
        category,
        totalRevenue: data.revenue,
        totalProfit: data.profit,
        transactionCount: data.count,
        productCount: data.products.size,
      });
    });

    return summaries.sort((a, b) => b.totalRevenue - a.totalRevenue);
  }

  // Product operations
  async getProducts(userId: string): Promise<Product[]> {
    return db.select().from(products)
      .where(eq(products.userId, userId))
      .orderBy(asc(products.name));
  }

  async getProduct(id: number, userId: string): Promise<Product | undefined> {
    const result = await db.select().from(products).where(
      and(eq(products.id, id), eq(products.userId, userId))
    );
    return result[0];
  }

  async createProduct(userId: string, insertProduct: InsertProduct): Promise<Product> {
    // Check quota before creating
    const quota = await this.checkProductQuota(userId);
    if (!quota.allowed) {
      const error = new Error(`Batas produk tercapai (${quota.current}/${quota.max}). Upgrade paket untuk menambah produk.`) as Error & { code: string };
      error.code = 'PRODUCT_QUOTA_EXCEEDED';
      throw error;
    }
    
    const result = await db.insert(products).values({
      userId,
      name: insertProduct.name,
      categoryId: insertProduct.categoryId || null,
      costPrice: insertProduct.costPrice || 0,
      sellingPrice: insertProduct.sellingPrice || 0,
      stock: insertProduct.stock || 0,
      minStock: insertProduct.minStock || 5,
    }).returning();
    return result[0];
  }

  async updateProduct(id: number, userId: string, updates: Partial<InsertProduct>): Promise<Product | undefined> {
    const result = await db.update(products)
      .set(updates)
      .where(and(eq(products.id, id), eq(products.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteProduct(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(products).where(
      and(eq(products.id, id), eq(products.userId, userId))
    ).returning();
    return result.length > 0;
  }

  async getLowStockProducts(userId: string): Promise<Product[]> {
    const allProducts = await db.select().from(products).where(eq(products.userId, userId));
    return allProducts.filter(p => p.stock <= p.minStock);
  }

  async updateProductStock(id: number, userId: string, quantity: number): Promise<Product | undefined> {
    const product = await this.getProduct(id, userId);
    if (!product) return undefined;
    
    const newStock = Math.max(0, product.stock + quantity);
    return this.updateProduct(id, userId, { stock: newStock });
  }

  // Analytics
  async getProductSummaries(userId: string, month: number, year: number): Promise<ProductSummary[]> {
    const allTransactions = await db.select().from(transactions).where(eq(transactions.userId, userId));
    const monthTransactions = allTransactions.filter((t) => {
      const transactionDate = new Date(t.date);
      return (
        transactionDate.getMonth() + 1 === month &&
        transactionDate.getFullYear() === year
      );
    });

    const productMap = new Map<string, { category: string | null; quantity: number; revenue: number; profit: number; count: number }>();
    
    for (const t of monthTransactions) {
      const existing = productMap.get(t.productName) || { category: t.category, quantity: 0, revenue: 0, profit: 0, count: 0 };
      existing.quantity += t.quantity;
      existing.revenue += t.quantity * t.sellingPrice;
      existing.profit += t.profit;
      existing.count += 1;
      productMap.set(t.productName, existing);
    }

    const summaries: ProductSummary[] = [];
    Array.from(productMap.entries()).forEach(([productName, data]) => {
      summaries.push({
        productName,
        category: data.category,
        totalQuantity: data.quantity,
        totalRevenue: data.revenue,
        totalProfit: data.profit,
        transactionCount: data.count,
      });
    });

    return summaries.sort((a, b) => b.totalQuantity - a.totalQuantity);
  }

  async getPaymentMethodSummaries(userId: string, month: number, year: number): Promise<PaymentMethodSummary[]> {
    const allTransactions = await db.select().from(transactions).where(eq(transactions.userId, userId));
    const monthTransactions = allTransactions.filter((t) => {
      const transactionDate = new Date(t.date);
      return (
        transactionDate.getMonth() + 1 === month &&
        transactionDate.getFullYear() === year
      );
    });

    const methodMap = new Map<string, { revenue: number; count: number }>();
    
    for (const t of monthTransactions) {
      const method = t.paymentMethod || "cash";
      const existing = methodMap.get(method) || { revenue: 0, count: 0 };
      existing.revenue += t.quantity * t.sellingPrice;
      existing.count += 1;
      methodMap.set(method, existing);
    }

    const summaries: PaymentMethodSummary[] = [];
    Array.from(methodMap.entries()).forEach(([method, data]) => {
      summaries.push({
        method,
        totalRevenue: data.revenue,
        transactionCount: data.count,
      });
    });

    return summaries.sort((a, b) => b.totalRevenue - a.totalRevenue);
  }

  // ========== ADVANCED ANALYTICS ==========
  
  // Day name helper
  private getDayName(dayOfWeek: number): string {
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    return days[dayOfWeek] || 'Unknown';
  }
  
  async getHourlySales(userId: string, month: number, year: number): Promise<HourlySales[]> {
    const allTransactions = await db.select().from(transactions).where(eq(transactions.userId, userId));
    const monthTransactions = allTransactions.filter((t) => {
      const transactionDate = new Date(t.date);
      return (
        transactionDate.getMonth() + 1 === month &&
        transactionDate.getFullYear() === year
      );
    });

    // Initialize all 24 hours
    const hourlyMap = new Map<number, { revenue: number; profit: number; count: number }>();
    for (let i = 0; i < 24; i++) {
      hourlyMap.set(i, { revenue: 0, profit: 0, count: 0 });
    }

    // Note: Since transactions only store date (not time), we distribute 
    // transactions across typical business hours (08:00-21:00) for visualization
    const businessHours = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21];
    
    for (const t of monthTransactions) {
      // Distribute each transaction to a business hour based on its ID for consistency
      const hourIndex = t.id % businessHours.length;
      const hour = businessHours[hourIndex];
      const existing = hourlyMap.get(hour) || { revenue: 0, profit: 0, count: 0 };
      existing.revenue += t.quantity * t.sellingPrice;
      existing.profit += t.profit;
      existing.count += 1;
      hourlyMap.set(hour, existing);
    }

    const result: HourlySales[] = [];
    for (let hour = 0; hour < 24; hour++) {
      const data = hourlyMap.get(hour)!;
      result.push({
        hour,
        totalRevenue: data.revenue,
        totalProfit: data.profit,
        transactionCount: data.count,
      });
    }

    return result;
  }

  async getDayOfWeekSales(userId: string, month: number, year: number): Promise<DayOfWeekSales[]> {
    const allTransactions = await db.select().from(transactions).where(eq(transactions.userId, userId));
    const monthTransactions = allTransactions.filter((t) => {
      const transactionDate = new Date(t.date);
      return (
        transactionDate.getMonth() + 1 === month &&
        transactionDate.getFullYear() === year
      );
    });

    // Initialize all 7 days
    const dayMap = new Map<number, { revenue: number; profit: number; count: number }>();
    for (let i = 0; i < 7; i++) {
      dayMap.set(i, { revenue: 0, profit: 0, count: 0 });
    }

    for (const t of monthTransactions) {
      const transactionDate = new Date(t.date);
      const dayOfWeek = transactionDate.getDay(); // 0 = Sunday, 6 = Saturday
      const existing = dayMap.get(dayOfWeek) || { revenue: 0, profit: 0, count: 0 };
      existing.revenue += t.quantity * t.sellingPrice;
      existing.profit += t.profit;
      existing.count += 1;
      dayMap.set(dayOfWeek, existing);
    }

    const result: DayOfWeekSales[] = [];
    for (let day = 0; day < 7; day++) {
      const data = dayMap.get(day)!;
      result.push({
        dayOfWeek: day,
        dayName: this.getDayName(day),
        totalRevenue: data.revenue,
        totalProfit: data.profit,
        transactionCount: data.count,
      });
    }

    return result;
  }

  async getCustomerInsights(userId: string, limit: number = 10): Promise<CustomerInsight[]> {
    const customerList = await this.getCustomers(userId);
    
    const insights: CustomerInsight[] = customerList.map(c => ({
      customerId: c.id,
      customerName: c.name,
      totalTransactions: c.totalTransactions,
      totalSpent: c.totalSpent,
      averageTransactionValue: c.totalTransactions > 0 ? c.totalSpent / c.totalTransactions : 0,
      lastTransactionDate: c.updatedAt ? c.updatedAt.toISOString().split('T')[0] : null,
    }));

    // Sort by total spent and limit
    return insights
      .sort((a, b) => b.totalSpent - a.totalSpent)
      .slice(0, limit);
  }

  async getProductProfitability(userId: string, month: number, year: number): Promise<ProductProfitability[]> {
    const allTransactions = await db.select().from(transactions).where(eq(transactions.userId, userId));
    const monthTransactions = allTransactions.filter((t) => {
      const transactionDate = new Date(t.date);
      return (
        transactionDate.getMonth() + 1 === month &&
        transactionDate.getFullYear() === year
      );
    });

    const productMap = new Map<string, { 
      category: string | null; 
      revenue: number; 
      cost: number; 
      profit: number; 
      quantity: number; 
      count: number 
    }>();
    
    for (const t of monthTransactions) {
      const existing = productMap.get(t.productName) || { 
        category: t.category, 
        revenue: 0, 
        cost: 0, 
        profit: 0, 
        quantity: 0, 
        count: 0 
      };
      existing.revenue += t.quantity * t.sellingPrice;
      existing.cost += t.quantity * t.costPrice + t.operationalCost;
      existing.profit += t.profit;
      existing.quantity += t.quantity;
      existing.count += 1;
      productMap.set(t.productName, existing);
    }

    const result: ProductProfitability[] = [];
    Array.from(productMap.entries()).forEach(([productName, data]) => {
      const profitMargin = data.revenue > 0 ? (data.profit / data.revenue) * 100 : 0;
      result.push({
        productName,
        category: data.category,
        totalRevenue: data.revenue,
        totalCost: data.cost,
        totalProfit: data.profit,
        profitMargin: Math.round(profitMargin * 100) / 100, // Round to 2 decimals
        totalQuantity: data.quantity,
        transactionCount: data.count,
      });
    });

    // Sort by profit margin (highest first)
    return result.sort((a, b) => b.profitMargin - a.profitMargin);
  }

  async getPeriodComparison(userId: string, periodType: 'weekly' | 'monthly'): Promise<PeriodComparison> {
    const allTransactions = await db.select().from(transactions).where(eq(transactions.userId, userId));
    const now = new Date();
    
    let currentStart: Date, currentEnd: Date, previousStart: Date, previousEnd: Date;
    let currentLabel: string, previousLabel: string;
    
    if (periodType === 'weekly') {
      // Current week (Monday-Sunday)
      const dayOfWeek = now.getDay();
      const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
      currentStart = new Date(now);
      currentStart.setDate(now.getDate() - daysToMonday);
      currentStart.setHours(0, 0, 0, 0);
      currentEnd = new Date(currentStart);
      currentEnd.setDate(currentStart.getDate() + 6);
      currentEnd.setHours(23, 59, 59, 999);
      
      // Previous week
      previousStart = new Date(currentStart);
      previousStart.setDate(previousStart.getDate() - 7);
      previousEnd = new Date(currentStart);
      previousEnd.setDate(previousEnd.getDate() - 1);
      previousEnd.setHours(23, 59, 59, 999);
      
      currentLabel = 'Minggu Ini';
      previousLabel = 'Minggu Lalu';
    } else {
      // Current month
      currentStart = new Date(now.getFullYear(), now.getMonth(), 1);
      currentEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
      
      // Previous month
      previousStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      previousEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
      
      currentLabel = 'Bulan Ini';
      previousLabel = 'Bulan Lalu';
    }

    const currentTransactions = allTransactions.filter(t => {
      const date = new Date(t.date);
      return date >= currentStart && date <= currentEnd;
    });
    
    const previousTransactions = allTransactions.filter(t => {
      const date = new Date(t.date);
      return date >= previousStart && date <= previousEnd;
    });

    const calcPeriodStats = (txns: Transaction[]) => {
      const totalRevenue = txns.reduce((sum, t) => sum + t.quantity * t.sellingPrice, 0);
      const totalProfit = txns.reduce((sum, t) => sum + t.profit, 0);
      const transactionCount = txns.length;
      const averageTransactionValue = transactionCount > 0 ? totalRevenue / transactionCount : 0;
      return { totalRevenue, totalProfit, transactionCount, averageTransactionValue };
    };

    const current = calcPeriodStats(currentTransactions);
    const previous = calcPeriodStats(previousTransactions);

    const calcChange = (curr: number, prev: number): number => {
      if (prev === 0) return curr > 0 ? 100 : 0;
      return Math.round(((curr - prev) / prev) * 100 * 100) / 100;
    };

    return {
      currentPeriod: { label: currentLabel, ...current },
      previousPeriod: { label: previousLabel, ...previous },
      revenueChange: calcChange(current.totalRevenue, previous.totalRevenue),
      profitChange: calcChange(current.totalProfit, previous.totalProfit),
      transactionCountChange: calcChange(current.transactionCount, previous.transactionCount),
    };
  }

  // ========== QUOTA HELPERS ==========
  
  // Plan defaults for quota enforcement
  private getPlanDefaults(plan: string): { maxStores: number; maxProducts: number; maxTransactionsPerMonth: number } {
    switch (plan) {
      case 'enterprise':
        return { maxStores: 999, maxProducts: 999999, maxTransactionsPerMonth: 999999 };
      case 'pro':
        return { maxStores: 10, maxProducts: 1000, maxTransactionsPerMonth: 10000 };
      case 'basic':
        return { maxStores: 3, maxProducts: 200, maxTransactionsPerMonth: 2000 };
      case 'free':
      default:
        return { maxStores: 1, maxProducts: 50, maxTransactionsPerMonth: 500 };
    }
  }
  
  // Get effective quota limit, coalescing NULL/undefined to plan defaults
  private getEffectiveLimit(value: number | null | undefined, planDefault: number): number {
    if (value === null || value === undefined) {
      return planDefault;
    }
    // 0 or negative is treated as unlimited
    if (value <= 0) {
      return 999999;
    }
    return value;
  }
  
  private async checkStoreQuota(userId: string): Promise<{ allowed: boolean; current: number; max: number; errorCode?: string }> {
    const subscription = await this.getSubscription(userId);
    const planDefaults = this.getPlanDefaults(subscription?.plan || 'free');
    
    const max = subscription 
      ? this.getEffectiveLimit(subscription.maxStores, planDefaults.maxStores)
      : planDefaults.maxStores;
    
    const storeList = await this.getStores(userId);
    const current = storeList.length;
    
    return { 
      allowed: current < max, 
      current, 
      max,
      errorCode: current >= max ? 'STORE_QUOTA_EXCEEDED' : undefined
    };
  }
  
  private async checkProductQuota(userId: string): Promise<{ allowed: boolean; current: number; max: number; errorCode?: string }> {
    const subscription = await this.getSubscription(userId);
    const planDefaults = this.getPlanDefaults(subscription?.plan || 'free');
    
    const max = subscription 
      ? this.getEffectiveLimit(subscription.maxProducts, planDefaults.maxProducts)
      : planDefaults.maxProducts;
    
    const productList = await this.getProducts(userId);
    const current = productList.length;
    
    return { 
      allowed: current < max, 
      current, 
      max,
      errorCode: current >= max ? 'PRODUCT_QUOTA_EXCEEDED' : undefined
    };
  }
  
  // ========== STORE OPERATIONS ==========
  
  async getStores(userId: string): Promise<Store[]> {
    return db.select().from(stores)
      .where(eq(stores.userId, userId))
      .orderBy(asc(stores.name));
  }

  async getStore(id: number, userId: string): Promise<Store | undefined> {
    const result = await db.select().from(stores).where(
      and(eq(stores.id, id), eq(stores.userId, userId))
    );
    return result[0];
  }

  async createStore(userId: string, insertStore: InsertStore): Promise<Store> {
    // Check quota before creating
    const quota = await this.checkStoreQuota(userId);
    if (!quota.allowed) {
      const error = new Error(`Batas toko tercapai (${quota.current}/${quota.max}). Upgrade paket untuk menambah toko.`) as Error & { code: string };
      error.code = 'STORE_QUOTA_EXCEEDED';
      throw error;
    }
    
    const result = await db.insert(stores).values({
      userId,
      name: insertStore.name,
      address: insertStore.address || null,
      phone: insertStore.phone || null,
      description: insertStore.description || null,
      isActive: insertStore.isActive ?? 1,
    }).returning();
    return result[0];
  }

  async updateStore(id: number, userId: string, updates: Partial<InsertStore>): Promise<Store | undefined> {
    const result = await db.update(stores)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(stores.id, id), eq(stores.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteStore(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(stores).where(
      and(eq(stores.id, id), eq(stores.userId, userId))
    ).returning();
    return result.length > 0;
  }

  // ========== CUSTOMER OPERATIONS ==========
  
  async getCustomers(userId: string): Promise<Customer[]> {
    return db.select().from(customers)
      .where(eq(customers.userId, userId))
      .orderBy(asc(customers.name));
  }

  async getCustomer(id: number, userId: string): Promise<Customer | undefined> {
    const result = await db.select().from(customers).where(
      and(eq(customers.id, id), eq(customers.userId, userId))
    );
    return result[0];
  }

  async createCustomer(userId: string, insertCustomer: InsertCustomer): Promise<Customer> {
    const result = await db.insert(customers).values({
      userId,
      name: insertCustomer.name,
      storeId: insertCustomer.storeId || null,
      phone: insertCustomer.phone || null,
      email: insertCustomer.email || null,
      address: insertCustomer.address || null,
      notes: insertCustomer.notes || null,
    }).returning();
    return result[0];
  }

  async updateCustomer(id: number, userId: string, updates: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const result = await db.update(customers)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(customers.id, id), eq(customers.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteCustomer(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(customers).where(
      and(eq(customers.id, id), eq(customers.userId, userId))
    ).returning();
    return result.length > 0;
  }

  async updateCustomerStats(id: number, userId: string, transactionAmount: number): Promise<Customer | undefined> {
    const customer = await this.getCustomer(id, userId);
    if (!customer) return undefined;
    
    const result = await db.update(customers)
      .set({ 
        totalTransactions: customer.totalTransactions + 1,
        totalSpent: customer.totalSpent + transactionAmount,
        updatedAt: new Date(),
      })
      .where(and(eq(customers.id, id), eq(customers.userId, userId)))
      .returning();
    return result[0];
  }

  // ========== AUDIT LOG OPERATIONS ==========
  
  async getAuditLogs(userId?: string, limit: number = 100): Promise<AuditLog[]> {
    if (userId) {
      return db.select().from(auditLogs)
        .where(eq(auditLogs.userId, userId))
        .orderBy(desc(auditLogs.createdAt))
        .limit(limit);
    }
    return db.select().from(auditLogs)
      .orderBy(desc(auditLogs.createdAt))
      .limit(limit);
  }

  async createAuditLog(log: InsertAuditLog): Promise<AuditLog> {
    const result = await db.insert(auditLogs).values({
      userId: log.userId,
      action: log.action,
      entityType: log.entityType,
      entityId: log.entityId || null,
      oldData: log.oldData || null,
      newData: log.newData || null,
      ipAddress: log.ipAddress || null,
      userAgent: log.userAgent || null,
    }).returning();
    return result[0];
  }

  // ========== SUBSCRIPTION OPERATIONS ==========
  
  async getSubscription(userId: string): Promise<Subscription | undefined> {
    const result = await db.select().from(subscriptions).where(
      eq(subscriptions.userId, userId)
    );
    return result[0];
  }

  async createSubscription(sub: Partial<InsertSubscription> & { userId: string }): Promise<Subscription> {
    const plan = sub.plan || "free";
    
    // Plan-based defaults
    const planDefaults = {
      free: { maxStores: 1, maxProducts: 50, maxTransactionsPerMonth: 100 },
      basic: { maxStores: 3, maxProducts: 200, maxTransactionsPerMonth: 500 },
      pro: { maxStores: 10, maxProducts: 1000, maxTransactionsPerMonth: 5000 },
      enterprise: { maxStores: 999, maxProducts: 10000, maxTransactionsPerMonth: 100000 },
    };
    
    const defaults = planDefaults[plan as keyof typeof planDefaults] || planDefaults.free;
    
    // Set trial end date to 14 days from now if not specified
    const trialEndsAt = sub.trialEndsAt || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);
    
    const result = await db.insert(subscriptions).values({
      userId: sub.userId,
      plan,
      status: sub.status || "trial",
      startDate: sub.startDate || new Date(),
      endDate: sub.endDate || null,
      trialEndsAt,
      maxStores: sub.maxStores ?? defaults.maxStores,
      maxProducts: sub.maxProducts ?? defaults.maxProducts,
      maxTransactionsPerMonth: sub.maxTransactionsPerMonth ?? defaults.maxTransactionsPerMonth,
    }).returning();
    return result[0];
  }

  async updateSubscription(userId: string, updates: Partial<InsertSubscription>): Promise<Subscription | undefined> {
    const result = await db.update(subscriptions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(subscriptions.userId, userId))
      .returning();
    return result[0];
  }

  // ========== EXPENSE CATEGORY OPERATIONS ==========
  
  async getExpenseCategories(userId: string): Promise<ExpenseCategory[]> {
    return db.select().from(expenseCategories)
      .where(eq(expenseCategories.userId, userId))
      .orderBy(asc(expenseCategories.name));
  }

  async getExpenseCategory(id: number, userId: string): Promise<ExpenseCategory | undefined> {
    const result = await db.select().from(expenseCategories).where(
      and(eq(expenseCategories.id, id), eq(expenseCategories.userId, userId))
    );
    return result[0];
  }

  async createExpenseCategory(userId: string, category: InsertExpenseCategory): Promise<ExpenseCategory> {
    const result = await db.insert(expenseCategories).values({
      userId,
      name: category.name,
      color: category.color || "#ef4444",
      description: category.description || null,
    }).returning();
    return result[0];
  }

  async updateExpenseCategory(id: number, userId: string, updates: Partial<InsertExpenseCategory>): Promise<ExpenseCategory | undefined> {
    const result = await db.update(expenseCategories)
      .set(updates)
      .where(and(eq(expenseCategories.id, id), eq(expenseCategories.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteExpenseCategory(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(expenseCategories).where(
      and(eq(expenseCategories.id, id), eq(expenseCategories.userId, userId))
    ).returning();
    return result.length > 0;
  }

  // ========== EXPENSE OPERATIONS ==========
  
  async getExpenses(userId: string): Promise<Expense[]> {
    return db.select().from(expenses)
      .where(eq(expenses.userId, userId))
      .orderBy(desc(expenses.date));
  }

  async getExpense(id: number, userId: string): Promise<Expense | undefined> {
    const result = await db.select().from(expenses).where(
      and(eq(expenses.id, id), eq(expenses.userId, userId))
    );
    return result[0];
  }

  async createExpense(userId: string, expense: InsertExpense): Promise<Expense> {
    const today = new Date().toISOString().split("T")[0];
    const result = await db.insert(expenses).values({
      userId,
      storeId: expense.storeId || null,
      categoryId: expense.categoryId || null,
      description: expense.description,
      amount: expense.amount,
      date: expense.date || today,
      paymentMethod: expense.paymentMethod || "cash",
      receipt: expense.receipt || null,
      notes: expense.notes || null,
    }).returning();
    return result[0];
  }

  async updateExpense(id: number, userId: string, updates: Partial<InsertExpense>): Promise<Expense | undefined> {
    const result = await db.update(expenses)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(expenses.id, id), eq(expenses.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteExpense(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(expenses).where(
      and(eq(expenses.id, id), eq(expenses.userId, userId))
    ).returning();
    return result.length > 0;
  }

  async getExpenseSummary(userId: string, month: number, year: number): Promise<MonthlyExpenseSummary> {
    const allExpenses = await this.getExpenses(userId);
    const allCategories = await this.getExpenseCategories(userId);
    
    // Filter by month/year
    const monthExpenses = allExpenses.filter((e) => {
      const expenseDate = new Date(e.date);
      return (
        expenseDate.getMonth() + 1 === month &&
        expenseDate.getFullYear() === year
      );
    });

    // Group by category
    const categoryMap = new Map<number | null, { amount: number; count: number }>();
    
    for (const expense of monthExpenses) {
      const key = expense.categoryId;
      const existing = categoryMap.get(key) || { amount: 0, count: 0 };
      existing.amount += expense.amount;
      existing.count += 1;
      categoryMap.set(key, existing);
    }

    const categorySummaries: ExpenseSummary[] = [];
    categoryMap.forEach((data, categoryId) => {
      const category = allCategories.find(c => c.id === categoryId);
      categorySummaries.push({
        categoryId,
        categoryName: category?.name || "Tanpa Kategori",
        categoryColor: category?.color || "#6b7280",
        totalAmount: data.amount,
        transactionCount: data.count,
      });
    });

    // Sort by total amount descending
    categorySummaries.sort((a, b) => b.totalAmount - a.totalAmount);

    return {
      month,
      year,
      totalExpenses: monthExpenses.reduce((sum, e) => sum + e.amount, 0),
      expenseCount: monthExpenses.length,
      categories: categorySummaries,
    };
  }

  // ========== SUPPLIER OPERATIONS ==========
  
  async getSuppliers(userId: string): Promise<Supplier[]> {
    return db.select().from(suppliers)
      .where(eq(suppliers.userId, userId))
      .orderBy(asc(suppliers.name));
  }

  async getSupplier(id: number, userId: string): Promise<Supplier | undefined> {
    const result = await db.select().from(suppliers).where(
      and(eq(suppliers.id, id), eq(suppliers.userId, userId))
    );
    return result[0];
  }

  async createSupplier(userId: string, supplier: InsertSupplier): Promise<Supplier> {
    const result = await db.insert(suppliers).values({
      userId,
      name: supplier.name,
      contactPerson: supplier.contactPerson || null,
      phone: supplier.phone || null,
      email: supplier.email || null,
      address: supplier.address || null,
      paymentTerms: supplier.paymentTerms || null,
      notes: supplier.notes || null,
      isActive: supplier.isActive ?? 1,
    }).returning();
    return result[0];
  }

  async updateSupplier(id: number, userId: string, updates: Partial<InsertSupplier>): Promise<Supplier | undefined> {
    const result = await db.update(suppliers)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(suppliers.id, id), eq(suppliers.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteSupplier(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(suppliers).where(
      and(eq(suppliers.id, id), eq(suppliers.userId, userId))
    ).returning();
    return result.length > 0;
  }

  // ========== INVOICE OPERATIONS ==========
  
  async getInvoices(userId: string): Promise<Invoice[]> {
    return db.select().from(invoices)
      .where(eq(invoices.userId, userId))
      .orderBy(desc(invoices.createdAt));
  }

  async getInvoice(id: number, userId: string): Promise<Invoice | undefined> {
    const result = await db.select().from(invoices).where(
      and(eq(invoices.id, id), eq(invoices.userId, userId))
    );
    return result[0];
  }

  async createInvoice(userId: string, invoice: InsertInvoice, items: InsertInvoiceItem[]): Promise<Invoice> {
    const today = new Date().toISOString().split("T")[0];
    
    // Calculate totals
    let subtotal = 0;
    for (const item of items) {
      subtotal += item.quantity * item.unitPrice;
    }
    
    const taxAmount = subtotal * (invoice.taxRate || 0) / 100;
    const discountAmount = subtotal * (invoice.discountRate || 0) / 100;
    const totalAmount = subtotal + taxAmount - discountAmount;
    
    // Create invoice
    const result = await db.insert(invoices).values({
      userId,
      storeId: invoice.storeId || null,
      customerId: invoice.customerId || null,
      invoiceNumber: invoice.invoiceNumber,
      status: invoice.status || "draft",
      issueDate: invoice.issueDate || today,
      dueDate: invoice.dueDate || null,
      subtotal,
      taxRate: invoice.taxRate || 0,
      taxAmount,
      discountRate: invoice.discountRate || 0,
      discountAmount,
      totalAmount,
      notes: invoice.notes || null,
      terms: invoice.terms || null,
    }).returning();
    
    const createdInvoice = result[0];
    
    // Create invoice items
    for (const item of items) {
      await db.insert(invoiceItems).values({
        invoiceId: createdInvoice.id,
        productId: item.productId || null,
        description: item.description,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalPrice: item.quantity * item.unitPrice,
      });
    }
    
    return createdInvoice;
  }

  async updateInvoice(id: number, userId: string, updates: Partial<InsertInvoice>): Promise<Invoice | undefined> {
    const result = await db.update(invoices)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(invoices.id, id), eq(invoices.userId, userId)))
      .returning();
    return result[0];
  }

  async updateInvoiceStatus(id: number, userId: string, status: InvoiceStatus): Promise<Invoice | undefined> {
    const result = await db.update(invoices)
      .set({ status, updatedAt: new Date() })
      .where(and(eq(invoices.id, id), eq(invoices.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteInvoice(id: number, userId: string): Promise<boolean> {
    // First delete invoice items
    const invoice = await this.getInvoice(id, userId);
    if (!invoice) return false;
    
    await db.delete(invoiceItems).where(eq(invoiceItems.invoiceId, id));
    
    // Then delete invoice
    const result = await db.delete(invoices).where(
      and(eq(invoices.id, id), eq(invoices.userId, userId))
    ).returning();
    return result.length > 0;
  }

  // ========== INVOICE ITEM OPERATIONS ==========
  
  async getInvoiceItems(invoiceId: number): Promise<InvoiceItem[]> {
    return db.select().from(invoiceItems)
      .where(eq(invoiceItems.invoiceId, invoiceId));
  }

  async addInvoiceItem(item: InsertInvoiceItem): Promise<InvoiceItem> {
    const result = await db.insert(invoiceItems).values({
      invoiceId: item.invoiceId,
      productId: item.productId || null,
      description: item.description,
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      totalPrice: item.quantity * item.unitPrice,
    }).returning();
    return result[0];
  }

  async deleteInvoiceItem(id: number): Promise<boolean> {
    const result = await db.delete(invoiceItems).where(
      eq(invoiceItems.id, id)
    ).returning();
    return result.length > 0;
  }

  async generateInvoiceNumber(userId: string): Promise<string> {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    
    // Get count of invoices this month
    const allInvoices = await this.getInvoices(userId);
    const monthInvoices = allInvoices.filter(inv => {
      const invDate = new Date(inv.issueDate);
      return invDate.getFullYear() === year && invDate.getMonth() + 1 === parseInt(month);
    });
    
    const count = monthInvoices.length + 1;
    const paddedCount = String(count).padStart(4, '0');
    
    return `INV-${year}${month}-${paddedCount}`;
  }

  // ========== BULK IMPORT OPERATIONS ==========

  async getBulkImportLogs(userId: string): Promise<BulkImportLog[]> {
    return db.select().from(bulkImportLogs)
      .where(eq(bulkImportLogs.userId, userId))
      .orderBy(desc(bulkImportLogs.createdAt));
  }

  async createBulkImportLog(userId: string, log: InsertBulkImportLog): Promise<BulkImportLog> {
    const result = await db.insert(bulkImportLogs).values({
      userId,
      ...log,
    }).returning();
    return result[0];
  }

  async updateBulkImportLog(id: number, updates: Partial<BulkImportLog>): Promise<BulkImportLog | undefined> {
    const result = await db.update(bulkImportLogs)
      .set(updates)
      .where(eq(bulkImportLogs.id, id))
      .returning();
    return result[0];
  }

  async bulkCreateTransactions(userId: string, txns: InsertTransaction[]): Promise<ImportResult> {
    const errors: { row: number; errors: string[] }[] = [];
    let success = 0;

    for (let i = 0; i < txns.length; i++) {
      try {
        const txn = txns[i];
        const profit = calculateProfit(
          txn.quantity,
          txn.costPrice,
          txn.sellingPrice,
          txn.operationalCost || 0
        );
        
        await db.insert(transactions).values({
          userId,
          productName: txn.productName,
          quantity: txn.quantity,
          costPrice: txn.costPrice,
          sellingPrice: txn.sellingPrice,
          operationalCost: txn.operationalCost || 0,
          profit,
          date: txn.date || new Date().toISOString().split("T")[0],
          category: txn.category || null,
          paymentMethod: txn.paymentMethod || "cash",
        });
        success++;
      } catch (error: any) {
        errors.push({ row: i + 1, errors: [error.message || "Unknown error"] });
      }
    }

    return { success, failed: errors.length, errors };
  }

  async bulkUpdateStock(userId: string, items: BulkUpdateStockItem[]): Promise<BulkDeleteResult> {
    const errors: { id: number; error: string }[] = [];
    let success = 0;

    for (const item of items) {
      try {
        const result = await db.update(products)
          .set({ stock: item.newStock })
          .where(and(eq(products.id, item.productId), eq(products.userId, userId)))
          .returning();
        
        if (result.length > 0) {
          success++;
        } else {
          errors.push({ id: item.productId, error: "Product not found" });
        }
      } catch (error: any) {
        errors.push({ id: item.productId, error: error.message || "Unknown error" });
      }
    }

    return { success, failed: errors.length, errors };
  }

  async bulkDeleteTransactions(userId: string, ids: number[]): Promise<BulkDeleteResult> {
    const errors: { id: number; error: string }[] = [];
    let success = 0;

    for (const id of ids) {
      try {
        const result = await db.delete(transactions)
          .where(and(eq(transactions.id, id), eq(transactions.userId, userId)))
          .returning();
        
        if (result.length > 0) {
          success++;
        } else {
          errors.push({ id, error: "Transaction not found" });
        }
      } catch (error: any) {
        errors.push({ id, error: error.message || "Unknown error" });
      }
    }

    return { success, failed: errors.length, errors };
  }

  async bulkDeleteProducts(userId: string, ids: number[]): Promise<BulkDeleteResult> {
    const errors: { id: number; error: string }[] = [];
    let success = 0;

    for (const id of ids) {
      try {
        const result = await db.delete(products)
          .where(and(eq(products.id, id), eq(products.userId, userId)))
          .returning();
        
        if (result.length > 0) {
          success++;
        } else {
          errors.push({ id, error: "Product not found" });
        }
      } catch (error: any) {
        errors.push({ id, error: error.message || "Unknown error" });
      }
    }

    return { success, failed: errors.length, errors };
  }

  // ========== RECURRING TRANSACTION OPERATIONS ==========

  async getRecurringTransactions(userId: string): Promise<RecurringTransaction[]> {
    return db.select().from(recurringTransactions)
      .where(eq(recurringTransactions.userId, userId))
      .orderBy(desc(recurringTransactions.createdAt));
  }

  async getRecurringTransaction(id: number, userId: string): Promise<RecurringTransaction | undefined> {
    const result = await db.select().from(recurringTransactions)
      .where(and(eq(recurringTransactions.id, id), eq(recurringTransactions.userId, userId)));
    return result[0];
  }

  async createRecurringTransaction(userId: string, recurring: InsertRecurringTransaction): Promise<RecurringTransaction> {
    const result = await db.insert(recurringTransactions).values({
      userId,
      ...recurring,
    }).returning();
    return result[0];
  }

  async updateRecurringTransaction(id: number, userId: string, recurring: Partial<InsertRecurringTransaction>): Promise<RecurringTransaction | undefined> {
    const result = await db.update(recurringTransactions)
      .set({ ...recurring, updatedAt: new Date() })
      .where(and(eq(recurringTransactions.id, id), eq(recurringTransactions.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteRecurringTransaction(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(recurringTransactions)
      .where(and(eq(recurringTransactions.id, id), eq(recurringTransactions.userId, userId)))
      .returning();
    return result.length > 0;
  }

  async updateRecurringStatus(id: number, userId: string, status: RecurringStatus): Promise<RecurringTransaction | undefined> {
    const result = await db.update(recurringTransactions)
      .set({ status, updatedAt: new Date() })
      .where(and(eq(recurringTransactions.id, id), eq(recurringTransactions.userId, userId)))
      .returning();
    return result[0];
  }

  async getDueRecurringTransactions(userId: string): Promise<RecurringTransaction[]> {
    const today = new Date().toISOString().split("T")[0];
    return db.select().from(recurringTransactions)
      .where(and(
        eq(recurringTransactions.userId, userId),
        eq(recurringTransactions.status, "active"),
        lte(recurringTransactions.nextScheduledDate, today)
      ));
  }

  async processRecurringTransaction(id: number, userId: string): Promise<Transaction | undefined> {
    const recurring = await this.getRecurringTransaction(id, userId);
    if (!recurring || recurring.status !== "active") return undefined;

    const today = new Date().toISOString().split("T")[0];
    if (recurring.nextScheduledDate > today) return undefined;

    // Create the transaction
    const profit = calculateProfit(
      recurring.quantity,
      recurring.costPrice,
      recurring.sellingPrice,
      recurring.operationalCost
    );

    const txnResult = await db.insert(transactions).values({
      userId,
      productName: recurring.productName,
      quantity: recurring.quantity,
      costPrice: recurring.costPrice,
      sellingPrice: recurring.sellingPrice,
      operationalCost: recurring.operationalCost,
      profit,
      date: today,
      category: recurring.category,
      paymentMethod: recurring.paymentMethod,
    }).returning();

    // Calculate next scheduled date
    const nextDate = this.calculateNextScheduledDate(today, recurring.frequency);
    
    // Check if end date reached
    let newStatus: RecurringStatus = "active";
    if (recurring.endDate && nextDate > recurring.endDate) {
      newStatus = "completed";
    }

    // Update recurring transaction
    await db.update(recurringTransactions)
      .set({
        lastGeneratedDate: today,
        nextScheduledDate: nextDate,
        status: newStatus,
        updatedAt: new Date(),
      })
      .where(eq(recurringTransactions.id, id));

    return txnResult[0];
  }

  private calculateNextScheduledDate(currentDate: string, frequency: string): string {
    const date = new Date(currentDate);
    
    switch (frequency) {
      case "daily":
        date.setDate(date.getDate() + 1);
        break;
      case "weekly":
        date.setDate(date.getDate() + 7);
        break;
      case "biweekly":
        date.setDate(date.getDate() + 14);
        break;
      case "monthly":
        date.setMonth(date.getMonth() + 1);
        break;
      case "yearly":
        date.setFullYear(date.getFullYear() + 1);
        break;
    }
    
    return date.toISOString().split("T")[0];
  }

  // ========== CURRENCY OPERATIONS ==========

  async getCurrencies(): Promise<Currency[]> {
    return db.select().from(currencies).orderBy(asc(currencies.code));
  }

  async getCurrency(code: string): Promise<Currency | undefined> {
    const result = await db.select().from(currencies)
      .where(eq(currencies.code, code as any));
    return result[0];
  }

  async createCurrency(currency: InsertCurrency): Promise<Currency> {
    const result = await db.insert(currencies).values(currency).returning();
    return result[0];
  }

  async updateCurrency(id: number, currency: Partial<InsertCurrency>): Promise<Currency | undefined> {
    const result = await db.update(currencies)
      .set(currency)
      .where(eq(currencies.id, id))
      .returning();
    return result[0];
  }

  // ========== EXCHANGE RATE OPERATIONS ==========

  async getExchangeRates(userId: string): Promise<ExchangeRate[]> {
    return db.select().from(exchangeRates)
      .where(eq(exchangeRates.userId, userId))
      .orderBy(desc(exchangeRates.createdAt));
  }

  async getExchangeRate(fromCurrency: string, toCurrency: string, userId: string): Promise<ExchangeRate | undefined> {
    const result = await db.select().from(exchangeRates)
      .where(and(
        eq(exchangeRates.fromCurrency, fromCurrency as any),
        eq(exchangeRates.toCurrency, toCurrency as any),
        eq(exchangeRates.userId, userId),
        eq(exchangeRates.isDefault, 1)
      ))
      .orderBy(desc(exchangeRates.validFrom))
      .limit(1);
    return result[0];
  }

  async createExchangeRate(userId: string, rate: InsertExchangeRate): Promise<ExchangeRate> {
    // If this is set as default, unset other defaults for same pair
    if (rate.isDefault === 1) {
      await db.update(exchangeRates)
        .set({ isDefault: 0 })
        .where(and(
          eq(exchangeRates.fromCurrency, rate.fromCurrency),
          eq(exchangeRates.toCurrency, rate.toCurrency),
          eq(exchangeRates.userId, userId)
        ));
    }

    const result = await db.insert(exchangeRates).values({
      userId,
      fromCurrency: rate.fromCurrency,
      toCurrency: rate.toCurrency,
      rate: rate.rate,
      isDefault: rate.isDefault || 0,
      validFrom: rate.validFrom || new Date(),
    }).returning();
    return result[0];
  }

  async updateExchangeRate(id: number, userId: string, rate: Partial<InsertExchangeRate>): Promise<ExchangeRate | undefined> {
    const result = await db.update(exchangeRates)
      .set({ ...rate, updatedAt: new Date() })
      .where(and(eq(exchangeRates.id, id), eq(exchangeRates.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteExchangeRate(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(exchangeRates)
      .where(and(eq(exchangeRates.id, id), eq(exchangeRates.userId, userId)))
      .returning();
    return result.length > 0;
  }

  async convertCurrency(amount: number, fromCurrency: string, toCurrency: string, userId: string): Promise<number> {
    if (fromCurrency === toCurrency) return amount;

    const rate = await this.getExchangeRate(fromCurrency, toCurrency, userId);
    if (rate) {
      return amount * rate.rate;
    }

    // Try reverse rate
    const reverseRate = await this.getExchangeRate(toCurrency, fromCurrency, userId);
    if (reverseRate) {
      return amount / reverseRate.rate;
    }

    // No rate found, return original amount
    return amount;
  }

  // Initialize default currencies
  async initializeDefaultCurrencies(): Promise<void> {
    const existingCurrencies = await this.getCurrencies();
    if (existingCurrencies.length > 0) return;

    const defaultCurrencies = [
      { code: "IDR" as const, name: "Indonesian Rupiah", symbol: "Rp", isActive: 1 },
      { code: "USD" as const, name: "US Dollar", symbol: "$", isActive: 1 },
      { code: "SGD" as const, name: "Singapore Dollar", symbol: "S$", isActive: 1 },
      { code: "MYR" as const, name: "Malaysian Ringgit", symbol: "RM", isActive: 1 },
      { code: "EUR" as const, name: "Euro", symbol: "€", isActive: 1 },
      { code: "JPY" as const, name: "Japanese Yen", symbol: "¥", isActive: 1 },
      { code: "CNY" as const, name: "Chinese Yuan", symbol: "¥", isActive: 1 },
      { code: "AUD" as const, name: "Australian Dollar", symbol: "A$", isActive: 1 },
      { code: "GBP" as const, name: "British Pound", symbol: "£", isActive: 1 },
    ];

    for (const curr of defaultCurrencies) {
      await this.createCurrency(curr);
    }
  }

  // ========== NOTIFICATION OPERATIONS ==========

  async getNotifications(userId: string): Promise<Notification[]> {
    return db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async getUnreadNotificationCount(userId: string): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)` })
      .from(notifications)
      .where(and(
        eq(notifications.userId, userId),
        eq(notifications.isRead, 0)
      ));
    return Number(result[0]?.count || 0);
  }

  async createNotification(userId: string, notification: InsertNotification): Promise<Notification> {
    const result = await db.insert(notifications).values({
      userId,
      type: notification.type,
      title: notification.title,
      message: notification.message,
      entityType: notification.entityType || null,
      entityId: notification.entityId || null,
      isRead: 0,
      priority: notification.priority || "normal",
    }).returning();
    return result[0];
  }

  async markNotificationAsRead(id: number, userId: string): Promise<Notification | undefined> {
    const result = await db.update(notifications)
      .set({ isRead: 1 })
      .where(and(eq(notifications.id, id), eq(notifications.userId, userId)))
      .returning();
    return result[0];
  }

  async markAllNotificationsAsRead(userId: string): Promise<number> {
    const result = await db.update(notifications)
      .set({ isRead: 1 })
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, 0)))
      .returning();
    return result.length;
  }

  async deleteNotification(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(notifications)
      .where(and(eq(notifications.id, id), eq(notifications.userId, userId)))
      .returning();
    return result.length > 0;
  }

  async deleteAllNotifications(userId: string): Promise<number> {
    const result = await db.delete(notifications)
      .where(eq(notifications.userId, userId))
      .returning();
    return result.length;
  }

  async generateLowStockNotifications(userId: string): Promise<number> {
    const lowStockProducts = await db.select().from(products)
      .where(and(
        eq(products.userId, userId),
        sql`${products.stock} <= ${products.minStock}`
      ));

    let count = 0;
    for (const product of lowStockProducts) {
      // Check if notification already exists for this product today
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const existing = await db.select().from(notifications)
        .where(and(
          eq(notifications.userId, userId),
          eq(notifications.type, "low_stock"),
          eq(notifications.entityType, "product"),
          eq(notifications.entityId, product.id),
          gte(notifications.createdAt, today)
        ))
        .limit(1);

      if (existing.length === 0) {
        await this.createNotification(userId, {
          type: "low_stock",
          title: "Stok Menipis",
          message: `Stok ${product.name} tinggal ${product.stock} unit (minimum: ${product.minStock})`,
          entityType: "product",
          entityId: product.id,
          priority: "high",
        });
        count++;
      }
    }
    return count;
  }

  async generateDueInvoiceNotifications(userId: string): Promise<number> {
    const today = new Date();
    const threeDaysFromNow = new Date();
    threeDaysFromNow.setDate(today.getDate() + 3);

    const dueInvoices = await db.select().from(invoices)
      .where(and(
        eq(invoices.userId, userId),
        eq(invoices.status, "sent"),
        lte(invoices.dueDate, threeDaysFromNow)
      ));

    let count = 0;
    for (const invoice of dueInvoices) {
      // Check if notification already exists
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      
      const existing = await db.select().from(notifications)
        .where(and(
          eq(notifications.userId, userId),
          eq(notifications.type, "invoice_due"),
          eq(notifications.entityType, "invoice"),
          eq(notifications.entityId, invoice.id),
          gte(notifications.createdAt, todayStart)
        ))
        .limit(1);

      if (existing.length === 0) {
        const isOverdue = invoice.dueDate && new Date(invoice.dueDate) < today;
        await this.createNotification(userId, {
          type: "invoice_due",
          title: isOverdue ? "Invoice Jatuh Tempo" : "Invoice Akan Jatuh Tempo",
          message: `Invoice ${invoice.invoiceNumber} ${isOverdue ? 'sudah jatuh tempo' : 'akan jatuh tempo dalam 3 hari'}`,
          entityType: "invoice",
          entityId: invoice.id,
          priority: isOverdue ? "high" : "normal",
        });
        count++;
      }
    }
    return count;
  }

  async generateTargetNotifications(userId: string): Promise<number> {
    const today = new Date();
    const month = today.getMonth() + 1;
    const year = today.getFullYear();

    const target = await this.getMonthlyTarget(userId, month, year);
    if (!target) return 0;

    const summary = await this.getMonthlySummary(userId, month, year);
    const progress = (summary.totalRevenue / target.targetAmount) * 100;

    // Check if notification already exists today
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    let count = 0;

    if (progress >= 100) {
      const existing = await db.select().from(notifications)
        .where(and(
          eq(notifications.userId, userId),
          eq(notifications.type, "target_achieved"),
          gte(notifications.createdAt, todayStart)
        ))
        .limit(1);

      if (existing.length === 0) {
        await this.createNotification(userId, {
          type: "target_achieved",
          title: "Target Tercapai!",
          message: `Selamat! Target bulan ini sudah tercapai ${progress.toFixed(1)}%`,
          entityType: "target",
          entityId: target.id,
          priority: "normal",
        });
        count++;
      }
    } else if (progress >= 80) {
      const existing = await db.select().from(notifications)
        .where(and(
          eq(notifications.userId, userId),
          eq(notifications.type, "target_warning"),
          gte(notifications.createdAt, todayStart)
        ))
        .limit(1);

      if (existing.length === 0) {
        await this.createNotification(userId, {
          type: "target_warning",
          title: "Target Hampir Tercapai",
          message: `Target bulan ini sudah ${progress.toFixed(1)}% tercapai. Semangat!`,
          entityType: "target",
          entityId: target.id,
          priority: "low",
        });
        count++;
      }
    }

    return count;
  }

  // ========== NOTES OPERATIONS ==========

  async getNotes(userId: string, entityType?: string, entityId?: number): Promise<Note[]> {
    if (entityType && entityId) {
      return db.select().from(notes)
        .where(and(
          eq(notes.userId, userId),
          eq(notes.entityType, entityType as any),
          eq(notes.entityId, entityId)
        ))
        .orderBy(desc(notes.createdAt));
    }
    return db.select().from(notes)
      .where(eq(notes.userId, userId))
      .orderBy(desc(notes.createdAt));
  }

  async getNote(id: number, userId: string): Promise<Note | undefined> {
    const result = await db.select().from(notes)
      .where(and(eq(notes.id, id), eq(notes.userId, userId)));
    return result[0];
  }

  async createNote(userId: string, note: InsertNote): Promise<Note> {
    const result = await db.insert(notes).values({
      userId,
      entityType: note.entityType,
      entityId: note.entityId,
      content: note.content,
    }).returning();
    return result[0];
  }

  async updateNote(id: number, userId: string, content: string): Promise<Note | undefined> {
    const result = await db.update(notes)
      .set({ content, updatedAt: new Date() })
      .where(and(eq(notes.id, id), eq(notes.userId, userId)))
      .returning();
    return result[0];
  }

  async deleteNote(id: number, userId: string): Promise<boolean> {
    const result = await db.delete(notes)
      .where(and(eq(notes.id, id), eq(notes.userId, userId)))
      .returning();
    return result.length > 0;
  }

  // ========== BACKUP OPERATIONS ==========

  async getBackupLogs(userId: string): Promise<BackupLog[]> {
    return db.select().from(backupLogs)
      .where(eq(backupLogs.userId, userId))
      .orderBy(desc(backupLogs.createdAt));
  }

  async createBackupLog(userId: string, log: InsertBackupLog): Promise<BackupLog> {
    const result = await db.insert(backupLogs).values({
      userId,
      type: log.type,
      status: log.status || "pending",
      fileName: log.fileName || null,
      fileSize: log.fileSize || null,
      tablesIncluded: log.tablesIncluded || null,
      recordCount: log.recordCount || null,
      errorMessage: log.errorMessage || null,
    }).returning();
    return result[0];
  }

  async updateBackupLog(id: number, updates: Partial<BackupLog>): Promise<BackupLog | undefined> {
    const result = await db.update(backupLogs)
      .set(updates)
      .where(eq(backupLogs.id, id))
      .returning();
    return result[0];
  }

  async createBackup(userId: string): Promise<{ data: any; fileName: string; recordCount: number }> {
    // Collect all user data
    const userTransactions = await this.getTransactions(userId);
    const userCategories = await this.getCategories(userId);
    const userProducts = await this.getProducts(userId);
    const userTargets = await db.select().from(monthlyTargets).where(eq(monthlyTargets.userId, userId));
    const userStores = await this.getStores(userId);
    const userCustomers = await this.getCustomers(userId);
    const userExpenses = await this.getExpenses(userId);
    const userExpenseCategories = await this.getExpenseCategories(userId);
    const userSuppliers = await this.getSuppliers(userId);
    const userInvoices = await this.getInvoices(userId);
    const userRecurring = await this.getRecurringTransactions(userId);
    const userExchangeRates = await this.getExchangeRates(userId);

    const data = {
      version: "1.0",
      exportedAt: new Date().toISOString(),
      userId,
      transactions: userTransactions,
      categories: userCategories,
      products: userProducts,
      monthlyTargets: userTargets,
      stores: userStores,
      customers: userCustomers,
      expenses: userExpenses,
      expenseCategories: userExpenseCategories,
      suppliers: userSuppliers,
      invoices: userInvoices,
      recurringTransactions: userRecurring,
      exchangeRates: userExchangeRates,
    };

    const recordCount = 
      userTransactions.length + userCategories.length + userProducts.length +
      userTargets.length + userStores.length + userCustomers.length +
      userExpenses.length + userExpenseCategories.length + userSuppliers.length +
      userInvoices.length + userRecurring.length + userExchangeRates.length;

    const fileName = `backup_${userId}_${new Date().toISOString().slice(0,10)}.json`;

    return { data, fileName, recordCount };
  }

  async restoreBackup(userId: string, data: any): Promise<{ success: boolean; recordCount: number }> {
    let recordCount = 0;

    try {
      // Restore categories first (products depend on them)
      if (data.categories?.length) {
        for (const cat of data.categories) {
          await this.createCategory(userId, { name: cat.name, color: cat.color });
          recordCount++;
        }
      }

      // Restore products
      if (data.products?.length) {
        for (const prod of data.products) {
          await this.createProduct(userId, {
            name: prod.name,
            categoryId: prod.categoryId,
            costPrice: prod.costPrice,
            sellingPrice: prod.sellingPrice,
            stock: prod.stock,
            minStock: prod.minStock,
          });
          recordCount++;
        }
      }

      // Restore customers
      if (data.customers?.length) {
        for (const cust of data.customers) {
          await this.createCustomer(userId, {
            name: cust.name,
            phone: cust.phone,
            email: cust.email,
            address: cust.address,
            notes: cust.notes,
          });
          recordCount++;
        }
      }

      // Restore stores
      if (data.stores?.length) {
        for (const store of data.stores) {
          await this.createStore(userId, {
            name: store.name,
            address: store.address,
            phone: store.phone,
            description: store.description,
          });
          recordCount++;
        }
      }

      // Restore expense categories
      if (data.expenseCategories?.length) {
        for (const cat of data.expenseCategories) {
          await this.createExpenseCategory(userId, {
            name: cat.name,
            color: cat.color,
            description: cat.description,
          });
          recordCount++;
        }
      }

      // Restore suppliers
      if (data.suppliers?.length) {
        for (const sup of data.suppliers) {
          await this.createSupplier(userId, {
            name: sup.name,
            contactPerson: sup.contactPerson,
            phone: sup.phone,
            email: sup.email,
            address: sup.address,
            paymentTerms: sup.paymentTerms,
            notes: sup.notes,
          });
          recordCount++;
        }
      }

      // Note: We don't restore transactions, invoices, expenses to avoid duplicates
      // User can choose to import those separately via bulk import

      return { success: true, recordCount };
    } catch (error) {
      console.error("Restore backup error:", error);
      return { success: false, recordCount };
    }
  }
}

export const storage = new DatabaseStorage();
