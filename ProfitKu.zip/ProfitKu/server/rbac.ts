import type { Request, Response, NextFunction } from "express";
import { storage } from "./storage";

export type Permission = 
  | "delete:transaction"
  | "delete:category"
  | "delete:product"
  | "delete:user"
  | "delete:customer"
  | "delete:store"
  | "delete:expense"
  | "delete:supplier"
  | "delete:invoice"
  | "export:reports"
  | "manage:users"
  | "manage:stores"
  | "view:audit-log";

const rolePermissions: Record<string, Permission[]> = {
  owner: [
    "delete:transaction",
    "delete:category",
    "delete:product",
    "delete:user",
    "delete:customer",
    "delete:store",
    "delete:expense",
    "delete:supplier",
    "delete:invoice",
    "export:reports",
    "manage:users",
    "manage:stores",
    "view:audit-log",
  ],
  kasir: [],
};

export function hasPermission(role: string, permission: Permission): boolean {
  const permissions = rolePermissions[role] || [];
  return permissions.includes(permission);
}

export function requirePermission(...permissions: Permission[]) {
  return async (req: any, res: Response, next: NextFunction) => {
    try {
      if (!req.user?.claims?.sub) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }

      const userRole = user.role || "kasir";
      const hasAllPermissions = permissions.every(p => hasPermission(userRole, p));

      if (!hasAllPermissions) {
        return res.status(403).json({ 
          message: "Akses ditolak. Anda tidak memiliki izin untuk melakukan aksi ini.",
          requiredPermissions: permissions,
        });
      }

      req.userRole = userRole;
      req.userData = user;
      next();
    } catch (error) {
      console.error("RBAC middleware error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  };
}

export function requireOwner() {
  return requirePermission("manage:users");
}
